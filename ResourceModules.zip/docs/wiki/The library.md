This section provides an overview of the design and principles the CARML modules are built upon, how they are set up, and how you can interact with them.

---

### _Navigation_

- [Module overview](./The%20library%20-%20Module%20overview)
- [Module design](./The%20library%20-%20Module%20design)
- [Module usage](./The%20library%20-%20Module%20usage)

---

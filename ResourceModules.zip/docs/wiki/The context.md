This section explains the context of the Common Azure Resource Modules Library (CARML) and the motivation for its creation.

---

### _Navigation_
- [CARML overview](./The%20context%20-%20CARML%20overview)
  - [The library](./The%20context%20-%20CARML%20library)
  - [The CI environment](./The%20context%20-%20CARML%20CI%20environment)
- [Logical layers and personas](./The%20context%20-%20Logical%20layers%20and%20personas)

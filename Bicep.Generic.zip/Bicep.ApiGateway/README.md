Resource name suggestions
 
Resource Groups;
UKS-POC-RSG0020-ApiGateway
UKS-POC-RSG0021-ApiGateway-Network
 
Key Vault;
UKS-POC-KYV-0007-ApiGateway
 
App Insights;
UKS-POC-AIN0028-ApiGateway
 
Log Analytics;
UKS-POC-LAI0019-ApiGateway
 
APIM;
UKS-POC-APM0001-ApiGateway
 
NSG;
UKS-POC-NSG0005-ApiGateway
 
Route table;
UKS-POC-UDR0001-ApiGateway
 
Completed;
Owner granted on sandbox subscription DevOpsIACPOC
ACR Reader granted on Container Registry (in Azure General subscription)
Resource name suggestions for PoC deployment above
New repo named Bicep.ApiGateway in IT DevOps
 
Outstanding;
Still working on Octopus read only as this requires some forethought/planning
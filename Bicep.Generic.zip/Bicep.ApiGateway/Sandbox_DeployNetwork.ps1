function ParamBuilder
{
   param([Object]$ParamArg)
   $Arg = [PSCustomObject]::new()
   foreach ($Param in $ParamArg)
   {
      if ($Param.Value.Length -gt 0)
      {
         Write-Host Adding $Param.Name to parameter list with value $Param.Value
         $Arg | Add-Member NoteProperty -Name $Param.Name -Value ([PSCustomObject] @{ value = $Param.Value })
      } 
   }
   return ($Arg | ConvertTo-Json -Compress).Replace('"', '\"')
}

$azureApplicationId = "b648d3ac-2c67-40c4-848a-2787fa604395"                                             #$OctopusParameters["AzureAccount.Client"]
$azureTenantId = "07808216-ca18-4f9b-b249-7d53dadb5344"                                                  #$OctopusParameters["AzureAccount.TenantId"]
$azurePassword = ConvertTo-SecureString "PGi8Q~~7ikIZA-LD2WTiBd5J.e~hz4XYJasfFaYk" -AsPlainText -Force   #$OctopusParameters["AzureAccount.Password"]
$subscriptionId = "3f88752d-7039-4e85-b9b9-22dd7b8adfb6"                                                 #$OctopusParameters["DunnoWhereWe'reGettin.ThisFromYet"]

############################
#### Authentication
############################
Write-Host AppId: $azureApplicationId
Write-Host Tenant: $azureTenantId
Write-Host Subscr: $subscriptionId
Write-Host Password: $azurePassword
   
$AzCred = New-Object System.Management.Automation.PSCredential($azureApplicationId , $azurePassword)
$AzLogin = az login --service-principal -u $AzCred.UserName -p $AzCred.GetNetworkCredential().Password --tenant $azureTenantId | ConvertFrom-Json
az account set --subscription $subscriptionId 
$acc = az account show | ConvertFrom-Json
Write-Host "Subscription scoped to"  $acc.name "-" $acc.id

####################
# Parent
####################
$DeploymentParentName = "ApiGatewayNetworkPoC" 
$BicepParentFilePath = ".\ApiGatewayNetwork.bicep"
$ResourceGroupName = "UKS-POC-RSG0021-ApiGateway-Network"

$ExistingVnetName = 'AZSPOC-VNET'
$ExistingVnetRG = 'UKS-TST-RSG0001-Network'
$ExistingVnetSubscription = '3f88752d-7039-4e85-b9b9-22dd7b8adfb6'
$subnet01Range  = '10.60.120.32/28'
$subnet02Range  = '10.60.120.48/28'
$subnet01Name  = 'UKS-POC-SUB0001-ApiGateway'
$subnet02Name  = 'UKS-POC-SUB0002-ApiGateway'
$routeTableName  = 'UKS-POC-RT0001-ApiGateway'
$virtualApplianceIp  = '10.100.176.0'
$nsg1Name = 'UKS-POC-NSG0001-ApiGateway'
$nsg2Name = 'UKS-POC-NSG0002-ApiGateway'
$apimPublicIp = 'APIMPublicIP'

$Params = @(
   [PSCustomObject]@{ Name = "ExistingVnetName"; Value = $ExistingVnetName }   
   [PSCustomObject]@{ Name = "ExistingVnetRG"; Value = $ExistingVnetRG }   
   [PSCustomObject]@{ Name = "ExistingVnetSubscription"; Value = $ExistingVnetSubscription }   
   [PSCustomObject]@{ Name = "subnet01Range"; Value = $subnet01Range }
   [PSCustomObject]@{ Name = "subnet02Range"; Value = $subnet02Range }
   [PSCustomObject]@{ Name = "subnet01Name"; Value = $subnet01Name }
   [PSCustomObject]@{ Name = "subnet02Name"; Value = $subnet02Name }
   [PSCustomObject]@{ Name = "routeTableName"; Value = $routeTableName }
   [PSCustomObject]@{ Name = "virtualApplianceIp"; Value = $virtualApplianceIp }
   [PSCustomObject]@{ Name = "nsg1Name"; Value = $nsg1Name }
   [PSCustomObject]@{ Name = "nsg2Name"; Value = $nsg2Name }
   [PSCustomObject]@{ Name = "apimPublicIp"; Value = $apimPublicIp }
)
$ParamString = ParamBuilder -ParamArg $Params

Write-Host Deploying $DeploymentParentName

az deployment group create `
   --resource-group $ResourceGroupName `
   --template-file $BicepParentFilePath `
   --name $DeploymentParentName `
   --parameters $ParamString `
   --debug

Write-Host Deployment complete

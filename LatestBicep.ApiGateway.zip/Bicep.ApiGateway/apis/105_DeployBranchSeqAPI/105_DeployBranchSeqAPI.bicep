
import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'


@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')



@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

// var vecoOpenApiSpec = loadTextContent('./api-specs/veco-desktop-msgFramework.json')


resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vaultName
}

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

var linkFormat = 'openapi'

var branchSnippet = loadTextContent('policy-snippets/branch-api-seq.xml')
var branchApiName = 'branch-api-seq'



var pocSwaggerLink = loadTextContent('api-specs/veco-desktop-branch-v1-poc.json')
var uatSwaggerLink = loadTextContent('api-specs/veco-desktop-branch-v1-poc.json')
var tstSwaggerLink = loadTextContent('api-specs/veco-desktop-branch-v1-poc.json')
var qatSwaggerLink = loadTextContent('api-specs/veco-desktop-branch-v1-poc.json')
var prdSwaggerLink = loadTextContent('api-specs/veco-desktop-branch-v1-poc.json')
var finalSwaggerLink = Environment == 'poc' ? pocSwaggerLink
  : Environment == 'tst' ? tstSwaggerLink
  : Environment == 'uat' ? uatSwaggerLink
  : Environment == 'qat' ? qatSwaggerLink
  : Environment == 'prd' ? prdSwaggerLink
  : 'unknown'


var branchApiVersionV1 = 'v1'
var branchSubscriptionRequiredV1= 'false'
module importBranchAPIV1 '../../modules/api-import/import-api-apim-oauth-backend-oauth.bicep' = if(contains(['poc','tst','uat'], Environment)) {
  name: '${Timestamp}-ImportBranchAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(branchApiName)}-api-${branchApiVersionV1}'
    apiUrl: finalSwaggerLink
    apiPath: branchApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(branchApiName)}API ${branchApiVersionV1}'
    apiVersion: branchApiVersionV1
    productDescription: '${toUpper(branchApiName)} Product'
    productDisplayName: '${toUpper(branchApiName)} Product'
    productName: '${toUpper(branchApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(branchApiName)}APIVersionSet'
    versionSetDisplayName:'${functions.getFirstLetterUppercase(branchApiName)} API'
    subscriptionRequired: branchSubscriptionRequiredV1
    snippet: branchSnippet
    clientAppId: keyVault.getSecret('branchSeqClientAppId')
    clientAppSecret: keyVault.getSecret('branchSeqClientAppSecret')
    backendAppId: keyVault.getSecret('branchSeqBackendAppId')
    backendAppIdName: 'branchSeqScope'
    clientAppIdName: 'branchSeqClientAppId' 
    clientAppSecretName: 'branchSeqClientAppSecret'
    tokenEndpointUrlName: 'branchSeqTokenEndpointUrl'
    authorizationResourceName: 'Branch-Seq-AuthorizationServer'
    hostName: environment().authentication.loginEndpoint
    tenantId: '725cf569-8659-493f-ac10-d6ccd4c3ad92'
  }
  dependsOn: [
    apim
  ]
}


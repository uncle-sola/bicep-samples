import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'


@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')


@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)


resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vaultName
}


// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}


var pocSwaggerLink = 'http://lmssecurelinkapi.test.branch.local/swagger/v1/swagger.json'
var uatSwaggerLink = 'http://lmssecurelinkapi.test.branch.local/swagger/v1/swagger.json'
var tstSwaggerLink = 'http://lmssecurelinkapi.test.branch.local/swagger/v1/swagger.json'
var qatSwaggerLink = 'http://lmssecurelinkapi.test.branch.local/swagger/v1/swagger.json'
var prdSwaggerLink = 'http://lmssecurelinkapi.test.branch.local/swagger/v1/swagger.json'
var finalSwaggerLink = Environment == 'poc' ? pocSwaggerLink
  : Environment == 'tst' ? tstSwaggerLink
  : Environment == 'uat' ? uatSwaggerLink
  : Environment == 'qat' ? qatSwaggerLink
  : Environment == 'prd' ? prdSwaggerLink
  : 'unknown'

var linkFormat = 'openapi-link'

var policySnippet = loadTextContent('policy-snippets/lms-secure-link.xml')


var lmsSecureLinkApiV1 = 'v1'
var lmsSecureLinkSubscriptionRequiredV2 = 'false'
var lmsSecureLinkApiName = 'lms-secure-link'

module importLMSSecureLinkAPIV1 '../../modules/api-import/import-api-apim-oauth-backend-oauth.bicep' = if(contains(['poc','tst','uat'], Environment)) {
  name: '${Timestamp}-ImportLMSSecureLinkAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(lmsSecureLinkApiName)}-api-${lmsSecureLinkApiV1}'
    apiUrl: finalSwaggerLink
    apiPath: lmsSecureLinkApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(lmsSecureLinkApiName)}API ${lmsSecureLinkApiV1}'
    apiVersion: lmsSecureLinkApiV1
    productDescription: '${toUpper(lmsSecureLinkApiName)} Product'
    productDisplayName: '${toUpper(lmsSecureLinkApiName)} Product'
    productName: '${toUpper(lmsSecureLinkApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(lmsSecureLinkApiName)}APIVersionSet'
    versionSetDisplayName:'${functions.getFirstLetterUppercase(lmsSecureLinkApiName)} API'
    subscriptionRequired: lmsSecureLinkSubscriptionRequiredV2
    snippet: policySnippet

    clientAppId: keyVault.getSecret('lmsSecureClientAppId')
    clientAppSecret: keyVault.getSecret('lmsSecureClientAppSecret')
    backendAppId: keyVault.getSecret('lmsSecureBackendAppId')
    backendAppIdName: 'lmsSecureScope'
    clientAppIdName: 'lmsSecureClientAppId' 
    clientAppSecretName: 'lmsSecureClientAppSecret'
    tokenEndpointUrlName: 'lmsSecureTokenEndpointUrl'
    authorizationResourceName: 'LMS-Secure-AuthorizationServer'
    hostName: environment().authentication.loginEndpoint
    tenantId: tenant().tenantId
  }
  dependsOn: [
    apim
  ]
}

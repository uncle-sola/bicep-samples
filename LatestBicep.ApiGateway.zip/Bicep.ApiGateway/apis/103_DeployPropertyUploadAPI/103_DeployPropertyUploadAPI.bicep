import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'


@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')


@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)



// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}


var linkFormat = 'swagger-link-json'

var propUploadSnippet = loadTextContent('policy-snippets/property-upload.xml')


var pocSwaggerLink = 'http://propertyupload-api.test.branch.local/swagger/v1.0/swagger.json'
var tstSwaggerLink = 'http://propertyupload-api.test.branch.local/swagger/v1.0/swagger.json'
var uatSwaggerLink = 'http://propertyupload-api.test.branch.local/swagger/v1.0/swagger.json'
var qatSwaggerLink = 'http://propertyupload-api.test.branch.local/swagger/v1.0/swagger.json'
var prdSwaggerLink = 'http://propertyupload-api.test.branch.local/swagger/v1.0/swagger.json'

var finalSwaggerLink = Environment == 'poc' ? pocSwaggerLink
  : Environment == 'tst' ? tstSwaggerLink
  : Environment == 'uat' ? uatSwaggerLink
  : Environment == 'qat' ? qatSwaggerLink
  : Environment == 'prd' ? prdSwaggerLink
  : 'unknown'



var propUploadApiV1 = 'v1'
var propUploadSubscriptionRequiredV2 = 'false'
var propUploadApiName = 'property-upload'

module importPropUploadAPIV1 '../../modules/api-import/import-api-apim-oauth-no-backend-oauth.bicep' = if(contains(['poc','tst','uat'], Environment)) {
  name: '${Timestamp}-ImportPropertyUploadAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(propUploadApiName)}-api-${propUploadApiV1}'
    apiUrl: finalSwaggerLink
    apiPath: propUploadApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(propUploadApiName)}API ${propUploadApiV1}'
    apiVersion: propUploadApiV1
    productDescription: '${toUpper(propUploadApiName)} Product'
    productDisplayName: '${toUpper(propUploadApiName)} Product'
    productName: '${toUpper(propUploadApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(propUploadApiName)}APIVersionSet'
    versionSetDisplayName:'${functions.getFirstLetterUppercase(propUploadApiName)} API'
    subscriptionRequired: propUploadSubscriptionRequiredV2
    snippet: propUploadSnippet
  }
  dependsOn: [
    apim
  ]
}

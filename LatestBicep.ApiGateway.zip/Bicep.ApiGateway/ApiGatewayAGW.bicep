import * as resources from 'functions/project-resource-names.bicep'

@description('Location')
param Location string = resourceGroup().location

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string = subscription().subscriptionId

@description('App Gateway FrontEnd Private Ip')
param AppGatewayPrivateIP string

@description('wild card cert name')
param wildCardCertName string

@description('Sku Name')
@allowed([
  'Standard_v2'
  'WAF_v2'
])
param skuName string = 'WAF_v2'

@description('Sku tier')
@allowed([
  'Standard_v2'
  'WAF_v2'
])
param skuTier string = 'WAF_v2'

@description('Specifies the mode of the WAF policy.')
@allowed([
  'Detection'
  'Prevention'
])
param wafPolicyMode string = 'Prevention'

@description('Specifies the state of the WAF policy.')
@allowed([
  'Enabled'
  'Disabled '
])
param wafPolicyState string = 'Enabled'

@description('Specifies the maximum file upload size in Mb for the WAF policy.')
param wafPolicyFileUploadLimitInMb int = 100

@description('Specifies the maximum request body size in Kb for the WAF policy.')
param wafPolicyMaxRequestBodySizeInKb int = 128

@description('Specifies the whether to allow WAF to check request Body.')
param wafPolicyRequestBodyCheck bool = true

@description('Specifies the rule set type.')
param wafPolicyRuleSetType string = 'OWASP'

@description('Specifies the rule set version.')
param wafPolicyRuleSetVersion string = '3.2'

@description('Managed Identity Name for key vault user')
var managedIdentityKeyVaultSecretUser = resources.getManagedIdentityKeyVaultSecretUser(Region, Environment, Project)

@description('App Gateway Subnet Name')
var appGatewaySubnetName = resources.getAppGatewaySubnetName(Region, Environment, Project)

@description('App Gateway Frontend Public IP')
var agwPublicIpName = resources.getAppGatewayPublicIpName(Region, Environment, Project)


var echoV1PathMatch = '/echotest/v1/*'
var echoV2PathMatch = '/echotest/v2/*'
var echoV3PathMatch = '/echotest/v3/*'
var branchApiSeqV1PathMatch = '/branch-api-seq/v1/*'
var branchApiSeqV2PathMatch = '/branch-api-seq/v2/*'
var msgFrameworkV1PathMatch = '/msg-framework/v1/*'
var propertyUploadV1PathMatch = '/property-upload/v1/*'
var webFeedV1PathMatch = '/web-feed/v1/*'
var lmsSecureLinkV1PathMatch = '/lms-secure-link/v1/*'


var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

@description('Specifies the name of the app gateway')
var gatewayName = resources.getAppGatewayName(Region, Environment, Project)

@description('Specifies the name of the WAF policy')
var wafPolicyName = '${gatewayName}-WafPolicy'

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('App Gaeway Network ResourceGroup name')
var AGWNetworkRGName = resources.getAPIMNetworkRGName(Region, Environment, Project)

@description('log analytics workspace name')
var LogAnalyticsName = resources.getLogAnalyticsName(Region, Environment, Project) 

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

resource kv 'Microsoft.KeyVault/vaults@2024-04-01-preview' existing = {
  name: vaultName
}

resource kvCertSecret 'Microsoft.KeyVault/vaults/secrets@2024-04-01-preview' existing = {
  parent: kv
  name: wildCardCertName
}



resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: LogAnalyticsName
}

resource vnet 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  name: ExistingVnetName
}

resource agwIPAddress 'Microsoft.Network/publicIPAddresses@2022-11-01' existing = {
  scope: resourceGroup(AGWNetworkRGName)
  name: agwPublicIpName
}

resource apim 'Microsoft.ApiManagement/service@2023-09-01-preview' existing = {
  name: apimName
}
resource wafPolicy 'Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies@2024-01-01' = if(skuName == 'WAF_v2') {
  name: wafPolicyName
  location: Location
  properties: {
    customRules: [
      {
        name: 'BlockMe'
        priority: 1
        ruleType: 'MatchRule'
        action: 'Block'
        matchConditions: [
          {
            matchVariables: [
              {
                variableName: 'QueryString'
              }
            ]
            operator: 'Contains'
            negationConditon: false
            matchValues: [
              'blockme'
            ]
          }
        ]
      }
      {
        name: 'BlockEvilBot'
        priority: 2
        ruleType: 'MatchRule'
        action: 'Block'
        matchConditions: [
          {
            matchVariables: [
              {
                variableName: 'RequestHeaders'
                selector: 'User-Agent'
              }
            ]
            operator: 'Contains'
            negationConditon: false
            matchValues: [
              'evilbot'
            ]
            transforms: [
              'Lowercase'
            ]
          }
        ]
      }
    ]
    policySettings: {
      requestBodyCheck: wafPolicyRequestBodyCheck
      maxRequestBodySizeInKb: wafPolicyMaxRequestBodySizeInKb
      fileUploadLimitInMb: wafPolicyFileUploadLimitInMb
      mode: wafPolicyMode
      state: wafPolicyState
    }
    managedRules: {
      managedRuleSets: [
        {
          ruleSetType: wafPolicyRuleSetType
          ruleSetVersion: wafPolicyRuleSetVersion
        }
      ]
    }
  }
}


module appGateway './modules/network/application-gateway/main.bicep' = {
  name: '${Timestamp}-${gatewayName}'
  params: {
    name: gatewayName
    backendAddressPools: [
      {
        name: 'defaultBackEnd'
        properties: {
          backendAddresses: [
          ]
        }
      }      
      {
        name: 'gatewayBackEnd'
        properties: {
          backendAddresses: [
            {
              fqdn: apim.properties.privateIPAddresses[0]
            }
          ]
        }
      }
    ]
    capacity: 1
    autoscaleMinCapacity: 0
    autoscaleMaxCapacity: 5
    diagnosticSettings: [
      {
        name: 'logToAnalytics'
        logAnalyticsDestinationType: 'AzureDiagnostics'
        logCategoriesAndGroups: [
          {
            category: 'ApplicationGatewayAccessLog'
            enabled: true
          }
          {
            category: 'ApplicationGatewayPerformanceLog'
            enabled: true
          }
          {
            category: 'ApplicationGatewayFirewallLog'
            enabled: true
          }
        ]
        metricCategories: [
          {
            category: 'AllMetrics'
            enabled: true
          }
        ]
        workspaceResourceId: laWorkspace.id
      }
    ]
    backendHttpSettingsCollection: [
      {
        name: 'apim-gateway-https-setting'
        properties: {
          port: 443
          protocol: 'Https'
          cookieBasedAffinity: 'Disabled'
          hostName: '${toLower(Environment)}-apim.internal.connellsgroup.co.uk'
          pickHostNameFromBackendAddress: false
          requestTimeout: 300
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes', gatewayName, 'apim-gateway-probe')
          }
        }
      }
    ]
    firewallPolicyResourceId: skuName == 'WAF_v2' ? wafPolicy.id : null
    frontendIPConfigurations: [
      {
        name: 'appGwPublicFrontendIp'
        properties: {
          publicIPAddress: {
            id: agwIPAddress.id
          }
        }
      }
      {
        name: 'appGwPrivateFrontendIp'
        properties: {
          privateIPAllocationMethod: 'Static'
          privateIPAddress: AppGatewayPrivateIP
          subnet: {
            id: '${vnet.id}/subnets/${appGatewaySubnetName}'
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: 'port_443'
        properties: {
          port: 443
        }
      }
    ]
    gatewayIPConfigurations: [
      {
        name: 'appGatewayIpConfig'
        properties: {
          subnet: {
            id: '${vnet.id}/subnets/${appGatewaySubnetName}'
          }
        }
      }
    ]
    httpListeners: [
      {
        name: 'apim-listener-public'
        properties: {
          frontendIPConfiguration: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/frontEndIPConfigurations',
              gatewayName,
              'appGwPublicFrontendIp'
            )
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndPorts', gatewayName, 'port_443')
          }
          protocol: 'Https'
          requireServerNameIndication: false
          sslCertificate: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/sslCertificates',
              gatewayName,
              'starInternalConnellsGroupCoUk'
            )
          }
        }
      }
      {
        name: 'apim-listener-private'
        properties: {
          frontendIPConfiguration: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndIPConfigurations', gatewayName, 'appGwPrivateFrontendIp')
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndPorts', gatewayName, 'port_443')
          }
          protocol: 'Https'
          requireServerNameIndication: false
          sslCertificate: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/sslCertificates',
              gatewayName,
              'starInternalConnellsGroupCoUk'
            )
          }
        }
      }
    ]
    location: Location
    probes: [
      {
        name: 'apim-gateway-probe'
        properties: {
          protocol: 'Https'
          port: 443
          path: '/status-0123456789abcdef'
          interval: 30
          timeout: 120
          unhealthyThreshold: 8
          pickHostNameFromBackendHttpSettings: true
          minServers: 0
        }
      }
    ]
    urlPathMaps: [
      {
        name: 'urlPathMapPrivate'
        properties: {
          defaultBackendAddressPool: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendAddressPools',
              gatewayName,
              'defaultBackEnd'
            )
          }
          defaultBackendHttpSettings: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
              gatewayName,
              'apim-gateway-https-setting'
            )
          } 
          pathRules: [            
            {
              name: 'echoApiPathRuleV1'
              properties: {
                paths: [
                  echoV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV2'
              properties: {
                paths: [
                  echoV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV3'
              properties: {
                paths: [
                  echoV3PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV1'
              properties: {
                paths: [
                  branchApiSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV2'
              properties: {
                paths: [
                  branchApiSeqV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'msgFrameworkPathRuleV1'
              properties: {
                paths: [
                  msgFrameworkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'propertyUploadPathRuleV1'
              properties: {
                paths: [
                  propertyUploadV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'webFeedPathRuleV1'
              properties: {
                paths: [
                  webFeedV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'lmsSecureLinkPathRuleV1'
              properties: {
                paths: [
                  lmsSecureLinkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
          ]
        }
      }
      {
        name: 'urlPathMapPublic'
        properties: {
          defaultBackendAddressPool: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendAddressPools',
              gatewayName,
              'defaultBackEnd'
            )
          }
          defaultBackendHttpSettings: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
              gatewayName,
              'apim-gateway-https-setting'
            )
          } 
          pathRules: [            
            {
              name: 'echoApiPathRuleV1'
              properties: {
                paths: [
                  echoV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV2'
              properties: {
                paths: [
                  echoV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV3'
              properties: {
                paths: [
                  echoV3PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV1'
              properties: {
                paths: [
                  branchApiSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV2'
              properties: {
                paths: [
                  branchApiSeqV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'msgFrameworkPathRuleV1'
              properties: {
                paths: [
                  msgFrameworkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'propertyUploadPathRuleV1'
              properties: {
                paths: [
                  propertyUploadV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'webFeedPathRuleV1'
              properties: {
                paths: [
                  webFeedV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'lmsSecureLinkPathRuleV1'
              properties: {
                paths: [
                  lmsSecureLinkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
          ]
        }
      }
    ]
    requestRoutingRules: [
      {
        name: 'apim-routing-rule-public'
        properties: {
          ruleType: 'PathBasedRouting'
          priority: 1
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners', gatewayName, 'apim-listener-public')
          }
          urlPathMap: {
            id: resourceId('Microsoft.Network/applicationGateways/urlPathMaps', gatewayName, 'urlPathMapPublic')
          }
        }
      }
      {
        name: 'apim-routing-rule-private'
        properties: {
          ruleType: 'PathBasedRouting'
          priority: 10
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners', gatewayName, 'apim-listener-private')
          }
          urlPathMap: {
            id: resourceId('Microsoft.Network/applicationGateways/urlPathMaps', gatewayName, 'urlPathMapPrivate')
          }
        }
      }
    ]
    zones: []
    sku: skuTier
    tags: tags
    managedIdentities: {
      userAssignedResourceIds: [
        '/subscriptions/${subscription().subscriptionId}/resourceGroups/${resourceGroup().name}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${managedIdentityKeyVaultSecretUser}'
      ]
    }
    sslCertificates: [
      {
        name: 'starInternalConnellsGroupCoUk'
        properties: {
          keyVaultSecretId: kvCertSecret.properties.secretUri
        }
      }
    ]
    sslPolicyCipherSuites:[
      'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384'
      'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256'
      'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384'
      'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256'
    ]
    sslPolicyMinProtocolVersion:'TLSv1_2'
    sslPolicyType:'Custom'
  }
}

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [5.5.14](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.14) - TBD

### Fixed
* Moved keyVaultName and keyVaultSecretsFilter in Infrastructure pipeline documentation into the appropriate section (pipeline parameter).

## [5.5.13](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.13) - 2023-07-24

### Changed
* Added support to pass service connection to build bicep templates that are hosted in an Azure container registry.

## [5.5.12](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.12) - 2023-07-13

### Changed
* Added support for changing behaviour of character escaping within the token replace step.
* Added ability to force whatif step to run against a development environment.

## [5.5.11](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.11) - 2023-07-12

### Changed
* Migrated script only pipeline tests to run in Pester

## [5.5.10](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.10) - 2023-07-07

### Changed
* Fixed the structure and fixed the merge issue in readme file

## [5.5.9](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.9) - 2023-07-06

### Changed
* Added support for multple repository checkout to the common-scripts-deploy template. Available via the additionalRepositories parameter.

## [5.5.8](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.8) - 2023-07-04

### Changed
* Added New centralised script to allow pipelines consuming Pipeline.Common to be able to add specified subnet to KeyVault

## [5.5.7](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.7) - 2023-07-04

### Changed
* Updated pester integration test pipelines to use common-pester-tests-runner

## [5.5.6](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.6) - 2023-06-30

### Changed
* Converted AppReg and Infrastructure Integration tests to Pester tests.

## [5.5.5](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.5) - 2023-06-29

### Changed
* Split documentation into dedicated markdown files.
* Removed unused `additionalFilesTypePattern` from `common-infrastructure-deploy.yaml`
* Updated documentation on missing fields.

## [5.5.4](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.4) - 2023-06-23

### Changed
* Reverting wrapper script option until module is fully ready to use and Feed Project Permission settings is discussed with the team.

## [5.5.3](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.3) - 2023-06-22

### Fixed
* 'Add-AdAppRegistrations' failing when 'appRegManifestJsonPath' option is used
## [5.5.2](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.2) - 2023-06-21

### Changed
* Remove `Add-AdAppRegistrations.ps1` script from Pipeline Common Repo (It is now available as Module in defra common feed).
* Wrapper script with the same name `Add-AdAppRegistrations.ps1` (Support for backward compatibility). This will internally load Add-AdAppRegistrations 1.0.0 version from defra common feed

## [5.5.1](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.1) - 2023-06-19

### Fixed
* Script fails when 'more than one script is called and one of the script uses commonModulesToLoad feature'

## [5.5.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.5.0) - 2023-06-19

### Added
* introduced environment-level `keyVaultList` parameter for loading secrets from multiple KeyVaults

### Changed
* Updated documentation - added table of content and headings

## [5.4.10](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.10) - 2023-06-08

### Changed
* Identifier Uris Allow Array of Strings

## [5.4.9](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.9) - 2023-06-05

### Changed
* Set sequential lockBehavior in integration pipelines

## [5.4.8](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.8) - 2023-06-01

### Added
* added environment level agent overwrite (`privateAgentName`/`agentImage` parameters)

### Changed
* extended integration test pipeline wait timeout to 30 minutes
* updated documentation

## [5.4.7](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.7) - 2023-05-19

### Changed
* Changed strict regexp which was only allowing subscription names in a certain formats (e.g. AZD-CDO-DEV1 was allowed but AZD-DEV1 wasn't, to only check for the environment name in the subscription nam, so all variations containing an environment name are accepted.*
* Removed Get-FeatureToggleAutoSecretRenewal function and any references to it, as this isn't required any longer
* Pass in subscription name to Connect-AzAccount when connecting to a different tenant, so the connection is with the correct subscription.
* Updated Get-AppRegRenewalLinkedAppServicePrincipalId, so it selects the correct Service Principal to apply Key Vault permissions, based on the tenant the App Registration is in. The previous implementation using the subscription name was wrong and didn't work properly.
* Added logic to cater for Get-AzKeyVault and Set-AzKeyVaultAccessPolicy to accept subscriptionId, when the KeyVault is in a different subscription to the one used by the ADO Service Connection running the pipeline.
* Updated agent pool for Integration Tests to 'DEFRA-COMMON-windows2019-SSV3'. There DEFRA-TRD' agent pool is temperamental and is sometime causing integration tests to fail. The 'DEFRA-COMMON-windows2019-SSV3' seems more stable.

## [5.4.6](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.6) - 2023-05-15

### Changed
* Stages Depends On Any


## [5.4.5](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.5) - 2023-05-15

### Fixed
* issue with WhatIf doesn't seem to be giving us expected results in a pipeline, by replacing  Get-AzDeploymentWhatIfResult and the Get-AzResourceGroupDeploymentWhatIfResult with New-AzDeployment and New-AzResourceGroupDeployment using the 'whatif' switch parameter.

## [5.4.4](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.4) - 2023-04-27

### Changed
* Deploying an existing app-reg does not create a new secret
* Updated Add-AdAppRegistrations.ps1 script
* Setup Integration tests for for App-reg deploy script and covered below scenarios
    -  Duplicate Secret is not created for existing App-Reg already having Secret with the same name
    -  New Secret is created for existing App-Reg

## [5.4.3](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.3) - 2023-04-24

### Changed
* Alert rule name has a default **webapp_** prefix for webapps that don't have a _Purpose_ tag set on them
* Added description for webapp alerts

## [5.4.2](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.2) - 2023-04-20

### Changed
* Load userCustomVariables in Build stage
### Fixed
* Fix for Bug 176201: Env userCustomVariables are not loaded in Validate stage

## [5.4.1](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.1) - 2023-04-20

### Changed
* Enable KeyVault in different tenant (Defra Dev) when App Reg is in O365-DefraDev.
* Removed references to keyVaultInAnotherTenantFeatureToggle because it is now available in all tenants.
* Updated documentation

## [5.4.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.4.0) - 2023-04-17

### Changed
* Pipeline changes to execute a Function from package published in dedicated PowerShell feed
* Support of running InlineScript
* Updated integration tests
* Updated Documentation

## [5.3.1](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.3.1) - 2023-04-06

### Fixed
* Removed Env variable print task which is not working on some agents

## [5.3.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.3.0) - 2023-04-06

### Added
* whatif support for deploying resources at subscription scope

## [5.2.3](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.2.3) - 2023-04-05

### Changed
* Added check for resource group scope in whatif step.
* Added integration test to deploy resources on subscription scope.
* Updates excecuteintegrationtest.yml to include task to clean up resources created on subscription level.

## [5.2.2](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.2.2) - 2023-04-05

###
Merged PR 28028: Can load variable file at environment level for ScriptOnly Pipeline

Changes:
- added support for custom variables for script-only pipeline
- added integration test for script-only pipeline
- updated documentation

Related work items: #170721, #170726, #170727, #170728
## [5.2.1](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.2.1) - 2023-04-04

###
Merged PR 28186: Updated all env vars to uppercase to work across windows/linux

Updated all env vars to uppercase to work across windows/linux

Issue highlighted by Josh in Chemicals when the App Reg creation wasn't working properly for them on Linux and it was working for us on Windows.

Related work items: #171266
## [5.2.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.2.0) - 2023-03-31

### Changed
- Added custom variable file loading at an environmental level
- changed integration test
- updated documentation

## [5.1.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.1.0) - 2023-03-28

### Changed
* Added dynamic variable on environment level
* Exposed the dynamic variable at job level
* Added integration test to pass the exposed dynamic variable to arm/bicep template
* Updated documentation

## [5.0.7](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.7) - 2023-03-28

### Changed
* Updated placeholders for all linked SPNs except O365_DefraDev, which is awaiting a change request (CHG0063569).
* Enable keyvault in another tenant feature flag except if KeyVault is in Defra (Dev) and AAD App-Registration is in  O365_DefraDev.
* Updated code to take into consideration all scenarios of Key Vault in a different tenant detailed in the below table.

## [5.0.6](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.6) - 2023-03-24

### Changed
* added script for updating the latest tags for each release
* added scheduled pipeline for nightly tag update
* updated documentation

## [5.0.5](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.5) - 2023-03-22

### Changed
* O365_DefraDev Documentation Update

## [5.0.4](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.4) - 2023-03-17

### Changed
* Changes to include AZD-ARR-DEV2 (defradev tenant) and featureToggleAutoSecretRenewal

## [5.0.3](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.3) - 2023-03-17

### Added
* Added Microsoft hosted agent to ARM TTK  job

## [5.0.2](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.2) - 2023-03-09

### Changed
* set regionalVariableFiles pipeline parameter default value to empty list which doesn't enforce loading var files
* updated documentation


## [5.0.1](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.1) - 2023-03-06

### Changed
* Moved AAD App-Registration documentation to Add-AdAppRegistrations.md
* Added more details on the tenant and features

## [5.0.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v5.0.0) - 2023-03-03

### Fixed
* Fixed Script path issue in pipeline

## [4.2.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v4.2.0) - Release version 4.2.02023-02-16

### Changed
* Replace onboarding table with App-Reg internal notes:

  - Removed all OnBoarding table and manifest storage references.
  - Introduced 3 new functions to use notes instead of manifest:
     - Get-SecretRenewalNotes
     - Convert-AppToInternalNotesStructure - This converts the manifest json to a smaller structure with only the fields required by the SecretHandler App to process App Reg renewals, which gives more space for Notes and Secrets.
     - Resize-AppJsonForInternalNote - This is only called if the note data is more than 1024 characters long .  This reduces the size of the note and appends '...' to the end.

Related work items: #146396
## [4.1.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v4.1.0) - Release version 4.1.02023-01-31

### Changed
* Validate/Dryrun Template deployment before actual deployment
* Updated documentation

**Example pipeline run for TST env :**(Dependency flow : **DryRun -> WhatIf -> Deploy**)
![image.png](https://dev.azure.com/defragovuk/6fb34fa8-c7cf-46cc-96a3-1cde7a2fa7b2/_apis/git/repositories/a93b59e7-00f4-4a92-a01a-21af1801c245/pullRequests/24616/attachments/image.png)

**Example pipeline run for Dev env :** (No Dryrun for development environment)
![image (2).png](https://dev.azure.com/defragovuk/6fb34fa8-c7cf-46cc-96a3-1cde7a2fa7b2/_apis/git/repositories/a93b59e7-00f4-4a92-a01a-21af1801c245/pullRequests/24616/attachments/image%20%282%29.png)

Related work items: #107151
## [4.0.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v4.0.0) - 2023-01-19

### Changed
* Documentation updated for Multi-Region

## [3.2.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v3.2.0) - 2022-12-06

### Changed
* Added secretRenewalSpObject for credmanager apps in DefraCloud and Defra tenant
* featureToggle function updated to allow DefraCloud and Defra tenants

## [3.1.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v3.1.0) - 2022-09-21

### Added
* Add Support of Non RTL environment to ARM TTK

## [3.0.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v3.0.0) - 2022-08-15

### Removed
* The secret renewal feature is turned-off by default in the [PowerShell script itself](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?path=/PowerShellLibrary/Add-AdAppRegistrations.ps1&version=GB106855_Cant-use-global-variables-in-consumer-pipeline&line=9&lineEnd=10&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents). We have to turn-it-on only in our[ consumer app-reg example project](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.AppRegistration.Consumer.Example?path=/azure-pipelines/pipelines/app-registration.yaml).
We don't need to set the toggle in our pipeline-template and step-template because of that.

## [2.0.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v2.0.0) - 2022-07-11

### Fixed
* The variables.developmentEnvironment was always being set to Dev in the pipeline Validate display name and some of the Validate job>steps.  This was because the Consumer ( project ) variables were being pulled in at the wrong level ( Validation job level ).  We moved the variables in the validation job level to the Validation stage level and also added the 'environment' variable at the stage level.
This now results in all jobs giving correct results.  The ARM TTK job displays the correct environments and the Validation job now also uses the developmentEnvironment passed in by the Consumer or defaults to Dev if developmentEnvironment isn't set by the consumer.

## [1.2.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v1.2.0) - 2022-06-29

### Changed
* Rename the ARM based deployment pipeline-template of Defra.Pipeline.Common to `common-infrastructure-deploy.yaml
* Update any repos referencing it to use new name. i.e. Defra.AppRegistration.Common, Defra.AppRegistration.Consumer.Example

## [1.1.0](https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_git/Defra.Pipeline.Common?version=GTRelease-v1.1.0) - 2022-06-24

### Fixed
* Fix empty workingDirectory issue in filePathsForTransform in powershell.yaml
* Added conditional statement to check if the parameters.workingDirectory is not empty and to use either:
targetFileslocation: ${{ parameters.workingDirectory }}/${{ filePath }} OR targetFileslocation: ${{ filePath }}

[[_TOC_]]

# Devops CI/CD Templates

## Route to live deployment using ARM/Bicep Template

Documentation for infrastructure ARM/Bicep deployment pipeline can be found [here](docs/InfrastructureDeploy.md)

## Route to live deployment using scripts

Documentation for scripts only deployment pipeline can be found [here](docs/ScriptsOnlyDeploy.md)

# AAD App-Registration Creation, Renaming and Configuration

Documentation for AAD App-registration of this repository can be found [here](/PowerShellLibrary/docs/Add-AdAppRegistrations.md)

# PowerShell script library

Documentation for PowerShell script library of this repository can be found [here](PowerShellLibrary/README.md).

# Integration Test PR Trigger Workflow

The diagram below shows the Integration Test Workflow with 2 examples.  

![Integration Test PR Trigger Workflow](/docs/assets/images/PRWorkflow.png)

There are also scenarios where a common file used across both AppReg and Infrastructure will trigger both pipelines e.g. vars/common.yaml.
To view the branch policy and path filters, go to the below links:

https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_settings/repositories?repo=a93b59e7-00f4-4a92-a01a-21af1801c245&_a=policiesMid&refs=refs/heads/main&build=4316

https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_settings/repositories?repo=a93b59e7-00f4-4a92-a01a-21af1801c245&_a=policiesMid&refs=refs/heads/main&build=4317
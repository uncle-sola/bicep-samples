<#
    This script creates latest tags for each major realease in the repo.
    This script reads the Versioning information from the 'version.json' file
#>

function Get-LatestVersionByMajor($Major) {
    $listOfReleases = git tag -l
    $versions = $listOfReleases | Where-Object { $_ -match "^Release-v$Major.[0-9]+.[0-9]+$" } | ForEach-Object { [System.Version]::new($_.Substring(9)) }
    $ver = $versions | Sort-Object -Descending | Select-Object -First 1
    return $ver
}

function Test-IfTagPresent($tag) {
    $listOfReleases = git tag -l
    $result = $listOfReleases | Where-Object { $_ -match "^$tag$" } | Select-Object -First 1
    if ($result.count -eq 1) {
        return $true
    }
    else {
        return $false
    }
}

$versioningJsonPath = './continuous-delivery/version.json'

try {
    $versionInfo = Get-Content -Raw -Path $versioningJsonPath | ConvertFrom-Json
    if ([string]::IsNullOrEmpty($versionInfo.major) -or [string]::IsNullOrEmpty($versionInfo.minor)) {
        throw
    }
}
catch {
    throw "Version info missing in the file '$($versioningJsonPath)'. Error : $($_.Exception.Message)"
}


$latestReleaseVersion = Get-LatestVersionByMajor $versionInfo.major
# Sanity check for at least one tag
if ($null -eq $latestReleaseVersion) {
    throw "Can't find tags for Release v$i (based on version.json). Please make sure at least one tag exist for that major release."
}

# Remove latest tag only if present
$latestMajorTag = "Release-v$($latestReleaseVersion.Major)-latest"
if (Test-IfTagPresent $latestMajorTag) {
    Write-Host "Removing tag $latestMajorTag"
    git tag -d $latestMajorTag
}

# Make sure semantic version tag is present before tagging it as latest
$latestReleaseTag = "Release-v$($latestReleaseVersion.Major).$($latestReleaseVersion.Minor).$($latestReleaseVersion.Build)"
Write-Host "Tagging $latestReleaseTag as $latestMajorTag"
git tag -f $latestMajorTag $latestReleaseTag

git push --tags --force
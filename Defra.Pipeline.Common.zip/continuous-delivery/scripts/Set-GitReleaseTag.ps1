<#
    This script creates a tag in ADO repo using Semver scheme.
    This script reads the Versioning information from the 'version.json' file
    It then validates the data in Versioning.json file with the existing tag Version and creates the New Tag for release. 
    This script uses Repo and Branch in the context where pipeine is executing it.
#>


function Get-LatestVersion {

    #Get existing latest tag from git
    $listOfReleases = git tag -l

    $versions = $listOfReleases | Where-Object { $_ -match '^Release-v[0-9]+.[0-9]+.[0-9]+$' } | ForEach-Object { [System.Version]::new($_.Substring(9)) } 
    $ver = $versions | Sort-Object -Descending | Select-Object -First 1
    return $ver
    
}

$versioningJsonPath = './continuous-delivery/version.json'

$prevTagVersion = @{
    Major = ""; Minor = ""; Patch = ""
}

$newTagVersion = @{
    Major = ""; Minor = ""; Patch = ""
}

try {
    #Get New Tag Info
    $versionInfo = Get-Content -Raw -Path $versioningJsonPath | ConvertFrom-Json  
    Write-Output $versionInfo
    if ([string]::IsNullOrEmpty($versionInfo.major) -or [string]::IsNullOrEmpty($versionInfo.minor)) {
        throw
    }
    $newTagVersion.Major = $versionInfo.major
    $newTagVersion.Minor = $versionInfo.minor
    $newTagVersion.Patch = 0 #intiliaze with the default
}
catch {
    throw "Version info missing in the file '$($versioningJsonPath)'. Error : $($_.Exception.Message)"
}

$latestVersion = Get-LatestVersion
Write-Output "Existing Latest Tag name : $($latestVersion)"

if ($latestVersion) {
    $prevTagVersion.Major = $latestVersion.Major
    $prevTagVersion.Minor = $latestVersion.Minor
    $prevTagVersion.Patch = $latestVersion.Build    

    #Validate and Set New Tag Info
    $versionChangePrintMessage = ""
    #MAJOR
    if ($prevTagVersion.Major -ne $newTagVersion.Major) {
        if (([int]$newTagVersion.Major - [int]$prevTagVersion.Major) -eq 1) {

            if ([int]$newTagVersion.Minor -ne 0) {
                throw "Minor must be set to 0 when Major is updated. Current Minor value in the file is '$($newTagVersion.Minor)'. Please update the 'version.json' file with the correct version details."
            }

            #Set Minor and patch version to 0 when Major is changed
            $newTagVersion.Minor = "0"
            $newTagVersion.Patch = "0"
            $versionChangePrintMessage = "Updating 'Major' number. New Major value : $($newTagVersion.Major)"
        }
        else {
            throw "New version of Major must be exactly increament by 1 from the previous version. Existing Tag Major value: $($prevTagVersion.Major), New Tag Major value: $($newTagVersion.Major). Please update the 'version.json' file with the correct version details."
        }
    }
    #MINOR
    elseif ($prevTagVersion.Minor -ne $newTagVersion.Minor) {
        if (([int]$newTagVersion.Minor - [int]$prevTagVersion.Minor) -eq 1) {
            #Set patch version to 0 when Minor is changed
            $newTagVersion.Patch = "0"
            $versionChangePrintMessage = "Updating 'Minor' number. New Minor value : $($newTagVersion.Minor)"
        }
        else {
            throw "New version of Minor must be exactly increament by 1 from the previous version. Existing Tag Minor value: $($prevTagVersion.Minor), New Tag Minor value: $($newTagVersion.Minor). Please update the 'version.json' file with the correct version details."
        }
    }
    #PATCH 
    else {
        #Increase the patch number
        $newTagVersion.Patch = [int]$prevTagVersion.Patch + 1
        $versionChangePrintMessage = "Updating 'Patch' number. New Patch value : $($newTagVersion.Patch)"
    }
}

#Create Tag and Push
$tagName = "Release-v$($newTagVersion.Major).$($newTagVersion.Minor).$($newTagVersion.Patch)"
$tagMessage = "Release Version $($newTagVersion.Major).$($newTagVersion.Minor).$($newTagVersion.Patch) - ADO Automatic"
Write-Output "Creating Tag '$($tagName)', Version change details = $($versionChangePrintMessage)"
git tag -a $tagName -m $tagMessage
git push origin $tagName
Write-Output "Tag Created Successfully. Tag Name : '$($tagName)', Tag Message : '$($tagMessage)'"
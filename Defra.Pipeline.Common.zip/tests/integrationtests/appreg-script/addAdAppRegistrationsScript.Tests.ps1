param(
    [Parameter(Mandatory = $true)]
    [string]$SourceBranch
)

BeforeAll {
    . $PSScriptRoot/../helper/pesterTestHelper.ps1

    Connect-MicrosoftGraph

    $existingConsumerAppToTest = 'ExistingAppReg01'
    $newAppRegWithIdentifierUrisString = 'NewAppRegWithIdentifierUrisString01'
    $newAppRegWithIdentifierUrisArray = 'NewAppRegWithIdentifierUrisArray01'
    $existingSecretDisplayName = 'ExistingSecret01'
    $newSecretDisplayName = 'NewSecret01'
    $keyVaultName = 'DEVCDOINFKV1060'

    # Ensure we are starting from a clean slate, by removing any data that wasn't cleaned due to failures
    Remove-ConsumerADApps -ConsumerAppRegsToRemove $existingConsumerAppToTest,$newAppRegWithIdentifierUrisString,$newAppRegWithIdentifierUrisArray
    Remove-IntTestConsumerAppSecrets -KeyVaultName $keyVaultName -SecretsToRemove "$($existingSecretDisplayName)-1", "$($newSecretDisplayName)-1"

    Set-ExistingConsumerAppwithSecrets -ExistingConsumerAppToTest $existingConsumerAppToTest

    $vaultName = 'DEVCDOINFKV1005'
    $secretName = 'AzureDevOpsRESTApiToken'
    $azureDevOpsRestApiToken = Get-AzKeyVaultSecret -VaultName $vaultName -Name $secretName -AsPlainText
    Invoke-IntegrationTestPipeline -sourceBranch $SourceBranch -personalAccessToken $azureDevOpsResTApiToken -orgName 'defragovuk' -projectName 'DEFRA-DEVOPS-COMMON' -pipelineStateCheckMaxWaitTimeOutInSec 5200 -buildDefinitionId 3575
    
}

Describe 'AddAdAppRegistrations validation tests' -Tag Integration {
    Context 'Validate new changes to AddAdAppRegistrations script' {
          
        It 'should not create new secret for existing App Registration' {  
            $duplicateAppRegSecretExists = Assert-DuplicateSecretIsNotCreatedForExistingAppReg -ConsumerAppToTest $existingConsumerAppToTest -SecretDisplayName $existingSecretDisplayName                                 
            $duplicateAppRegSecretExists | Should -Be $false
        }

        It 'should create new secret for existing App Registration' {
            $secretIsCreatedForExistingAppReg = Assert-NewSecretIsCreatedForExistingAppReg -ConsumerAppToTest $existingConsumerAppToTest -SecretDisplayName $newSecretDisplayName                                   
            $secretIsCreatedForExistingAppReg | Should -Be $true
        }

        It 'should find one identifierUri for App Registration' { 
            $oneIdentifierUriExists = Assert-AppRegCreatedWithidentifierUris -ConsumerAppToTest $newAppRegWithIdentifierUrisString -ExpectedIdentifierUrisCount 1                                  
            $oneIdentifierUriExists | Should -Be $true
        }
       
        It 'should find two identifierUri for App Registration' { 
            $twoIdentifierUriExists = Assert-AppRegCreatedWithidentifierUris -ConsumerAppToTest $newAppRegWithIdentifierUrisArray -ExpectedIdentifierUrisCount 2                                  
            $twoIdentifierUriExists | Should -Be $true
        }

        AfterAll {
            Remove-ConsumerADApps -ConsumerAppRegsToRemove $existingConsumerAppToTest,$newAppRegWithIdentifierUrisString,$newAppRegWithIdentifierUrisArray
            Remove-IntTestConsumerAppSecrets -KeyVaultName $keyVaultName -SecretsToRemove "$($existingSecretDisplayName)-1", "$($newSecretDisplayName)-1"
        } 
    }
}
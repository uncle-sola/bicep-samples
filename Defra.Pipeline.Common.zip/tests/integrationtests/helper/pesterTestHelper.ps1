Function Invoke-IntegrationTestPipeline {
    Param (
        [Parameter(Mandatory = $true, HelpMessage = 'PR Build branch name. e.g. refs/pull/18011/merge')]
        [string]$sourceBranch,

        [Parameter(Mandatory = $true, HelpMessage = 'The personal access token used to authorize devops rest api requests')]
        [String]$personalAccessToken,

        [Parameter(Mandatory = $true, HelpMessage = 'Devops Orgnization Name')]
        [string]$orgName,

        [Parameter(Mandatory = $true, HelpMessage = 'Devops Project Name')]
        [string]$projectName,

        [Parameter(Mandatory = $true, HelpMessage = 'Max Wait TimeOut for IntegrationTestpipeline. Default to 10 minutes.')]
        [int]$pipelineStateCheckMaxWaitTimeOutInSec,

        [Parameter(Mandatory = $true, HelpMessage = 'Pipeline Build Definition ID.')]
        [int]$buildDefinitionId
    )

    Write-Verbose -Message "PR Source Branch: $($sourceBranch)" -Verbose

    $azureDevopsProjectBaseUrl = "https://dev.azure.com/$($orgName)/$($projectName)";

    #Prepare Header: Base64-encodes the Personal Access Token (PAT) appropriately
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes((":{0}" -f $personalAccessToken)))
    $headers = @{Authorization = ("Basic {0}" -f $base64AuthInfo) }

    #Trigger Integration Test Pipeline
    $uriPostRunPipeline = "$($azureDevopsProjectBaseUrl)/_apis/pipelines/$($buildDefinitionId)/runs?api-version=6.0"
    $runPipelineRequestBodyWithDefaultConfig = '{
                    "stagesToSkip": [],
                    "resources": {
                        "repositories": {
                            "PipelineCommon": {
                                "refName": "refs/heads/main",
                                "version": ""
                            },
                            "self": {
                                "refName": "refs/heads/main"
                            }
                        }
                    },
                    "variables": {}
                }' | ConvertFrom-Json

    $runPipelineRequestBodyWithDefaultConfig.resources.repositories.PipelineCommon.refName = $sourceBranch
    $runPipelineRequestBodyWithDefaultConfig.resources.repositories.self.refName = $sourceBranch
    $requestBodyJson = $runPipelineRequestBodyWithDefaultConfig | ConvertTo-Json -Depth 100
    Write-Verbose -Message "requestBodyJson: $($requestBodyJson)" -Verbose

    Write-Verbose -Message "Triggering Integration test pipeline. uriPostRunPipeline: $($uriPostRunPipeline)" -Verbose
    $pipelineRun = Invoke-RestMethod -Uri $uriPostRunPipeline -Method Post -Headers $headers -Body $requestBodyJson -ContentType "application/json"
    Write-Verbose -Message "PipelineRun run $($pipelineRun.id) triggered sucessfully. Current state: $($pipelineRun.state)" -Verbose
    $piplineRunResult = [string]::Empty

    # Get the Pipeline Run status and loop until state is inProgress.
    $sleepPeriodinSec = 60
    $totalSleepinSec = 0
    do {
        sleep 60
        $totalSleepinSec += $sleepPeriodinSec;
        Write-Verbose -Message "Slept for $($sleepPeriodinSec) sec. TotalSleep so far $($totalSleepinSec) sec." -Verbose

        $gerPipelineRunStateUri = "$($azureDevopsProjectBaseUrl)/_apis/pipelines/$($buildDefinitionId)/runs/$($pipelineRun.id)?api-version=6.0"
        $pipelinerundetails = Invoke-RestMethod -Uri $gerPipelineRunStateUri -Method Get -Headers $headers
        $currentState = $pipelinerundetails.state
        Write-Verbose -Message "Current state of pipeline runId $($pipelineRun.id): $($currentState)" -Verbose
        Write-Verbose -Message "Running state check..." -Verbose
        if ($currentState -ne "inProgress") {
            $piplineRunResult = $pipelinerundetails.result
            Write-Verbose -Message "Current state: $($currentState)" -Verbose
            break
        }
    } until ($currentState -ne "inProgress" -or $totalSleepinSec -ge $pipelineStateCheckMaxWaitTimeOutInSec)

    #report pipeline status
    if ($piplineRunResult -eq "succeeded") {
        $successmsg = "$($pipelinerundetails.pipeline.name) pipeline with runId $($pipelinerundetails.id) has completed successfully."
        Write-Verbose -Message "$($successmsg)" -Verbose
    }
    else {
        if ($totalSleepinSec -ge $pipelineStateCheckMaxWaitTimeOutInSec) {
            $errorMsg += "Excecution of Integration tests has stopped due to max timeout of $($pipelineStateCheckMaxWaitTimeOutInSec) sec."
        }
        else {
            $errormsg = "$($pipelinerundetails.pipeline.name) pipeline with runId $($pipelinerundetails.id) has failed."
        }
        Write-Verbose -Message "##vso[task.logissue type=error]$($errormsg)" -Verbose
        exit 1
    }
}

Function Remove-ResourceGroup {
    Param (
        [Parameter(Mandatory = $true, HelpMessage = 'Resourse group to be deleted')]
        [string]$ResourceGroupName
    )

    Write-Host "Start : Deleting Resource group : $($ResourceGroupName)"
    Remove-AzResourceGroup -Name $ResourceGroupName -Force -ErrorAction Ignore
    Write-Host "End : Deleted Resource group : $($ResourceGroupName)"
}

Function Assert-DuplicateSecretIsNotCreatedForExistingAppReg {
    param (
        [string]$ConsumerAppToTest,
        [string]$SecretDisplayName
    )

    $SecretThatShouldNotExit = "$($SecretDisplayName) - ADO automatic"

    $consumerApp = Get-MgApplication -Filter "displayName eq '$($ConsumerAppToTest)'"
    $appRegSecretExists = ($consumerApp.passwordCredentials | Where-Object { ($_.DisplayName -eq $($SecretThatShouldNotExit)) }).Count -gt 0

    return $appRegSecretExists
}

Function Connect-MicrosoftGraph {
    if (-not (Get-Module -ListAvailable -Name 'Microsoft.Graph')) {
        Write-Host "Microsoft.Graph Module does not exists. Installing now.."
        Install-Module Microsoft.Graph -Force
        Write-Host "Microsoft.Graph Installed Successfully."
    }
    $accessToken = (Get-AzAccessToken -Resource 'https://graph.microsoft.com').Token
    Connect-MgGraph -AccessToken $accessToken
}

Function Set-ExistingConsumerAppwithSecrets {
    Param(
        [string]$ExistingConsumerAppToTest
    )

    $existingSecretName = "ExistingSecret01";

    Write-Output "Creating Application $($ExistingConsumerAppToTest)"
    $application = New-MgApplication -DisplayName $ExistingConsumerAppToTest `
        -Description 'Used in integration test to test existing consumer app reg having one existing secret' `
        -SignInAudience 'AzureADMyOrg'

    Write-Output "Adding app-reg secret $($existingSecretName)"
    $appPasswordCredential = @{
        DisplayName   = $existingSecretName
        StartDateTime = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        EndDateTime   = (Get-Date).ToUniversalTime().AddDays(210).ToString("yyyy-MM-ddTHH:mm:ssZ")
    }

    $secret = Add-MgApplicationPassword -ApplicationId $application.Id -PasswordCredential $appPasswordCredential

}

Function Assert-NewSecretIsCreatedForExistingAppReg {
    param (
        [string]$ConsumerAppToTest,
        [string]$SecretDisplayName
    )

    $SecretThatShouldNotExit = "$($SecretDisplayName) - ADO automatic"

    $consumerApp = Get-MgApplication -Filter "displayName eq '$($ConsumerAppToTest)'"
    $appRegSecretExists = ($consumerApp.passwordCredentials | Where-Object { ($_.DisplayName -eq $($SecretThatShouldNotExit)) }).Count -gt 0

    return $appRegSecretExists

}

Function Assert-AppRegCreatedWithidentifierUris {
    param (
        [string]$ConsumerAppToTest,
        [int]  $ExpectedIdentifierUrisCount
    )

    $consumerApp = Get-MgApplication -Filter "displayName eq '$($ConsumerAppToTest)'"

    $appIdentifierUrisExit = ($consumerApp.identifierUris.Count -eq $ExpectedIdentifierUrisCount)

    return $appIdentifierUrisExit

}

Function Remove-ConsumerADApps {
    param (
        [string[]]$ConsumerAppRegsToRemove
    )

    Write-Host "Consumer applications data cleanup Started."

    foreach ($app in $ConsumerAppRegsToRemove) {
        $consumerApps = Get-MgApplication -Filter "displayName eq '$($app)'"
        if ($consumerApps) {
            foreach ($consumerApp in $consumerApps) {
            Write-Host "Removing $($app) application.."
            Remove-MgApplication -ApplicationId $consumerApp.Id
            Write-Host "Removed $($app) application."
            Write-Host "=================================================================================="
        }
    }
    }

}

function Remove-IntTestConsumerAppSecrets {
    param (
        [string] $KeyVaultName,
        [string[]] $SecretsToRemove
    )

    #Remove Keyvault Secrets
    foreach ($secret in $SecretsToRemove) {
        Write-Host "Removing $($secret) secret from $($KeyVaultName)"
        Remove-AzKeyVaultSecret -VaultName $KeyVaultName -Name $secret -PassThru -Force -ErrorAction Ignore
        Write-Host "Removed $($secret) secret"
        Write-Host "=================================================================================="
    }

}
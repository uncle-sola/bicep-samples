param(
    [Parameter(Mandatory = $true)]
    [string]$SourceBranch
)

Describe 'Common ScriptsOnly Pipeline Deploy Integration Tests' -Tag Integration {

    BeforeAll {
        $lookupPath = "$PSScriptRoot/../../../"
        $fileTramsformingPath = "$PSScriptRoot/../../../tests/integrationtests/test-files"
        $lookupSting = 'AZD-CDO-DEV1'
    }

    Context 'Supported script types' {

        It 'should support running Powershell tasks' {
            "$lookupPath/Powershell.txt" | Should -FileContentMatch $lookupSting
        }

        It 'should support running AzurePowershell tasks' {
            "$lookupPath/AzurePowershell.txt" | Should -FileContentMatch $lookupSting
        }

        It 'should support running AzCli tasks' {
            "$lookupPath/AzCli.txt" | Should -FileContentMatch $lookupSting
        }
    }

    Context 'File transformations' {

        It 'should support JSON file token replacement' {
            "$fileTramsformingPath/replaceTokenInFile.json" | Should -FileContentMatch $lookupSting
        }

        It 'should support XML file token replacement' {
            "$fileTramsformingPath/replaceTokenInFile.xml" | Should -FileContentMatch $lookupSting
        }

        It 'should not replace tokens with misconfifigured prefix/suffix in JSON' {
            "$fileTramsformingPath/dontreplaceTokenInFile.json" | Should -Not -FileContentMatch $lookupSting
        }

        It 'should not replace tokens with misconfifigured prefix/suffix in XML' {
            "$fileTramsformingPath/dontreplaceTokenInFile.xml" | Should -Not -FileContentMatch $lookupSting
        }

        It 'should support wildcard JSON files token replacement' {
            Get-ChildItem -Path "$fileTramsformingPath/replaceTokenFiles/" -Include *.json | Foreach-Object { Should -FileContentMatch $lookupSting }
        }

        It 'should support wildcard XML files token replacement' {
            Get-ChildItem -Path "$fileTramsformingPath/replaceTokenFiles/" -Include *.xml | Foreach-Object { Should -FileContentMatch $lookupSting }
        }
    }

    Context 'Custom variables' {

        It 'should have variable varName defined' {
            $env:varName | Should -Be "test"
        }

        It 'should have variable chicken.mcNugget.sauce defined' {
            $env:chicken_mcNugget_sauce | Should -Be "szechuan"
        }

        It 'should have variable character defined' {
            $env:character | Should -Be "Pickle Rick"
        }
    }

}



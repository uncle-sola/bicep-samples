<#
  .SYNOPSIS
  Runs pester integration tests.

  .DESCRIPTION
  The test-runner.ps1 script creates the pester container which is
  used in pester configuration object to enable advanced configurations
  for running tests using Invoke-Pester.

  .PARAMETER TestPath
  Specifies the path to the test files.

  .PARAMETER Tags
  Specifies the tags used in pester tests to identify the type of test.
  For Ex: Unit, Integration, Regression, Smoke. It is a comma delimited list

  .PARAMETER OutputFile
  Specifies the name and path where Invoke-Pester will save formatted test results log file.
  The path must include the location and name of the folder and file name with the xml extension.
  If this path is not provided, no log will be generated.

  .PARAMETER Data
  Specifies a hashtable with parameter-values that should be used during the execution of the test container.

  .EXAMPLE
  PS> .\test-runner.ps1 -TestPath 'tests/integrationtests/certificateAuthority.Tests.ps1'
  -Tags 'Integration'
  -OutputFile 'tests/integrationtests/test-results-1.xml'
  -Data @{CentralKeyvaultName   = "TSTCDOINFKV1011"; CertificateIssuerName = "DigiCertIssuer"}
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory = $false)]
    [string]$TestPath = './',
    [Parameter(Mandatory = $false)]
    [string]$Tags = 'Unit',
    [Parameter(Mandatory = $false)]
    [string]$OutputFile = './test-results.xml',
    [Parameter(Mandatory = $true)]
    [hashtable]$Data
)

$container = New-PesterContainer -Path $TestPath -Data $Data

Import-Module Pester

$configuration = [PesterConfiguration]@{
    Run        = @{
        Exit      = $true
        Container = $container
        PassThru  = $true
        Throw     = $true
    }
    Filter     = @{
        Tag = $Tags.Split(",")
    }
    Output     = @{
        Verbosity = 'Detailed'
    }
    TestResult = @{
        Enabled      = $true
        OutputFormat = "NUnitXml"
        OutputPath   = $OutputFile
    }
    Should     = @{
        ErrorAction = 'Continue'
    }
}

Invoke-Pester -Configuration $configuration

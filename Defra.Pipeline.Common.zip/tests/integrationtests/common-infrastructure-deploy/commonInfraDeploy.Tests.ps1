param(
    [Parameter(Mandatory = $true)]
    [string]$SourceBranch
)

BeforeAll {
    . $PSScriptRoot/../helper/pesterTestHelper.ps1

    $vaultName = 'DEVCDOINFKV1005'
    $secretName = 'AzureDevOpsRESTApiToken'
    $azureDevOpsRestApiToken = Get-AzKeyVaultSecret -VaultName $vaultName -Name $secretName -AsPlainText
    Invoke-IntegrationTestPipeline -sourceBranch $SourceBranch -personalAccessToken $azureDevOpsResTApiToken -orgName 'defragovuk' -projectName 'DEFRA-DEVOPS-COMMON' -pipelineStateCheckMaxWaitTimeOutInSec 5200 -buildDefinitionId 1997
    
}

Describe 'Common Infra Deploy Dev primary region Integration Tests' -Tag Integration {
    Context 'Validate KeyVault and Storage Account deployed to northeurope' {
        BeforeAll {  
            $bicepSubscriptionScopeRgName = 'devinttestssrgp1001'
            $resourceGroupName = "devinttestrgp1001"
            $keyVaultName = "devnorthkv1010"
            $storageAccountName = "devnorthsa1010"
            $region = "northeurope"
            $keyVault = Get-AzKeyVault -ResourceGroupName $resourceGroupName -VaultName $keyVaultName -ErrorAction Ignore            
            $storage = Get-AzStorageAccount -ResourceGroupName $resourceGroupName -Name $storageAccountName -ErrorAction Ignore
            $bicepSubscriptionScopeRg = Get-AzResourceGroup -Name $bicepSubscriptionScopeRgName -Location $region -ErrorAction Ignore
        }
          
        It 'should return a KeyVault resource location' {                                   
            $keyVault.Location | Should -Not -BeNullOrEmpty
        }

        It 'should be deployed to the correct KeyVault region (north europe)' {                                   
            $keyVault.Location | Should -Be $region
        }

        It 'should return a Storage resource location' {                                   
            $storage.Location | Should -Not -BeNullOrEmpty
        }
       
        It 'should be deployed to the correct Storage region (north europe)' {                                   
            $storage.Location | Should -Be $region
        }

        It 'should return a resource group in Dev northeurope' {
            $bicepSubscriptionScopeRg | Should -Not -BeNullOrEmpty 
        }

        AfterAll {
            Remove-ResourceGroup -ResourceGroupName $resourceGroupName
            Remove-ResourceGroup -ResourceGroupName $bicepSubscriptionScopeRgName
        } 
    }
}

Describe 'Common Infra Deploy Dev secondary region Integration Tests' -Tag Integration {
    Context 'Validate KeyVault and Storage Account are not deployed to westeurope' {
        BeforeAll {  
            $resourceGroupName = "devinttestrgp1201"
            $keyVaultName = "devwestkv1211"
            $storageAccountName = "devwestsa1211"
            $region = "westeurope"
            $keyVault = Get-AzKeyVault -ResourceGroupName $resourceGroupName -VaultName $keyVaultName -ErrorAction Ignore            
            $storage = Get-AzStorageAccount -ResourceGroupName $resourceGroupName -Name $storageAccountName -ErrorAction Ignore
                 
        }
          
        It 'should not return a KeyVault resource location' {                                   
            $keyVault.Location | Should -BeNullOrEmpty
        }

        It 'should not be deployed to the KeyVault region (westeurope)' {                                   
            $keyVault.Location | Should -Not -Be $region
        }

        It 'should not return a Storage resource location' {                                   
            $storage.Location | Should -BeNullOrEmpty
        }
       
        It 'should not be deployed to the Storage region (westeurope)' {                                   
            $storage.Location | Should -Not -Be $region
        }

        It 'should not return a resource group in Dev westeurope' {
            $bicepSubscriptionScopeRgName = 'devinttestssrgp1201'
            $bicepSubscriptionScopeRg = Get-AzResourceGroup -Name $bicepSubscriptionScopeRgName -Location $region -ErrorAction Ignore
            $bicepSubscriptionScopeRg | Should -BeNullOrEmpty 
        }

        AfterAll {
            Remove-ResourceGroup -ResourceGroupName $resourceGroupName
        } 
    }
}

Describe 'Common Infra Deploy Tst primary region Integration Tests' -Tag Integration {
    Context 'Validate KeyVault and Storage Account deployed to northeurope' {
        BeforeAll {
            Set-AzContext -SubscriptionId AZD-CDO-TST1
            $bicepSubscriptionScopeRgName = 'tstinttestssrgp1001'
            $resourceGroupName = "tstinttestrgp1001"
            $keyVaultName = "tstnorthkv1010"
            $storageAccountName = "tstnorthsa1010"
            $region = "northeurope"
            $keyVault = Get-AzKeyVault -ResourceGroupName $resourceGroupName -VaultName $keyVaultName -ErrorAction Ignore            
            $storage = Get-AzStorageAccount -ResourceGroupName $resourceGroupName -Name $storageAccountName -ErrorAction Ignore
            $bicepSubscriptionScopeRg = Get-AzResourceGroup -Name $bicepSubscriptionScopeRgName -Location $region -ErrorAction Ignore      
        }
          
        It 'should return a KeyVault resource location' {                                   
            $keyVault.Location | Should -Not -BeNullOrEmpty
        }

        It 'should be deployed to the correct KeyVault region (north europe)' {                                   
            $keyVault.Location | Should -Be $region
        }

        It 'should return a Storage resource location' {                                   
            $storage.Location | Should -Not -BeNullOrEmpty
        }
       
        It 'should be deployed to the correct Storage region (north europe)' {                                   
            $storage.Location | Should -Be $region
        }

        It 'should return a resource group in Tst northeurope' {
            $bicepSubscriptionScopeRg | Should -Not -BeNullOrEmpty 
        }

        AfterAll{
            Remove-ResourceGroup -ResourceGroupName $resourceGroupName
            Remove-ResourceGroup -ResourceGroupName $bicepSubscriptionScopeRgName
        } 
    }
}

Describe 'Common Infra Deploy Tst secondary region Integration Tests' -Tag Integration {
    Context 'Validate KeyVault is not deployed and Storage Account is deployed to westeurope' {
        BeforeAll {  
            $bicepSubscriptionScopeRgName = 'tstinttestssrgp1201'
            $resourceGroupName = "tstinttestrgp1201"
            $keyVaultName = "tstwestkv1211"
            $storageAccountName = "tstwestsa1211"
            $region = "westeurope"
            $keyVault = Get-AzKeyVault -ResourceGroupName $resourceGroupName -VaultName $keyVaultName -ErrorAction Ignore            
            $storage = Get-AzStorageAccount -ResourceGroupName $resourceGroupName -Name $storageAccountName -ErrorAction Ignore
            $bicepSubscriptionScopeRg = Get-AzResourceGroup -Name $bicepSubscriptionScopeRgName -Location $region -ErrorAction Ignore      
        }
          
        It 'should not return a KeyVault resource location' {                                   
            $keyVault.location | Should -BeNullOrEmpty
        }

        It 'should not be deployed to the KeyVault region (westeurope)' {                                   
            $keyVault.Location | Should -Not -Be $region
        }

        It 'should return a Storage resource location' {                                   
            $storage.Location | Should -Not -BeNullOrEmpty
        }
       
        It 'should be deployed to the correct Storage region (westeurope)' {                                   
            $storage.Location | Should -Be $region
        }

        It 'should return a resource group in Tst westeurope' {
            $bicepSubscriptionScopeRg | Should -Not -BeNullOrEmpty 
        }

        AfterAll{
            Remove-ResourceGroup -ResourceGroupName $resourceGroupName
            Remove-ResourceGroup -ResourceGroupName $bicepSubscriptionScopeRgName
            Clear-AzContext -Force
        } 
    }
}
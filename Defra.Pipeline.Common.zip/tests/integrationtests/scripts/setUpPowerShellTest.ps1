<#
 This script sets up a basic Powershell test by adding the Subscription name to a file
 which will be tested later by the runTests.ps1 script.
#>

Param(
    [string]$ScriptType,
    [string]$ServiceConnectionName
)

Write-Host "Setting up PowersShell Test"

echo $ServiceConnectionName | Out-File -FilePath .\${ScriptType}.txt

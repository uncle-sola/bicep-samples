<#
 This script sets up a basic Azure Powershell test by adding the Subscription name to a file
 which will be tested later by the runTests.ps1 script.
#>

Param(
    [string]$ScriptType
)

Write-Host "Setting up Azure Powershell Test"

(Get-AzContext).Subscription.Name > .\${ScriptType}.txt
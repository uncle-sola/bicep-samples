param(
    [Parameter(Mandatory = $true)]
    [string]$DummyParameter
)

Write-Output "Inside consumer script. DummyParameter is $DummyParameter"

Write-Output "Calling Get-FirstHello function of GetHelloScript common module."
Get-FirstHello
Write-Output "Executed Get-FirstHello function of GetHelloScript common module."
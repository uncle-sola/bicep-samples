<#
 Placeholder script to display any message
#>

Param(
    [string]$message = "HelloWorld from the message.ps1"
)

Write-Host "$message"

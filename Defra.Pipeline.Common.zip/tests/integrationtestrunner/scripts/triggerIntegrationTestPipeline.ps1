<#
 This script triggers Integration test pipelines using Devops REST apis and report successfull or
 failed status (Build validation check for the PR)
 Infra Deploy Pipeline : https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_build?definitionId=1997&_a=summary
 Script Deploy Pipeline : https://dev.azure.com/defragovuk/DEFRA-DEVOPS-COMMON/_build?definitionId=2085&_a=summary
#>

[CmdletBinding()]
Param (
    [Parameter(Mandatory = $true, HelpMessage = 'PR Build branch name. e.g. refs/pull/18011/merge')]
    [string]$sourceBranch,

    [Parameter(Mandatory = $true, HelpMessage = 'The personal access token used to authorize devops rest api requests')]
    [String]$personalAccessToken,

    [Parameter(Mandatory = $true, HelpMessage = 'Devops Orgnization Name')]
    [string]$orgName,

    [Parameter(Mandatory = $true, HelpMessage = 'Devops Project Name')]
    [string]$projectName,

    [Parameter(Mandatory = $true, HelpMessage = 'Max Wait TimeOut for IntegrationTestpipeline. Default to 10 minutes.')]
    [int]$pipelineStateCheckMaxWaitTimeOutInSec = 600,

    [Parameter(Mandatory = $true, HelpMessage = 'Pipeline Build Definition ID.')]
    [int]$buildDefinitionId
)

Write-Verbose -Message "PR Source Branch: $($sourceBranch)" -Verbose

$azureDevopsProjectBaseUrl = "https://dev.azure.com/$($orgName)/$($projectName)";

#Prepare Header: Base64-encodes the Personal Access Token (PAT) appropriately
$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes((":{0}" -f $personalAccessToken)))
$headers = @{Authorization = ("Basic {0}" -f $base64AuthInfo) }

#Trigger Integration Test Pipeline
$uriPostRunPipeline = "$($azureDevopsProjectBaseUrl)/_apis/pipelines/$($buildDefinitionId)/runs?api-version=6.0"
$runPipelineRequestBodyWithDefaultConfig = '{
                    "stagesToSkip": [],
                    "resources": {
                        "repositories": {
                            "PipelineCommon": {
                                "refName": "refs/heads/main",
                                "version": ""
                            },
                            "self": {
                                "refName": "refs/heads/main"
                            }
                        }
                    },
                    "variables": {}
                }' | ConvertFrom-Json

$runPipelineRequestBodyWithDefaultConfig.resources.repositories.PipelineCommon.refName = $sourceBranch
$runPipelineRequestBodyWithDefaultConfig.resources.repositories.self.refName = $sourceBranch
$requestBodyJson = $runPipelineRequestBodyWithDefaultConfig | ConvertTo-Json -Depth 100
Write-Verbose -Message "requestBodyJson: $($requestBodyJson)" -Verbose

Write-Verbose -Message "Triggering Integration test pipeline. uriPostRunPipeline: $($uriPostRunPipeline)" -Verbose
$pipelineRun = Invoke-RestMethod -Uri $uriPostRunPipeline -Method Post -Headers $headers -Body $requestBodyJson -ContentType "application/json"
Write-Verbose -Message "PipelineRun run $($pipelineRun.id) triggered sucessfully. Current state: $($pipelineRun.state)" -Verbose
$piplineRunResult = [string]::Empty

# Get the Pipeline Run status and loop until state is inProgress.
$sleepPeriodinSec = 60
$totalSleepinSec = 0
do {
    sleep 60
    $totalSleepinSec += $sleepPeriodinSec;
    Write-Verbose -Message "Slept for $($sleepPeriodinSec) sec. TotalSleep so far $($totalSleepinSec) sec." -Verbose

    $gerPipelineRunStateUri = "$($azureDevopsProjectBaseUrl)/_apis/pipelines/$($buildDefinitionId)/runs/$($pipelineRun.id)?api-version=6.0"
    $pipelinerundetails = Invoke-RestMethod -Uri $gerPipelineRunStateUri -Method Get -Headers $headers
    $currentState = $pipelinerundetails.state
    Write-Verbose -Message "Current state of pipeline runId $($pipelineRun.id): $($currentState)" -Verbose
    Write-Verbose -Message "Running state check..." -Verbose
    if ($currentState -ne "inProgress") {
        $piplineRunResult = $pipelinerundetails.result
        Write-Verbose -Message "Current state: $($currentState)" -Verbose
        break
    }
} until ($currentState -ne "inProgress" -or $totalSleepinSec -ge $pipelineStateCheckMaxWaitTimeOutInSec)

#report pipeline status
if ($piplineRunResult -eq "succeeded") {
    $successmsg = "$($pipelinerundetails.pipeline.name) pipeline with runId $($pipelinerundetails.id) has completed successfully."
    Write-Verbose -Message "$($successmsg)" -Verbose
}
else {
    if ($totalSleepinSec -ge $pipelineStateCheckMaxWaitTimeOutInSec) {
        $errorMsg += "Excecution of Integration tests has stopped due to max timeout of $($pipelineStateCheckMaxWaitTimeOutInSec) sec."
    }
    else {
        $errormsg = "$($pipelinerundetails.pipeline.name) pipeline with runId $($pipelinerundetails.id) has failed."
    }
    Write-Verbose -Message "##vso[task.logissue type=error]$($errormsg)" -Verbose
    exit 1
}
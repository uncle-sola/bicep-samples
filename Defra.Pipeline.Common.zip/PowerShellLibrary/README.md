# PowerShell Library documentation

For a specific script refer to the relevant documentation page from the list below:

* [Add-AdAppRegistrations.ps1](/PowerShellLibrary/docs/Add-AdAppRegistrations.md)

* [CreateMetricAlertFunctions.ps1](/PowerShellLibrary/docs/CreateMetricAlertFunctions.md)

* [Configure-SubnetAccessToSSLCertKeyVault.ps1](/PowerShellLibrary/docs/Configure-SubnetAccessToSSLCertKeyVault.md)

* [Get-ResourcePrivateEndPointsDnsRecordsAsJson.ps1](/PowerShellLibrary/docs/Get-ResourcePrivateEndPointsDnsRecordsAsJson.md)

* [Set-AppGatewayPoolFqdnOrIpAddress.ps1](/PowerShellLibrary/docs/Set-AppGatewayPoolFqdnOrIpAddress.md)

* [Set-PrivateDnsRecordSet.ps1](/PowerShellLibrary/docs/Set-PrivateDnsRecordSet.md)

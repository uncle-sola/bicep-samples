<#
    .SYNOPSIS
        Configure-SubnetAccessToSSLCertKeyVault
    .DESCRIPTION
        This script is used to configure subnets to be able to access a KeyVault hosting SSL certificates
        The script will ensure the KeyVault Service Endpoint is configured on the provided subnet
        It will then add the provided to subnet to the KeyVault Vnet rules
#>


[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, HelpMessage = 'The resource group containing the virtual network')]
    [ValidateNotNullOrEmpty()]
    [String]$VnetRGname,
    [Parameter(Mandatory = $true, HelpMessage = 'The name of the virtual network')]
    [ValidateNotNullOrEmpty()]
    [String]$VnetName,
    [Parameter(Mandatory = $true, HelpMessage = 'The name of the subnet')]
    [ValidateNotNullOrEmpty()]
    [String]$SubnetName,
    [Parameter(Mandatory = $true, HelpMessage = 'The name of the KeyVault to link the subnet to')]
    [ValidateNotNullOrEmpty()]
    [String]$KeyVaultName

)

$vnet = Get-AzVirtualNetwork -ResourceGroupName $VnetRGname -Name $VnetName
$subnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $SubnetName

# Get existing service endpoints
$ServiceEndPoint = New-Object 'System.Collections.Generic.List[String]'
$subnet.ServiceEndpoints | ForEach-Object { $ServiceEndPoint.Add($_.service) }


if ($ServiceEndPoint.Contains("Microsoft.KeyVault")) {
    Write-Output "Microsoft.KeyVault Service endpoint already exists on subnet $SubnetName, nothing to do"
}
else {
    # Add required endpoint
    $ServiceEndPoint.Add("Microsoft.KeyVault")

    Get-AzVirtualNetwork -ResourceGroupName $VnetRGname -Name $VnetName | Set-AzVirtualNetworkSubnetConfig -Name $subnet.Name -AddressPrefix $subnet.AddressPrefix -ServiceEndpoint $ServiceEndPoint | Set-AzVirtualNetwork | Out-Null

    Write-Output "Added Microsoft.KeyVault Service endpoint to subnet $SubnetName"
}

# Now add subnet to KeyVault networking rules
Write-Output "Adding subnet $SubnetName to KeyVault $KeyVaultName networking rules"
Add-AzKeyVaultNetworkRule -VaultName $KeyVaultName -VirtualNetworkResourceId $subnet.Id


<#
    This script configures beckend pool of an Application Gateway.
    Oner scenario where this can be handy is to enable a shutter page during deployments.
#>
param (
    # Application Gateway to configure
    [Parameter(Mandatory = $true)]
    [string]$AppGatewayName,

    [Parameter(Mandatory = $true)]
    [string]$AppGatewayRG,

    [Parameter(Mandatory = $true)]
    [string]$Pool,

    [Parameter(Mandatory = $false)]
    [string[]]
    $BackendFqdns,

    [Parameter(Mandatory = $false)]
    [string[]]
    $BackendIPAddresses
)

# Check if Application Gateway can be found
try {
    $AppGw = Get-AzApplicationGateway -Name $AppGatewayName -ResourceGroupName $AppGatewayRG 
}
catch {
    throw "Couldn't find Application Gateway $AppGatewayName in Resource group $AppGatewayRG"
}

# Check if Pool exists on Application Gateway
$BackendPools = Get-AzApplicationGatewayBackendAddressPool -ApplicationGateway $AppGw
if (-Not $BackendPools.Name.contains($Pool) ) {
    throw "$Pool is missing on $AppGatewayName"
}

# Check wether BackendFqdns or BackendIPAddresses was supplied
if ( ($BackendFqdns.Length -eq 0) -and ($BackendIPAddresses.Length -eq 0)) {
    throw "Missing parameter. You need to specify BackendFqdns OR BackendIPAddresses"
}

# Check wether BackendFqdns and BackendIPAddresses was supplied
if ( ($BackendFqdns.Length -gt 0) -and ($BackendIPAddresses.Length -gt 0)) {
    throw "Too many parameters. You can't supply BackendFqdns and BackendIPAddresses at the same time."
}

if ( $BackendFqdns.Length -gt 0) {
    # Run for BackendFqdns
    Write-Host "Updating Application Gateway ($AppGatewayName) settings"
    Write-Host "  backend pool - $Pool"
    Write-Host "  backendFqdns - $BackendFqdns"
    
    try {       
        # Setting up new BackendAddressPool
        $AppGw = Set-AzApplicationGatewayBackendAddressPool -ApplicationGateway $AppGw -Name $Pool -BackendFqdns $BackendFqdns
        # This command actually configures Application Gateway with previously prepared changes
        $AppGw = Set-AzApplicationGateway -ApplicationGateway $AppGw
        # Confirm backend is set correctly
        $BackendPools = Get-AzApplicationGatewayBackendAddressPool -ApplicationGateway $AppGw
        Write-Host "Applied backend FQDNs:"
        Write-Host $BackendPools.BackendAddressesText
    }
    catch {
        throw "$_"
    }
}
else {
    # Run for BackendIPAddresses
    Write-Host "Updating Application Gateway ($AppGatewayName) settings"
    Write-Host "  backend pool - $Pool"
    Write-Host "  backendIPAddresses - $BackendIPAddresses"

    try {
        # Setting up new BackendAddressPool
        $AppGw = Set-AzApplicationGatewayBackendAddressPool -ApplicationGateway $AppGw -Name $Pool -BackendIPAddresses $BackendIPAddresses
        # This command actually configures Application Gateway with previously prepared changes
        $AppGw = Set-AzApplicationGateway -ApplicationGateway $AppGw
        # Confirm backend is set correctly
        $BackendPools = Get-AzApplicationGatewayBackendAddressPool -ApplicationGateway $AppGw
        Write-Host "Applied backend IPs:"
        Write-Host $BackendPools.BackendIpConfigurationsText
    }
    catch {
        throw "$_"
    }
}

Param (    
    [Parameter(Mandatory = $true)]
    [string]$AppRegJsonPath,
    [Parameter(Mandatory = $false)]
    [string]$AppRegManifestStorageAccountName = "",
    [Parameter(Mandatory = $false)]
    [string]$AppRegManifestContainerName = ""
)

Write-Host "RepositoryName = $($env:REPOSITORYNAME)"
Write-Host "PackageFeedEndpoint = $($env:PACKAGEFEEDENDPOINT)"
Write-Host "AddAdAppRegistrationsModuleName = $($env:ADDADAPPREGISTRATIONSMODULENAME)"
Write-Host "AddAdAppRegistrationsModuleVersion = $($env:ADDADAPPREGISTRATIONSMODULEVERSION)"

Write-Host "Register Package source.."
. $PSScriptRoot\..\templates\powershell\common-module\Register-Package.ps1 -RepositoryName $env:REPOSITORYNAME -PackageFeedEndpoint $env:PACKAGEFEEDENDPOINT

Write-Host "Installing Module.."
. $PSScriptRoot\..\templates\powershell\common-module\Install-Module.ps1 -RepositoryName $env:REPOSITORYNAME -ModuleName $env:ADDADAPPREGISTRATIONSMODULENAME -ModuleVersion $env:ADDADAPPREGISTRATIONSMODULEVERSION

Write-Host "Importing Module.."
Import-Module -Name $env:ADDADAPPREGISTRATIONSMODULENAME -RequiredVersion $env:ADDADAPPREGISTRATIONSMODULEVERSION -Force

#Call Function from the powershell module hosted in Azure Artifact feed
Write-Host "Calling Add-AdAppRegistrations funtion from the Module.."
if ($AppRegManifestStorageAccountName -or $AppRegManifestContainerName) {
    Write-Warning "AppRegManifestStorageAccountName and AppRegManifestContainerName are no longer required.  The Secret Renewal app now stores manifest data with the app registration in the notes property"
}
Add-AdAppRegistrations -appRegJsonPath $AppRegJsonPath

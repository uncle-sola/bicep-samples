---

---
# Configure-SubnetAccessToSSLCertKeyVault documentation

## Short description

Configure a specified subnet to be able to access a specified KeyVault via service endpoint connectivity

## Long description

The *Configure-SubnetAccessToSSLCertKeyVault.ps1* script configures the KeyVault service endppoint on a specified subnet, and then updates the KeyVault networking configuration to allow the subnet to be able access it. This is primarily used to allow Application Gateways to automatically retrieve SSL certficates for listeners.

## Syntax

```powershell
Configure-SubnetAccessToSSLCertKeyVault.ps1 
 -VnetRGname <String> 
 -VnetName <String> 
 -SubnetName <String> 
 -KeyVaultName <String>
```

## Parameters

### -VnetRGname

Specifies the Resource Group hosting the Virtual Network

### -VnetName

Specifies the name of the Virtual Network

### -SubnetName

Specifies the name of the Subnet

### -KeyVaultName

Specifies the name of the KeyVault to integrate with



## Pipeline example

This example show how to run the script as part of pre-deployment scripts from the `common-infrastructure-deploy.yaml`

```yaml

extends:
  template: /templates/pipelines/common-infrastructure-deploy.yaml@PipelineCommon
  parameters:
    projectName: SAMPLE
    templates:
      - name: SAMPLE-INFRA-templ
        path: SAMPLE-INFRA/ARM-SAMPLE-INFRA
        scope: 'Resource Group'
        resourceGroupName: 'tstcdorgp1001'
        preDeployServiceConnectionVariableName: secAzureResourceManagerConnection
        preDeployScriptsList:
          - displayName: Add subnet to KeyVault network rules
            scriptPath: 'Configure-SubnetAccessToSSLCertKeyVault.ps1@PipelineCommon'
            ScriptArguments: >
              -vnetRGname '$(appGwVnetRGName)' -vnetName '$(agwVnet)' -subnetName '$(appGwSubnetName)' -keyVaultName '$(wildcardCertKeyVault)'

```
---

---
# CreateMetricAlertFunctions documentation

## Short description

Create Azure metric alerts

## Long description

The metric alerts are created by passing a json `manifest` file. The json `manifest` file is used to describe the resources for which alerting should be configured.

The current version of the script creates a 'standard policy' of alerts as follows:
 - Web alert rules - monitoring number of health check failures and server errors
 - Traffic manager alert rules - monitoring traffic manager endpoint failures
 - App Insights alert rules - monitoring exceptions, dependency failures, request failures and response times
 - Service bus alert rules - monitoring dead letter queue counts
 - Logic app alert rules - monitoring logic app run failures
 - Simple App Insights alert rules - monitoring request failures (Policy Name : SimpleFailedRequestAppInsightsAlertPolicy)
 - Event Grid Topic rules - monitoring dead letter event counts

 The script also configures the action group and email recipients that will receive alert notifications.

## Syntax

```powershell
CreateMetricAlertFunctions.ps1 -manifestFilePath <string>
```

## Parameters

### -manifestFilePath

Specifies the path of monitoring_config.json - used to configure what alerts are created.

## Example consuming implementation

### File Structure

```
project
│   README.md
│
└───monitoring
│   │   create-alerts-pipeline.yaml
│   │   monitoring_config.json

```

### Example Manifest File
```
{
  "environment": "#{{ Environment.Name }}",
  "subscriptionId": "#{{ subscriptionId }}",
  "secSubscriptionId": "#{{ secsubscriptionId }}",
  "actionContext": {
    "groupName": "Capgemini",
    "groupShortName": "Cap",
    "groupResourceGroup": "#{{ Environment.Name }}trd#{{ nc-function-infrastructure }}#{{ nc-resource-resourcegroup }}#{{ nc-region-id }}01"
  },
  "alertRecipientPolicy": {
    "productionEnvironment": {
      "name": "EmailPolicy",
      "emailRecipients": [
          "europeandtradeamssupport@capgemini.com",
          "gcchypercarealerts.uk@capgemini.com"
      ]
    },
    "nonProductionEnvironment": {
      "name": "EmailPolicy",
      "emailRecipients": [
          "dave.macdonald@capgemini.com"
      ]
    }
  },
  "monitoredResources": {
    "appInsights": [
        {
        "name": "#{{ Environment.Name }}TRDINFAI1001",
        "resourceGroup": "#{{ Environment.Name }}TRDINFRG1001",
        "cloudRoleNames": [
          "#{{ Environment.Name }}trainfam1001.azure-api.net North Europe",
          "#{{ Environment.Name }}trainfam1001.azure-api.net West Europe",
          "#{{ Environment.Name }}trainfam1002.azure-api.net North Europe",
          "#{{ Environment.Name }}trainfam1002.azure-api.net West Europe",
          "#{{ Environment.Name }}ailwebaw1002",
          "#{{ Environment.Name }}trawebaw1001",
          "#{{ Environment.Name }}trawebaw1007",
          "#{{ Environment.Name }}trawebaw1009",
          "#{{ Environment.Name }}trawebaw1013",
          "#{{ Environment.Name }}trewebaf1001",
          "#{{ Environment.Name }}trewebaf1002",
          "#{{ Environment.Name }}trewebaf1003",
          "#{{ Environment.Name }}trewebaf1004",
          "#{{ Environment.Name }}trewebaf1005",
          "#{{ Environment.Name }}trewebaf1006",
          "#{{ Environment.Name }}trewebaf1007",
          "#{{ Environment.Name }}trewebaf1008",
          "#{{ Environment.Name }}trewebaf1009",
          "#{{ Environment.Name }}trewebaf1010",
          "#{{ Environment.Name }}trewebaf1011",
          "#{{ Environment.Name }}trewebaf1012",
          "#{{ Environment.Name }}trewebaf1013",
          "#{{ Environment.Name }}trewebaf1015",
          "#{{ Environment.Name }}trewebaf1021",
          "#{{ Environment.Name }}trewebaf1024",
          "#{{ Environment.Name }}trewebaf1025",
          "#{{ Environment.Name }}trewebaf1026",
          "#{{ Environment.Name }}trewebaf1027",
          "#{{ Environment.Name }}trewebaf1028",
          "#{{ Environment.Name }}trewebaf1029",
          "#{{ Environment.Name }}trswebaf1001",
          "#{{ Environment.Name }}trswebaf1002",
          "#{{ Environment.Name }}trswebaf1003",
          "#{{ Environment.Name }}trswebaw1001",
          "#{{ Environment.Name }}trswebaw1002",
          "#{{ Environment.Name }}trswebaw1005",
          "#{{ Environment.Name }}trswebaw1008",
          "#{{ Environment.Name }}trswebaw1009",
          "#{{ Environment.Name }}trswebaw1010",
          "#{{ Environment.Name }}trswebaw1015",
          "#{{ Environment.Name }}trswebaw1016",
          "#{{ Environment.Name }}trswebaw1017",
          "#{{ Environment.Name }}trswebaw1021",
          "#{{ Environment.Name }}trswebaw1022",
          "#{{ Environment.Name }}trswebaw1025",
          "#{{ Environment.Name }}trswebaw1026",
          "#{{ Environment.Name }}trswebaw1027",
          "#{{ Environment.Name }}trswebaw1028",
          "#{{ Environment.Name }}trswebaw1030",
          "#{{ Environment.Name }}trswebaw1032",
          "#{{ Environment.Name }}trswebaw1036",
          "#{{ Environment.Name }}trswebaw1038",
          "#{{ Environment.Name }}trswebaw1041"
        ]
      },
      "appInsightsAlertPolicyName": "StandardAppInsightsAlertPolicy or SimpleFailedRequestAppInsightsAlertPolicy",
    ]

    "webAppResourceGroups": [
      "#{{ Environment.Name }}TRA#{{ nc-function-infrastructure }}#{{ nc-resource-resourcegroup }}#{{ nc-region-id }}01",
      "#{{ Environment.Name }}TRS#{{ nc-function-infrastructure }}#{{ nc-resource-resourcegroup }}#{{ nc-region-id }}01",
      "#{{ Environment.Name }}TRA#{{ nc-function-infrastructure }}#{{ nc-resource-resourcegroup }}#{{ nc-secondary-region-id }}01",
      "#{{ Environment.Name }}TRS#{{ nc-function-infrastructure }}#{{ nc-resource-resourcegroup }}#{{ nc-secondary-region-id }}01"
    ],
    "webAppAlertPolicyName": "StandardWebAppPolicy",

    "trafficManagerResourceGroups": [
      "SECTRD#{{ Environment.Name }}#{{ nc-resource-resourcegroup }}#{{ nc-region-id }}01"
    ],
    "trafficManagerAlertPolicyName": "StandardTrafficManagerPolicy"

    "serviceBusNamespaces": [
      {
          "name": "#{{ Environment.Name }}TREINFSB1001",
          "resourceGroup": "#{{ Environment.Name }}TREINFRG1001",
          "serviceBusNamespacesAlertPolicyName": "StandardServiceBusPolicy"
      }
    ],

    "logicApps": [],
    "logicAppsAlertPolicyName": "StandardLogicAppPolicy",

    "eventGridTopics":
      [
        {
          "resourceGroup": "#{{ Environment.Name }}CDOINFRGP1001",
          "eventGridTopicNames": [
              "#{{ Environment.Name }}CDOINFEXPEVT1001",
              "#{{ Environment.Name }}CDOINFNEXPEVT1001",
              "eventGridTopicAlertPolicyName": "StandardEventGridTopicAlertPolicy"
          ]
        }
      ]
    }
  }
}
```
## Pipeline extending devops common script deploy
```
name: $(BuildID)

parameters:
  - name: forceDeploy
    displayName: 'Force deployment'
    type: boolean
    default: false

trigger:
  batch: true
  branches:
    include:
      - '*'
  paths:
    include:
      - monitoring/*

resources:
  repositories:
    - repository: TRDPipelineCommon
      name: DEFRA-TRD/Defra.TRD.Pipeline.Common
      type: git
      ref: master
    - repository: PipelineCommon
      name: DEFRA-DEVOPS-COMMON/Defra.Pipeline.Common
      type: git
      ref: feature/alerts

extends:
  template: /templates/pipelines/common-scripts-deploy.yaml@PipelineCommon
  parameters:
    variableFiles:
      - /vars/common.yaml@TRDPipelineCommon
      - /vars/{environment}.yaml@TRDPipelineCommon
    regionalVariableFiles:
      - /vars/regional/{environment}-{region}.yaml@TRDPipelineCommon
    environments:
      - name: 'dev'
        developmentEnvironment: true
        deploymentBranches:
          - '*'
      - name: 'snd'
        dependsOn: 'dev'
        developmentEnvironment: false
        deploymentBranches:
          - 'refs/heads/master'
      - name: 'tst'
        dependsOn: 'dev'
        developmentEnvironment: false
        deploymentBranches:
          - 'refs/heads/master'
      - name: 'pre'
        dependsOn: 'tst'
        developmentEnvironment: false
        deploymentBranches:
          - 'refs/heads/master'
      - name: 'prd'
        dependsOn: 'pre'
        developmentEnvironment: false
        deploymentBranches:
          - 'refs/heads/master'
    primaryRegionOnlyInEnvironments:
      - 'dev'
      - 'snd'
      - 'tst'
      - 'pre'
      - 'prd'
    scriptsList:
      - displayName: 'Create Azure Metric Alerts'
        scriptPath: 'CreateMetricAlertFunctions.ps1@PipelineCommon'
        scriptArguments: >-
          -manifestFilePath "./monitoring/monitoring_config.json"
        type: AzurePowerShell
        failOnStandardError: true
        filePathsForTransform:
          - monitoring/monitoring_config.json
    forceDeploy: ${{ parameters.forceDeploy }}

```
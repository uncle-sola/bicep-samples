---

---
# Set-AppGatewayPoolFqdnOrIpAddress documentation

## Short description

Configure a backend target for a given pool within an Application Gateway.

## Long description

The *Set-AppGatewayPoolFqdnOrIpAddress.ps1* script allows to configure a backend target for a given Application Gateway by either supplying a list of FQDNs or a list of backend IP addresses. This can be used e.g. for setting up a shutter page during maintenance/deployments.

## Syntax

```powershell
Set-AppGatewayPoolFqdnOrIpAddress.ps1 
 -AppGatewayName <String> 
 -AppGatewayRG <String> 
 -Pool <String> 
 [-BackendFqdns <String[]>]
 [-BackendIPAddresses <String[]>]
```

## Parameters

### -AppGatewayName

Specifies the Application Gateway to configure.

### -AppGatewayRG

Specifies the Application Gateway resource group.

### -Pool

Specifies the Application Gateway pool to configure.

### -BackendFqdns

List of backend FQDNs that the pool should point to. Mutually exclusive with **BackendIPAddresses**.

### -BackendIPAddresses

List of backend IP addresses that the pool should point to. Mutually exclusive with **BackendFqdns**.

## Pipeline example

This example show how to run the script as part of pre-deployment scripts from the `common-infrastructure-deploy.yaml`

```yaml

extends:
  template: /templates/pipelines/common-infrastructure-deploy.yaml@PipelineCommon
  parameters:
    projectName: SAMPLE
    templates:
      - name: SAMPLE-INFRA-templ
        path: SAMPLE-INFRA/ARM-SAMPLE-INFRA
        scope: 'Resource Group'
        resourceGroupName: 'tstcdorgp1001'
        preDeployServiceConnectionVariableName: secAzureResourceManagerConnection
        preDeployScriptsList:
          - displayName: Close B2B Application Gateway for pool $(b2b_appgw_admin_fe_backend_pool_name)
            scriptPath: 'Set-AppGatewayPoolFqdnOrIpAddress.ps1@PipelineCommon'
            ScriptArguments: -AppGatewayName $(b2b_appgw_name) -AppGatewayRG $(agwResourceGroupName) -Pool $(b2b_appgw_admin_fe_backend_pool_name) -BackendFqdns $(appgw_shutterpage_backend)

```
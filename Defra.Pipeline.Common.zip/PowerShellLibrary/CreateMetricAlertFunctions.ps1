﻿[CmdletBinding()]
Param
(
  [Parameter(Mandatory = $true)]
  [string]$manifestFilePath
)
### Verify if Non Prod or Prod
function environmentCheck ($environment, $nonProdEmailRecipients, $prodEmailRecipients, $actionGroupName ) {
  Write-Host "EnvironmentCheck function has been called."
  if ($environment.ToLower() -eq "prd") {
    $script:_actionGroupName = $actionGroupName + " - Production"
    $script:_actionGroupShortName = $actionGroupShortName + "Prod"
    $script:_emailAddress = $prodEmailRecipients
  }
  else {
    $script:_actionGroupName = $actionGroupName + " - Non Production"
    $script:_actionGroupShortName = $actionGroupShortName + "NonProd"
    $script:_emailAddress = $nonProdEmailRecipients
  }
}

function setActionGroup ($_actionGroupName, $actionGroupRg, $_emailAddress, $_actionGroupShortName) {
  Write-Host "CheckActionGroup function has been called."

  Write-Host "Creating / Updating Action Group ..."

  $emailReceivers = @()

  foreach ($email in $_emailAddress) {
    $emailReceiver = New-AzActionGroupReceiver -EmailReceiver -Name $email -EmailAddress $email -UseCommonAlertSchema
    $emailReceivers += $emailReceiver
  }

  Set-AzActionGroup -Name $_actionGroupName -ResourceGroup $actionGroupRg -ShortName $_actionGroupShortName -Receiver $emailReceivers -wa 0
  $actionGroup = Get-AzActionGroup -ResourceGroup $actionGroupRg -Name $_actionGroupName -wa 0

  $script:actionGroupId = $actionGroup.Id
  Write-Host $actionGroupId
  Write-Host "Completed creating / updating Action Group"
}

function createWebAlertRules ($actionGroupId, $manifest) {
  Write-Host "CreateWebAlertRules function has been called."
  Write-Host "Retrieving all (web) app services ..."

  if ($manifest.webAppAlertPolicyName -eq "StandardWebAppPolicy") {

    foreach ($rg in $manifest.webAppResourceGroups) {

      $webAppList = Get-AzResource -ResourceGroupName $rg -ResourceType "Microsoft.Web/sites"
      $webAppHealthStatusCriteria = New-AzMetricAlertRuleV2Criteria -MetricName "HealthCheckStatus" -TimeAggregation Average -Operator LessThanOrEqual -Threshold 95
      $webAppServerErrorCriteria = New-AzMetricAlertRuleV2Criteria -MetricName "Http5xx" -TimeAggregation Average -Operator GreaterThan -Threshold 2

      foreach ($webApp in $webAppList) {
        Write-Host "Adding alert rules to ... " $webApp.Name
        $tagPurpose = $webApp.Tags.Purpose
        $webAppLocation = $webApp.Location
        $webAppResourceId = $webApp.ResourceId

        if ($tagPurpose -eq $empty) {
          $alertHealthStatusRuleName = "WebApp_" + $webAppLocation + "_HealthCheckStatus"
          $alertServerErrorRuleName = "WebApp_" + $webAppLocation + "_ServerError"
        } else {
          $alertHealthStatusRuleName = $tagPurpose + "_" + $webAppLocation + "_HealthCheckStatus"
          $alertServerErrorRuleName = $tagPurpose + "_" + $webAppLocation + "_ServerError"
        }

        Add-AzMetricAlertRuleV2 -Name $alertHealthStatusRuleName `
          -ResourceGroup $rg `
          -TargetResourceId $webAppResourceId `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:01:00 `
          -Severity 2 `
          -Description "$($webApp.Name) is unhealthy" `
          -Condition $webAppHealthStatusCriteria

        Add-AzMetricAlertRuleV2 -Name $alertServerErrorRuleName `
          -ResourceGroup $rg `
          -TargetResourceId $webAppResourceId `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:01:00 `
          -Severity 2 `
          -Description "$($webApp.Name) failed to fulfil an apparently valid request (5xx server error)" `
          -Condition $webAppServerErrorCriteria
      }
    }
  }
}

function createTrafficManagerRules ($actionGroupId, $manifest, $actionGroupRg, $secSubscriptionId, $subscriptionId) {
  foreach ($rg in $manifest.trafficManagerResourceGroups) {
    if ($manifest.trafficManagerAlertPolicyName -eq "StandardTrafficManagerPolicy") {
      Write-Host "createTrafficManagerRules function has been called."
      Set-AzContext -Subscription $secSubscriptionId
      $TMProfileList = Get-AzResource -ResourceGroupName $rg -ResourceType "Microsoft.Network/trafficManagerProfiles"
      foreach ($item in $TMProfileList) {
        Write-Host "TMProfile name is " $item.Name
      }

      Set-AzContext -Subscription $subscriptionId

      $TMProfileOneEndpointFailureCriteria = New-AzMetricAlertRuleV2Criteria -MetricName "ProbeAgentCurrentEndpointStateByProfileResourceId" -TimeAggregation Average -Operator GreaterThanOrEqual -Threshold 0.52
      $TMProfileAllEndpointFailureCriteria = New-AzMetricAlertRuleV2Criteria -MetricName "ProbeAgentCurrentEndpointStateByProfileResourceId" -TimeAggregation Average -Operator LessThan -Threshold 0.48

      foreach ($TMProfile in $TMProfileList) {
        $resourceName = $TMProfile.ResourceName
        Write-Host "Resource name is $resourceName"

        $TMProfileOneEndpointFailurealertRuleName = "Traffic Mgr Profile Single endpoint failure - $resourceName"
        $TMProfileAllEndpointFailurealertRuleName = "Traffic Mgr Profile ALL endpoint failure - $resourceName"

        $TMProfileResourceId = $TMProfile.ResourceId

        Add-AzMetricAlertRuleV2 -Name $TMProfileOneEndpointFailurealertRuleName `
          -ResourceGroup $actionGroupRg `
          -TargetResourceId $TMProfileResourceId `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:01:00 `
          -Severity 2 `
          -Condition $TMProfileOneEndpointFailureCriteria

        Add-AzMetricAlertRuleV2 -Name $TMProfileAllEndpointFailurealertRuleName `
          -ResourceGroup $actionGroupRg `
          -TargetResourceId $TMProfileResourceId `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:01:00 `
          -Severity 1 `
          -Condition $TMProfileAllEndpointFailureCriteria
      }
    }
  }
}

function createAppinsightsAlertRules($actionGroupId, $manifest) {

  Write-Host "createAppinsightsAlertRules function has been called."

  foreach ($ai in $manifest.appInsights) {

    $appInsightsName = $ai.name.ToUpper()
    $appInsightsRg = $ai.resourceGroup.ToUpper()

    foreach ($cr in $ai.cloudRoleNames) {

      $crName = $cr.ToUpper()
      $ai = Get-AzApplicationInsights -ResourceGroupName $appInsightsRg -Name $appInsightsName

      if ($ai.appInsightsAlertPolicyName -eq "StandardAppInsightsAlertPolicy" `
          -or $manifest.appInsightsAlertPolicyName -eq "StandardAppInsightsAlertPolicy") {

        $errorCriteriaExceptions = New-AzMetricAlertRuleV2DimensionSelection -DimensionName "cloud/roleName" -ValuesToInclude $crName |`
          New-AzMetricAlertRuleV2Criteria -Dynamic -MetricNamespace "microsoft.insights/components" -MetricName "exceptions/count" -TimeAggregation Count -Operator GreaterThan -ThresholdSensitivity Medium -ViolationCount 4 -ExaminedAggregatedPointCount 4

        Add-AzMetricAlertRuleV2 -Name "Exceptions - $crName" `
          -ResourceGroup $appInsightsRg `
          -TargetResourceId $ai.Id `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:05:00 `
          -Severity 2 `
          -Description "$crName has more exceptions than usual" `
          -Condition $errorCriteriaExceptions

        $errorCriteriaDependencies = New-AzMetricAlertRuleV2DimensionSelection -DimensionName "cloud/roleName" -ValuesToInclude $crName |`
          New-AzMetricAlertRuleV2Criteria -Dynamic -MetricNamespace "microsoft.insights/components" -MetricName "dependencies/failed" -TimeAggregation Count -Operator GreaterThan -ThresholdSensitivity Medium -ViolationCount 4 -ExaminedAggregatedPointCount 4

        Add-AzMetricAlertRuleV2 -Name "Dependencies - $crName" `
          -ResourceGroup $appInsightsRg `
          -TargetResourceId $ai.Id `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:05:00 `
          -Severity 2 `
          -Description "$crName has more dependecy failures than usual" `
          -Condition $errorCriteriaDependencies

        $errorCriteriaRequests = New-AzMetricAlertRuleV2DimensionSelection -DimensionName "cloud/roleName" -ValuesToInclude $crName |`
          New-AzMetricAlertRuleV2Criteria -Dynamic -MetricNamespace "microsoft.insights/components" -MetricName "requests/failed" -TimeAggregation Count -Operator GreaterThan -ThresholdSensitivity Medium -ViolationCount 4 -ExaminedAggregatedPointCount 4

        Add-AzMetricAlertRuleV2 -Name "Requests - $crName" `
          -ResourceGroup $appInsightsRg `
          -TargetResourceId $ai.Id `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:05:00 `
          -Severity 2 `
          -Description "$crName has more request failures than usual" `
          -Condition $errorCriteriaRequests

        $errorCriteriaRequestTime = New-AzMetricAlertRuleV2DimensionSelection -DimensionName "cloud/roleName" -ValuesToInclude $crName |`
          New-AzMetricAlertRuleV2Criteria -Dynamic -MetricNamespace "microsoft.insights/components" -MetricName "requests/duration" -TimeAggregation Average -Operator GreaterThan -ThresholdSensitivity Low -ViolationCount 4 -ExaminedAggregatedPointCount 4

        Add-AzMetricAlertRuleV2 -Name "Server Response Time - $crName" `
          -ResourceGroup $appInsightsRg `
          -TargetResourceId $ai.Id `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:05:00 `
          -Severity 2 `
          -Description "$crName is taking longer than usual to respond to incoming requests" `
          -Condition $errorCriteriaRequestTime
      }
      elseif ($ai.appInsightsAlertPolicyName -eq "SimpleFailedRequestAppInsightsAlertPolicy" `
          -or $manifest.appInsightsAlertPolicyName -eq "SimpleFailedRequestAppInsightsAlertPolicy") {

        $errorCriteriaRequests = New-AzMetricAlertRuleV2DimensionSelection -DimensionName "cloud/roleName" -ValuesToInclude $crName |`
          New-AzMetricAlertRuleV2Criteria -MetricNamespace "microsoft.insights/components" -MetricName "requests/failed" -TimeAggregation Count -Operator GreaterThan -Threshold 0

        Add-AzMetricAlertRuleV2 -Name "Failed Requests - $crName" `
          -ResourceGroup $appInsightsRg `
          -TargetResourceId $ai.Id `
          -ActionGroupId $actionGroupId `
          -WindowSize 01:00:00 `
          -Frequency 01:00:00 `
          -Severity 2 `
          -Description "$crName has more request failures than usual" `
          -Condition $errorCriteriaRequests
      }
    }
  }
}

function createServiceBusAlertRules($actionGroupId, $manifest) {
  Write-Host "createServiceBusAlertRules function has been called."

  foreach ($sb in $manifest.serviceBusNamespaces) {

    if ($manifest.serviceBusNamespacesAlertPolicyName -eq "StandardServiceBusPolicy" `
        -or $sb.serviceBusNamespacesAlertPolicyName -eq "StandardServiceBusPolicy") {

      $servicebusRg = $sb.resourceGroup
      $servicebusNamespace = $sb.name

      Write-Host $servicebusRg
      Write-Host $servicebusNamespace

      $servicebus = Get-AzResource -ResourceGroupName $servicebusRg -ResourceType "Microsoft.ServiceBus/namespaces"
      #Get list of queues

      $queues = Get-AzServiceBusQueue -ResourceGroup $servicebusRg -NamespaceName $servicebusNamespace
      foreach ($queue in $queues) {

        $dlqErrorCriteria = New-AzMetricAlertRuleV2DimensionSelection -DimensionName "EntityName" -ValuesToInclude $queue.name `
      | New-AzMetricAlertRuleV2Criteria -MetricName "deadletteredmessages" -TimeAggregation Maximum -Operator GreaterThan -Threshold 0

        Add-AzMetricAlertRuleV2 -Name "DLQ Alert - $($queue.name)" `
          -ResourceGroup $servicebusRg `
          -TargetResourceId $servicebus.ResourceId `
          -ActionGroupId $actionGroupId `
          -WindowSize 00:05:00 `
          -Frequency 00:05:00 `
          -Severity 2 `
          -Description "The queue $($queue.name) has dead lettered messages" `
          -Condition $dlqErrorCriteria
      }
    }
  }
}

function createLogicAppAlertRules($actionGroupId, $manifest) {
  Write-Host "createLogicAppAlertRules function has been called."

  foreach ($la in $manifest.logicApps) {
    if ($la.logicAppsAlertPolicyName -eq "StandardLogicAppPolicy" `
        -or $manifest.logicAppsAlertPolicyName -eq "StandardLogicAppPolicy") {
      $laName = $la.name.ToUpper()
      $laResourceGroup = $la.resourceGroup.ToUpper()
      Write-Host $crName $appInsightsName
      $logicApp = Get-AzLogicApp -ResourceGroupName $laResourceGroup -Name $laName

      $errorCriteria = New-AzMetricAlertRuleV2Criteria -MetricName "runsfailed" -TimeAggregation Average -Operator GreaterThan -Threshold 1

      Add-AzMetricAlertRuleV2 -Name "Logic App Runs Failed - $laName" `
        -ResourceGroup $laResourceGroup `
        -TargetResourceId $logicApp.Id `
        -ActionGroupId $actionGroupId `
        -WindowSize 00:05:00 `
        -Frequency 00:05:00 `
        -Severity 2 `
        -Description "$laName has failed runs" `
        -Condition $errorCriteria
    }
  }
}

function createStandardEventGridTopicAlertRules($actionGroupId, $manifest) {
  Write-Host "createStandardEventGridTopicAlertRules function has been called."

  foreach ($egt in $manifest.eventGridTopics) {
    if ($egt.eventGridTopicAlertPolicyName -eq "StandardEventGridTopicAlertPolicy" `
        -or $manifest.eventGridTopicAlertPolicyName -eq "StandardEventGridTopicAlertPolicy") {

      $eventTopicNamesArray = $egt.eventGridTopicNames
      $eventGridResourceGroup = $egt.resourceGroup

      foreach ($eventGridTopicName in $eventTopicNamesArray) {
        Write-Host "Adding alert rules to ... " $eventGridTopicName
        $eventGridTopic = Get-AzResource -Name $eventGridTopicName -ResourceGroupName $eventGridResourceGroup

        $errorCriteriaRequests = New-AzMetricAlertRuleV2Criteria -MetricNamespace "Microsoft.EventGrid/topics" -MetricName "DeadLetteredCount" -TimeAggregation Total -Operator GreaterThan -Threshold 0

        Add-AzMetricAlertRuleV2 -Name "DeadLetterEvent Alert - $eventGridTopicName" `
          -ResourceGroup $eventGridResourceGroup `
          -TargetResourceId $eventGridTopic.Id `
          -ActionGroupId $actionGroupId `
          -WindowSize 01:00:00 `
          -Frequency 01:00:00 `
          -Severity 2 `
          -Description "The topic $($eventGridTopicName) has dead lettered messages" `
          -Condition $errorCriteriaRequests
      }
    }
  }
}

###### CALL FUNCTIONS ######
try {

  $manifest = Get-Content $manifestFilePath -Raw | ConvertFrom-Json
  Write-Host $manifest.actionContext $manifest.alertRecipientPolicy

  $actionGroupName = $manifest.actionContext.groupName
  $actionGroupShortName = $manifest.actionContext.groupShortName
  $actionGroupRg = $manifest.actionContext.groupResourceGroup
  $prodEmailRecipients = $manifest.alertRecipientPolicy.productionEnvironment.emailRecipients
  $nonProdEmailRecipients = $manifest.alertRecipientPolicy.nonProductionEnvironment.emailRecipients
  $subscriptionId = $manifest.subscriptionId
  $secSubscriptionId = $manifest.secSubscriptionId
  $environment = $manifest.environment

  environmentCheck $environment $nonProdEmailRecipients $prodEmailRecipients $actionGroupName
  Write-Host "emails ${script:_emailAddress}"
  setActionGroup $script:_actionGroupName $actionGroupRg $script:_emailAddress $script:_actionGroupShortName

  if ($manifest.monitoredResources.webAppResourceGroups) {
    createWebAlertRules $script:actionGroupId $manifest.monitoredResources
  }
  if ($manifest.monitoredResources.trafficManagerResourceGroups) {
    createTrafficManagerRules $script:actionGroupId $manifest.monitoredResources $actionGroupRg $secSubscriptionId $subscriptionId
  }
  if ($manifest.monitoredResources.serviceBusNamespaces) {
    createServiceBusAlertRules $script:actionGroupId $manifest.monitoredResources
  }
  if ($manifest.monitoredResources.appInsights) {
    createAppinsightsAlertRules $script:actionGroupId $manifest.monitoredResources
  }
  if ($manifest.monitoredResources.logicApps) {
    createLogicAppAlertRules $script:actionGroupId $manifest.monitoredResources
  }
  if ($manifest.monitoredResources.eventGridTopics) {
    createStandardEventGridTopicAlertRules $script:actionGroupId $manifest.monitoredResources
  }

}
catch {
  Write-Host "The following error occurred ... " $_
}
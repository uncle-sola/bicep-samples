[CmdletBinding()]
Param
(
    [Parameter(Mandatory = $true)]
    [string]$TemplateFile,

    [Parameter(Mandatory = $true)]
    [string]$TemplateParameterFile,
    
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName
)

$ErrorActionPreference = "Stop"

try {  
    New-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile $TemplateFile -TemplateParameterFile $TemplateParameterFile -Whatif
}
catch {
    Write-Output "The resource group $resourceGroupName does not exist, the template WhatIf has been ignored"
}
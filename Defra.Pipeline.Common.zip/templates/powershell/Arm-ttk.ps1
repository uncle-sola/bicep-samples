param(
    [Parameter(Mandatory = $true)]
    [string] $templateFile
)

$deletedtests = @('apiVersions-Should-Be-Recent',
    'apiVersions-Should-Be-Recent-In-Reference-Functions',
    'VM-Images-Should-Use-Latest-Version',
    'Virtual-Machines-Should-Not-Be-Preview',
    'Resources-Should-Not-Be-Ambiguous')

$errortests = @('DeploymentTemplate-Schema-Is-Correct',
    'Parameters-Must-Be-Referenced',
    'Secure-String-Parameters-Cannot-Have-Default',
    'DeploymentTemplate-Must-Not-Contain-Hardcoded-Uri',
    'Location-Should-Not-Be-Hardcoded',
    'VM-Size-Should-Be-A-Parameter',
    'adminUsername-Should-Not-Be-A-Literal',
    'Outputs-Must-Not-Contain-Secrets')

$warningtests = @('DependsOn-Best-Practices',
    'Deployment-Resources-Must-Not-Be-Debug',
    'Dynamic-Variable-References-Should-Not-Use-Concat',
    'IDs-Should-Be-Derived-From-ResourceIDs',
    'ManagedIdentityExtension-must-not-be-used',
    'Min-And-Max-Value-Are-Numbers',
    'Parameter-Types-Should-Be-Consistent',
    'Parameters-Must-Be-Referenced',
    'Password-params-must-be-secure',
    'ResourceIds-should-not-contain',
    'Resources-Should-Have-Location',
    'Secure-Params-In-Nested-Deployments',
    'Template-Should-Not-Contain-Blanks',
    'URIs-Should-Be-Properly-Constructed',
    'Variables-Must-Be-Referenced',
    'artifacts-parameter',
    'providers_apiVersions-Is-Not-Permitted')

$warningpara = @('DeploymentParameters-Should-Have-Value',
    'DeploymentParameters-Should-Have-Schema',
    'DeploymentParameters-Should-Have-Parameters',
    'DeploymentParameters-Should-Have-ContentVersion')


$file = "./arm-template-toolkit/arm-ttk/arm-ttk.psd1"

if (-not(Test-Path -Path $file -PathType Leaf)) {
    try {
        Invoke-WebRequest -Uri 'https://azurequickstartsservice.blob.core.windows.net/ttk/latest/arm-template-toolkit.zip' -OutFile './arm-template-toolkit.zip'
        Expand-Archive './arm-template-toolkit.zip' './arm-template-toolkit' -Force
        Write-Host "ARM ttk extracted"

        for ($i = 0; $i -lt $deletedtests.length; $i++) {
            $fullpath = './arm-template-toolkit/arm-ttk/testcases/deploymentTemplate/' + $deletedtests[$i] + '.test.ps1'
            Remove-Item $fullpath
        }
    }
    catch {
        throw $_.Exception.Message
    }
}
Import-Module $file
for ($i = 0; $i -lt $errortests.length; $i++) {
    $fullpath = './arm-template-toolkit/arm-ttk/testcases/deploymentTemplate/' + $errortests[$i] + '.test.ps1'
    $content = Get-Content -Path $fullpath
    $newContent = $content -replace 'Write-Error', 'Write-output'
    $newContent | Set-Content -Path $fullpath
    $path = './' + $templateFile + '.json'
    Test-AzTemplate -TemplatePath $path -Test $errortests[$i]
}

for ($i = 0; $i -lt $warningtests.length; $i++) {
    $fullpath = './arm-template-toolkit/arm-ttk/testcases/deploymentTemplate/' + $warningtests[$i] + '.test.ps1'
    $content = Get-Content -Path $fullpath
    $newContent = $content -replace 'Write-Error', 'Write-Output'
    $newContent | Set-Content -Path $fullpath
    $path = './' + $templateFile + '.json'
    Test-AzTemplate -TemplatePath $path -Test $warningtests[$i]
}

for ($i = 0; $i -lt $warningpara.length; $i++) {
    $parafullpath = './arm-template-toolkit/arm-ttk/testcases/deploymentParameters/' + $warningpara[$i] + '.test.ps1'
    $content = Get-Content -Path $parafullpath
    $newContent = $content -replace 'Write-Error', 'Write-Output'
    $newContent | Set-Content -Path $parafullpath
    $path = './' + $templateFile + '.json'
    Test-AzTemplate -TemplatePath $path -Test $warningpara[$i]
}

$path = './' + $templateFile + '.json'
Test-AzTemplate -TemplatePath $path -Test JSONFiles-Should-Be-Valid
[CmdletBinding()]
Param
(
    [Parameter(Mandatory = $true)]
    [string]$applicationUrl,

    [Parameter(Mandatory = $false)]
    [string]$endpointPath = "/health"
)

. $PSScriptRoot\CommonFunctions.ps1
Write-Output "Checking health of: $applicationUrl$endpointPath"

[Net.ServicepointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function CheckHealth ($url) {
    $status = Invoke-RestMethod -Method Get -Uri $url -UseBasicParsing
    if ($null -ne $status) {
        foreach($item in $status.entries) {
            Write-Host "Component: $($item.key), Status: $($item.status), Additional Info: $($item.data)"
        }
    }
}

Retry {CheckHealth -url "$applicationUrl$endpointPath"} -maxAttempts 5

[CmdletBinding()]
Param
(
    [Parameter(Mandatory = $true)]
    [string]$TemplateFile,

    [Parameter(Mandatory = $true)]
    [string]$TemplateParameterFile,
    
    [Parameter(Mandatory = $true)]
    [string]$Location
)

$ErrorActionPreference = "Stop"

try {
    New-AzDeployment -Location $Location -TemplateFile $TemplateFile -TemplateParameterFile $TemplateParameterFile -WhatIf
}
catch {
    Write-Output "The Location $Location does not exist, the template WhatIf has been ignored"
}
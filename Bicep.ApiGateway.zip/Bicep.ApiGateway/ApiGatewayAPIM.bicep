@description('Location')
param Location string = resourceGroup().location

@description('log analytics workspace name')
param LogAnalyticsName string

@description('App Insights Name')
param AppInsightsName string

@description('key vault name')
#disable-next-line no-unused-params
param vaultName string

@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')


@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string


@description('Apim Subnet Name')
param subnet01Name string

@description('Required. The name of the API Management service.')
param apimName string

@description('Optional. Public Standard SKU IP V4 based IP address to be associated with Virtual Network deployed service in the region. Supported only for Developer and Premium SKU being deployed in Virtual Network.')
param apimPublicIpName string

@description('Apim pricing tier')
@allowed([
  'Consumption'
  'Developer'
  'Basic'
  'Standard'
  'Premium'
  'StandardV2'
  'BasicV2'
])
param apimPricingTier string

@description('Apim capacity')
param apimCapacity int

@description('Required. The email address of the owner of the service.')
param publisherEmail string

@description('Optional. The notification sender email address for the service.')
param notificationSenderEmail string = 'apimgmt-noreply@mail.windowsazure.com'

@description('Required. The name of the owner of the service.')
param publisherName string

@description('Optional. The type of VPN in which API Management service needs to be configured in. None (Default Value) means the API Management service is not part of any Virtual Network, External means the API Management deployment is set up inside a Virtual Network having an internet Facing Endpoint, and Internal means that API Management deployment is setup inside a Virtual Network having an Intranet Facing Endpoint only.')
@allowed([
  'None'
  'External'
  'Internal'
])
param virtualNetworkType string = 'None'

@description('Apim Network ResourceGroup name')
param APIMNetworkRGName string

@description('Managed Identity Name for key vault user')
@secure()
param managedIdentityKeyVaultSecretUser string

@description('switch to deploy basic config or full custom domain config')
@allowed([
  'Basic'
  'Full'
])
param deployBasicConfiguration string = 'Basic'

@description('apim custom url prefix')
param apimCustomUrlPrefix string

@description('wild card cert name')
param wildCardCertName string

var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

var customProperties = {
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Tls11': 'false'
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Tls10': 'false'
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Backend.Protocols.Tls11': 'false'
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Backend.Protocols.Tls10': 'false'
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Backend.Protocols.Ssl30': 'true'
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Protocols.Server.Http2': 'false'
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Ciphers.TripleDes168': 'false'
  'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Ssl30': 'true'
}

var basicHostnameConfigurations = [
  {
    hostName: '${toLower(apimName)}.azure-api.net'
    type: 'Proxy'
    certificateSource: 'BuiltIn'
    defaultSslBinding: false
  }
]


var starInternalConnellsGroupSslCertKeyVaultUri = 'https://${vaultName}${environment().suffixes.keyvaultDns}/secrets/${wildCardCertName}' // ssl cert location
var fullHostnameConfigurations = [
  {
    hostName: '${toLower(apimName)}.azure-api.net'
    type: 'Proxy'
    certificateSource: 'BuiltIn'
    defaultSslBinding: false
  }
  {
    hostName: '${apimCustomUrlPrefix}-gateway.internal.connellsgroup.co.uk'
    type: 'Proxy'
    certificateSource: 'KeyVault'
    keyVaultId: starInternalConnellsGroupSslCertKeyVaultUri
  }
  {
    hostName: '${apimCustomUrlPrefix}-portal.internal.connellsgroup.co.uk'
    type: 'Portal'
    certificateSource: 'KeyVault'
    keyVaultId: starInternalConnellsGroupSslCertKeyVaultUri
  }
  {
    hostName: '${apimCustomUrlPrefix}-developer.internal.connellsgroup.co.uk'
    type: 'DeveloperPortal'
    certificateSource: 'KeyVault'
    keyVaultId: starInternalConnellsGroupSslCertKeyVaultUri
  }
  {
    hostName: '${apimCustomUrlPrefix}-gateway-management.internal.connellsgroup.co.uk'
    type: 'Management'
    certificateSource: 'KeyVault'
    keyVaultId: starInternalConnellsGroupSslCertKeyVaultUri
  }
  {
    hostName: '${apimCustomUrlPrefix}-scm.internal.connellsgroup.co.uk'
    type: 'Scm'
    certificateSource: 'KeyVault'
    keyVaultId: starInternalConnellsGroupSslCertKeyVaultUri
  }
]

var keyVaultSecretUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'
var varUniqueKeyvaultUserRoleId = guid(
  '/subscriptions/${subscription().subscriptionId}/resourceGroups/${resourceGroup().id}/providers/Microsoft.keyVault/vaults/${vaultName}',
  keyVaultSecretUserRoleId,
  resourceId('Microsoft.ApiManagement/service', apimName)
)

resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vaultName
}

resource uniqueKeyvaultUserGuid 'Microsoft.Authorization/roleAssignments@2022-04-01' =  {
  scope: keyVault
  name: varUniqueKeyvaultUserRoleId
  properties: {
    roleDefinitionId: resourceId('Microsoft.Authorization/roleDefinitions', keyVaultSecretUserRoleId)
    principalId: CreateApim.outputs.systemAssignedMIPrincipalId
    principalType: 'ServicePrincipal'
  }

}

resource apimIPAddress 'Microsoft.Network/publicIPAddresses@2022-11-01' existing = {
  scope: resourceGroup(APIMNetworkRGName)
  name: apimPublicIpName
}

resource vnet 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  name: ExistingVnetName
}


resource UserAssignedIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-07-31-preview' existing ={
  name: managedIdentityKeyVaultSecretUser
}
module CreateApim './modules/api-management/service/main.bicep' = {
  name: '${Timestamp}-Apim'
  params:{
    name: apimName
    publisherEmail: publisherEmail
    publisherName: publisherName
    notificationSenderEmail: notificationSenderEmail
    customProperties: customProperties
    hostnameConfigurations: (deployBasicConfiguration == 'Basic' ? basicHostnameConfigurations : fullHostnameConfigurations)
    location: Location
    managedIdentities:{
      systemAssigned:true
      userAssignedResourceIds:[
        UserAssignedIdentity.id
      ]
    }
    publicIpAddressResourceId: apimIPAddress.id
    sku: apimPricingTier
    skuCapacity: apimCapacity
    subnetResourceId: '${vnet.id}/subnets/${subnet01Name}'
    tags: tags
    virtualNetworkType: virtualNetworkType
    zones: []
  
  }
  
}

module CreateAPIMDependencies './modules/apim-dependencies.bicep' = {
  name: '${Timestamp}-APIM-Dependencies'
  params:{
    apimName: apimName
    AppInsightsName: AppInsightsName
    LogAnalyticsName: LogAnalyticsName
    vnetId: vnet.id
  }
  dependsOn:[
    CreateApim
  ]
}

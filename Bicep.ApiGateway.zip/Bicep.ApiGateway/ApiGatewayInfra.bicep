import * as resources from 'functions/project-resource-names.bicep'


@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string


@description('Location')
param Location string = resourceGroup().location





@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string = subscription().subscriptionId

@description('App Gateway Subnet Name')
var appGwSubnetName = resources.getAppGatewaySubnetName(Region, Environment, Project)

@description('Apim subnet name')
var apimSubnetName = resources.getApimSubnetName(Region, Environment, Project)

@description('log analytics workspace name')
var LogAnalyticsName = resources.getLogAnalyticsName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

@description('Managed Identity Name for key vault user')
var managedIdentityKeyVaultSecretUser = resources.getManagedIdentityKeyVaultSecretUser(Region, Environment, Project) 

@description('Managed Identity Name for api caller')
var managedIdentityApiCaller = resources.getManagedIdentityApiCaller(Region,Environment,Project)

var keyVaultSecretUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'

var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}



resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: LogAnalyticsName
}

resource vnet 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  name: ExistingVnetName
}

module ManagedIdentitykeyVaultSecretUser 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/userassignedmanagedidentity:1.0.1' = {
  name: '${Timestamp}-ManagedIdentityKeyVaultSecretUserName'
  params: {
    BusinessUnitTag: BusinessUnitTag
    CompanyTag: CompanyTag
    ContactTag: ContactTag
    ManagedIdentityName: managedIdentityKeyVaultSecretUser
    SolutionName: SolutionName
  }
}

module ManagedIdentityApiCaller 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/userassignedmanagedidentity:1.0.1' = {
  name: '${Timestamp}-ManagedIdentityApiCallerName'
  params: {
    BusinessUnitTag: BusinessUnitTag
    CompanyTag: CompanyTag
    ContactTag: ContactTag
    ManagedIdentityName: managedIdentityApiCaller
    SolutionName: SolutionName
  }
}

module KeyVaultSecretUserRoleAssignment 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/roleassignmentsingle:1.0.1' = {
  name: '${Timestamp}-KvSecretRoleAssignment'
  params: {
    PrincipalId: ManagedIdentitykeyVaultSecretUser.outputs.PrincipalId
    RoleDefinitionId: keyVaultSecretUserRoleId
  }
}


module KeyVault './modules/key-vault/vault/main.bicep' = {
  name: '${Timestamp}-Keyvault'
  params: {
    name: vaultName
    accessPolicies: []
    diagnosticSettings: [
      {
        logCategoriesAndGroups: [
          {
            categoryGroup: 'allLogs'
            enabled: true
          }
          {
            categoryGroup: 'audit'
            enabled: true
          }
        ]
        metricCategories: [
          {
            category: 'AllMetrics'
            enabled: true
          }
        ]
        logAnalyticsDestinationType: 'AzureDiagnostics'
        workspaceResourceId: laWorkspace.id
      }
    ]
    enablePurgeProtection: true
    enableRbacAuthorization: true
    enableSoftDelete: true
    enableVaultForDeployment: true
    enableVaultForDiskEncryption: true
    enableVaultForTemplateDeployment: true
    location: Location
    privateEndpoints: []
    networkAcls:{
      bypass: 'AzureServices'
      defaultAction: 'Deny'
      virtualNetworkRules: [
        {
          id: '${vnet.id}/subnets/${appGwSubnetName}'
        }
        {
          id: '${vnet.id}/subnets/${apimSubnetName}'
        }
      ]
    }
    sku:'standard'
    tags:tags
  }
}

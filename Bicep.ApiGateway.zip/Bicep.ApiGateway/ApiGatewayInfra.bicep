@description('Location')
param Location string = resourceGroup().location

@description('log analytics workspace name')
param LogAnalyticsName string

@description('Key vault name')
param vaultName string

@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('Existing VNet Name')
#disable-next-line no-unused-params
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
#disable-next-line no-unused-params
param ExistingVnetRG string

@description('Existing VNet Subscription')
#disable-next-line no-unused-params
param ExistingVnetSubscription string

@description('Existing Infra subnet name')
#disable-next-line no-unused-params
param subnet02Name string

@description('Managed Identity Name for key vault user')
@secure()
param managedIdentityKeyVaultSecretUser string

var keyVaultSecretUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'

var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

var enablePublicAccess = true

resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: LogAnalyticsName
}

module ManagedIdentitykeyVaultSecretUser 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/userassignedmanagedidentity:1.0.1' = {
  name: '${Timestamp}-ManagedIdentityKeyVaultSecretUserName'
  params: {
    BusinessUnitTag: BusinessUnitTag
    CompanyTag: CompanyTag
    ContactTag: ContactTag
    ManagedIdentityName: managedIdentityKeyVaultSecretUser
    SolutionName: SolutionName
  }
}

module KeyVaultSecretUserRoleAssignment 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/roleassignmentsingle:1.0.1' = {
  name: '${Timestamp}-KvRoleAssignment'
  params: {
    PrincipalId: ManagedIdentitykeyVaultSecretUser.outputs.PrincipalId
    RoleDefinitionId: keyVaultSecretUserRoleId
  }
}

module KeyVault './modules/key-vault/vault/main.bicep' = {
  name: '${Timestamp}-Keyvault'
  params: {
    name: vaultName
    accessPolicies: []
    diagnosticSettings: [
      {
        logCategoriesAndGroups: [
          {
            categoryGroup: 'allLogs'
            enabled: true
          }
          {
            categoryGroup: 'audit'
            enabled: true
          }
        ]
        metricCategories: [
          {
            category: 'AllMetrics'
            enabled: true
          }
        ]
        logAnalyticsDestinationType: 'AzureDiagnostics'
        workspaceResourceId: laWorkspace.id
      }
    ]
    enablePurgeProtection: true
    enableRbacAuthorization: true
    enableSoftDelete: true
    enableVaultForDeployment: true
    enableVaultForDiskEncryption: true
    enableVaultForTemplateDeployment: true
    location: Location
    privateEndpoints: []
    networkAcls:{
      bypass: 'AzureServices'
      defaultAction: 'Deny'
      virtualNetworkRules: []
    }
    publicNetworkAccess: enablePublicAccess ? 'Enabled' : 'Disabled'
    sku:'standard'
    tags:tags
  }
}

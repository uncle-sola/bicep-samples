param Location string = resourceGroup().location
param vmPrefix string
param vnetId string
param kvName string 
param kvResourceGroup string

param BusinessUnitTag string = 'New Business Unit'
param CompanyTag string = 'Connells Group'
param ContactTag string = 'Dev - Online'
param SolutionName string = 'ApiGateway'

resource kv 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: kvName
  scope: resourceGroup(kvResourceGroup)
}


var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

module CreateVM './modules/create-vm.bicep' = {
  name: 'CreateVm'
  params: {
    adminUsername: kv.getSecret('adminUsername')
    adminPassword: kv.getSecret('adminPassword')
    tags: tags
    vmPrefix: vmPrefix
    vnetId: vnetId
    Location: Location
  }
  
}

output privateIp string = CreateVM.outputs.privateIp
output publicIp string = CreateVM.outputs.publicIp

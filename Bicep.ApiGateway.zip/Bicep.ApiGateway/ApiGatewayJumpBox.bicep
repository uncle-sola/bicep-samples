import * as resources from 'functions/project-resource-names.bicep'

param Location string = resourceGroup().location

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

param BusinessUnitTag string = 'New Business Unit'
param CompanyTag string = 'Connells Group'
param ContactTag string = 'Dev - Online'
param SolutionName string = 'ApiGateway'

@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string = subscription().subscriptionId

@description('Public Standard SKU IP V4 based IP address to be associated with Virtual Network deployed service in the region. Supported only for Developer and Premium SKU being deployed in Virtual Network.')
var JumpBoxIpName = resources.getJumpBoxPublicIpName(Region, Environment, Project)

@description('Key vault resource group')
var kvResourceGroup = resources.getInfraResourceGroupName(Region, Environment, Project)

@description('jump box ip resource group same as APIM Network resource group')
var jumpBoxIpResourceGroup = resources.getAPIMNetworkRGName(Region, Environment, Project)



@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

@description('Jumpbox Subnet Name')
var jumpBoxSubnetName = resources.getInfraSubnetName(Region, Environment, Project)


var vmName = resources.getVmName(Region, Environment, Project)
var vmInterfaceCardName = resources.getInterfaceCardName(Region, Environment, Project)
var vmShutDownScheduleName = 'shutdown-computevm-${vmName}'
var vmDiskName = resources.getOsDiskName(Region, Environment, Project)

resource vnet 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  name: ExistingVnetName
}

resource kv 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: vaultName
  scope: resourceGroup(kvResourceGroup)
}



module CreateVM './modules/create-vm.bicep' = if (Environment == 'poc') {
  name: '${Timestamp}-CreateVm'
  params: {
    adminUsername: kv.getSecret('adminUsername')
    adminPassword: kv.getSecret('adminPassword')
    tags: tags
    vmName: vmName
    vmInterfaceCardName: vmInterfaceCardName
    vmShutDownScheduleName: vmShutDownScheduleName
    vmDiskName: vmDiskName
    jumBoxIpName: JumpBoxIpName
    subNetId: '${vnet.id}/subnets/${jumpBoxSubnetName}'
    Location: Location
    jumpBoxIpResourceGroup: jumpBoxIpResourceGroup
  }
  
}

output privateIp string = CreateVM.outputs.privateIp
output publicIp string = CreateVM.outputs.publicIp

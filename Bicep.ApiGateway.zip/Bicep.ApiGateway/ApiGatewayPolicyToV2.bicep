param apimName string
param apiName string
param apiVersion string
param apiOperationName string
param productName string

var apiOperationPolicystring = loadTextContent('./policy/operation.policy.xml')
var apimPolicystring = loadTextContent('./policy/apim.policy.xml')
var apiPolicystring = loadTextContent('./policy/api.policy.xml')
var productPolicystring = loadTextContent('./policy/product.policy.xml')

module installApiOperationPolicy './modules/install-api-operation-policy.bicep' = {
  name: 'installApiOperationPolicy'
  params:{
    apimName: apimName
    apiName: '${toLower(apiName)}-api-${apiVersion}'
    apiOperationName: apiOperationName
    policystring: apiOperationPolicystring
  }
}

module installApimPolicy './modules/install-apim-policy.bicep' = {
  name: 'installApimPolicy'
  params:{
    apimName: apimName
    policystring: apimPolicystring
  }
}


module installApiPolicy './modules/install-api-policy.bicep' = {
  name: 'installApiPolicy'
  params:{
    apimName: apimName
    apiName: '${toLower(apiName)}-api-${apiVersion}'
    policystring: apiPolicystring
  }
}


module installProductPolicy './modules/install-product-policy.bicep' = {
  name: 'installProductPolicy'
  params:{
    apimName: apimName
    productName: productName
    policystring: productPolicystring
  }
}

output apiOperationPolicyValue string = installApiOperationPolicy.outputs.apiOperationPolicyValue
output apiOpsName string = installApiOperationPolicy.outputs.apiOpsName
output apiOpsDisplayName string = installApiOperationPolicy.outputs.apiOpsDisplayName
output apiOpsDescription string = installApiOperationPolicy.outputs.apiOpsDescription

output apimName string = installApimPolicy.outputs.apimName
output apimPolicyId string = installApimPolicy.outputs.apimPolicyId
output apimPolicyValue string = installApimPolicy.outputs.apimPolicyValue

output apiName string = installApiPolicy.outputs.apiName
output apiPolicyValue string = installApiPolicy.outputs.apiPolicyValue
output apiDisplayName string = installApiPolicy.outputs.apiDisplayName

output productName string = installProductPolicy.outputs.productName
output productPolicyValue string = installProductPolicy.outputs.prouctPolicyValue
output productPolicyId string = installProductPolicy.outputs.productPolicyId

@description('Location')
param Location string = resourceGroup().location

@description('log analytics workspace name')
param LogAnalyticsName string

@description('key vault name')
param vaultName string

@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string

@description('App Gateway Frontend Public IP')
param agwPublicIpName string

@description('Apim Name')
param apimName string = 'UKSPOCAPIM0001'

@description('App Gateway Network ResourceGroup Name')
param AGWNetworkRGName string

@description('Managed Identity Name for key vault user')
@secure()
param managedIdentityKeyVaultSecretUser string

@description('App Gateway Subnet Name')
param appGatewaySubnetName string

@description('App Gateway FrontEnd Private Ip')
param AppGatewayPrivateIP string

@description('wild card cert name')
param wildCardCertName string

var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

var gatewayName = 'apim-agw'

var starInternalConnellsGroupSslCertKeyVaultUri = 'https://${vaultName}${environment().suffixes.keyvaultDns}/secrets/${wildCardCertName}' // ssl cert location


resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: LogAnalyticsName
}

resource vnet 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  name: ExistingVnetName
}

resource agwIPAddress 'Microsoft.Network/publicIPAddresses@2022-11-01' existing = {
  scope: resourceGroup(AGWNetworkRGName)
  name: agwPublicIpName
}

resource apim 'Microsoft.ApiManagement/service@2023-09-01-preview' existing = {
  name: apimName
}

module appGateway './modules/network/application-gateway/main.bicep' = {
  name: '${Timestamp}-apim-agw'
  params: {
    name: 'apim-agw'
    backendAddressPools: [
      {
        name: 'gatewayBackEnd'
        properties: {
          backendAddresses: [
            {
              fqdn: apim.properties.privateIPAddresses[0]
            }
            // {
            //   fqdn: '${apimName}.azure-api.net'
            // }
          ]
        }
      }
    ]
    capacity: 1
    diagnosticSettings: [
      {
        name: 'logToAnalytics'
        logAnalyticsDestinationType: 'AzureDiagnostics'
        logCategoriesAndGroups: [
          {
            category: 'ApplicationGatewayAccessLog'
            enabled: true
          }
          {
            category: 'ApplicationGatewayPerformanceLog'
            enabled: true
          }
          {
            category: 'ApplicationGatewayFirewallLog'
            enabled: true
          }
        ]
        metricCategories: [
          {
            category: 'AllMetrics'
            enabled: true
          }
        ]
        workspaceResourceId: laWorkspace.id
      }
    ]
    backendHttpSettingsCollection: [
      {
        name: 'apim-gateway-https-setting'
        properties: {
          port: 443
          protocol: 'Https'
          cookieBasedAffinity: 'Disabled'
          hostName: '${apimName}.azure-api.net'
          pickHostNameFromBackendAddress: false
          requestTimeout: 20
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes', gatewayName, 'apim-gateway-probe')
          }
        }
      }
    ]
    frontendIPConfigurations: [
      {
        name: 'appGwPublicFrontendIp'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          publicIPAddress: {
            id: agwIPAddress.id
          }
        }
      }
      {
        name: 'appGwPrivateFrontendIp'
        properties: {
          privateIPAllocationMethod: 'Static'
          privateIPAddress: AppGatewayPrivateIP
          subnet: {
            id: '${vnet.id}/subnets/${appGatewaySubnetName}'
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: 'port_443'
        properties: {
          port: 443
        }
      }
    ]
    gatewayIPConfigurations: [
      {
        name: 'appGatewayIpConfig'
        properties: {
          subnet: {
            id: '${vnet.id}/subnets/${appGatewaySubnetName}'
          }
        }
      }
    ]
    httpListeners: [
      {
        name: 'apim-listener-public'
        properties: {
          frontendIPConfiguration: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/frontEndIPConfigurations',
              gatewayName,
              'appGwPublicFrontendIp'
            )
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndPorts', gatewayName, 'port_443')
          }
          protocol: 'Https'
          requireServerNameIndication: false
          sslCertificate: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/sslCertificates',
              gatewayName,
              'starInternalConnellsGroupCoUk'
            )
          }
        }
      }
      {
        name: 'apim-listener-private'
        properties: {
          frontendIPConfiguration: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndIPConfigurations', gatewayName, 'appGwPrivateFrontendIp')
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndPorts', gatewayName, 'port_443')
          }
          protocol: 'Https'
          requireServerNameIndication: false
          sslCertificate: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/sslCertificates',
              gatewayName,
              'starInternalConnellsGroupCoUk'
            )
          }
        }
      }
    ]
    location: Location
    probes: [
      {
        name: 'apim-gateway-probe'
        properties: {
          protocol: 'Https'
          host: '${apimName}.azure-api.net'
          port: 443
          path: '/status-0123456789abcdef'
          interval: 30
          timeout: 120
          unhealthyThreshold: 8
          pickHostNameFromBackendHttpSettings: false
          minServers: 0
        }
      }
    ]
    requestRoutingRules: [
      {
        name: 'apim-routing-rule-public'
        properties: {
          ruleType: 'Basic'
          priority: 1
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners', gatewayName, 'apim-listener-public')
          }
          backendAddressPool: {
            id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools', gatewayName, 'gatewayBackEnd')
          }
          backendHttpSettings: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
              gatewayName,
              'apim-gateway-https-setting'
            )
          }
        }
      }
      {
        name: 'apim-routing-rule-private'
        properties: {
          ruleType: 'Basic'
          priority: 10
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners', gatewayName, 'apim-listener-private')
          }
          backendAddressPool: {
            id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools', gatewayName, 'gatewayBackEnd')
          }
          backendHttpSettings: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
              gatewayName,
              'apim-gateway-https-setting'
            )
          }
        }
      }
    ]
    zones: []
    sku: 'WAF_v2'
    tags: tags
    webApplicationFirewallConfiguration: {
      enabled: true
      firewallMode: 'Detection'
      ruleSetType: 'OWASP'
      ruleSetVersion: '3.2'
      requestBodyCheck: true
      maxRequestBodySizeInKb: 128
      fileUploadLimitInMb: 100
    }
    managedIdentities: {
      userAssignedResourceIds: [
        '/subscriptions/${subscription().subscriptionId}/resourceGroups/${resourceGroup().name}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${managedIdentityKeyVaultSecretUser}'
      ]
    }
    sslCertificates: [
      {
        name: 'starInternalConnellsGroupCoUk'
        properties: {
          keyVaultSecretId: starInternalConnellsGroupSslCertKeyVaultUri
        }
      }
    ]
  }
}

import * as resources from 'functions/project-resource-names.bicep'

@description('Location')
param Location string = resourceGroup().location

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string = subscription().subscriptionId

@description('App Gateway FrontEnd Private Ip')
param AppGatewayPrivateIP string

@description('wild card cert name')
param wildCardCertName string = 'star-internal-connellsgroup-co-uk'

@description('Sku Name')
@allowed([
  'Standard_v2'
  'WAF_v2'
])
param skuName string = 'WAF_v2'

@description('Sku tier')
@allowed([
  'Standard_v2'
  'WAF_v2'
])
param skuTier string = 'WAF_v2'

@description('Specifies the mode of the WAF policy.')
@allowed([
  'Detection'
  'Prevention'
])
param wafPolicyMode string = 'Prevention'

@description('Specifies the state of the WAF policy.')
@allowed([
  'Enabled'
  'Disabled '
])
param wafPolicyState string = 'Enabled'

@description('Specifies the maximum file upload size in Mb for the WAF policy.')
param wafPolicyFileUploadLimitInMb int = 100

@description('Specifies the maximum request body size in Kb for the WAF policy.')
param wafPolicyMaxRequestBodySizeInKb int = 2048

@description('Specifies the whether to allow WAF to check request Body.')
param wafPolicyRequestBodyCheck bool = true

@description('Specifies the rule set type.')
param wafPolicyRuleSetType string = 'OWASP'

@description('Specifies the rule set version.')
param wafPolicyRuleSetVersion string = '3.2'

@description('public cert name')
var publicCertName = 'api-gateway-connellsgroup-co-uk'

@description('Managed Identity Name for key vault user')
var managedIdentityKeyVaultSecretUser = resources.getManagedIdentityKeyVaultSecretUser(Region, Environment, Project)

@description('App Gateway Subnet Name')
var appGatewaySubnetName = resources.getAppGatewaySubnetName(Region, Environment, Project)

@description('App Gateway Frontend Public IP')
var agwPublicIpName = resources.getAppGatewayPublicIpName(Region, Environment, Project)

var echoV1PathMatch = '/echotest/v1/*'
var echoV2PathMatch = '/echotest/v2/*'
var echoV3PathMatch = '/echotest/v3/*'
var branchApiSeqV1PathMatch = '/branch-api-seq/v1/*'
var branchApiSeqV2PathMatch = '/branch-api-seq/v2/*'
var msgFrameworkV1PathMatch = '/msg-framework/v1/*'
var propertyUploadV1PathMatch = '/property-upload/v1/*'
var webFeedV1PathMatch = '/web-feed/v1/*'
var lmsSecureLinkV1PathMatch = '/lms-secure-link/v1/*'
var coreWebServicesV1PathMatch = '/core-web-services/v1/*'
var branchProfileV1PathMatch = '/branch-profile/v1/*'

var vecoDesktopDsarRmsV1PathMatch = '/veco-desktop-dsar-rms/v1/*'
var vecoDesktopDsarConV1PathMatch = '/veco-desktop-dsar-con/v1/*'
var vecoDesktopDsarSeqV1PathMatch = '/veco-desktop-dsar-seq/v1/*'
var vecoDesktopDsarPaV1PathMatch = '/veco-desktop-dsar-pa/v1/*'
var vecoDesktopDsarSqV1PathMatch = '/veco-desktop-dsar-sq/v1/*'

var vecoDesktopBranchRmsV1PathMatch = '/veco-desktop-branch-rms/v1/*'
var vecoDesktopBranchConV1PathMatch = '/veco-desktop-branch-con/v1/*'
var vecoDesktopBranchSeqV1PathMatch = '/veco-desktop-branch-seq/v1/*'
var vecoDesktopBranchPaV1PathMatch = '/veco-desktop-branch-pa/v1/*'
var vecoDesktopBranchSqV1PathMatch = '/veco-desktop-branch-sq/v1/*'

var vecoDesktopMpcRmsV1PathMatch = '/veco-desktop-mpc-rms/v1/*'
var vecoDesktopMpcConV1PathMatch = '/veco-desktop-mpc-con/v1/*'
var vecoDesktopMpcSeqV1PathMatch = '/veco-desktop-mpc-seq/v1/*'
var vecoDesktopMpcPaV1PathMatch = '/veco-desktop-mpc-pa/v1/*'

/*
var vecoDesktopMpcSqV1PathMatch = '/veco-desktop-mpc-sq/v1/*' 
*/

var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

@description('Specifies the name of the app gateway')
var gatewayName = resources.getAppGatewayName(Region, Environment, Project)

@description('Specifies the name of the WAF policy')
var wafPolicyName = '${gatewayName}-WafPolicy'

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('App Gaeway Network ResourceGroup name')
var AGWNetworkRGName = resources.getAPIMNetworkRGName(Region, Environment, Project)

@description('log analytics workspace name')
var LogAnalyticsName = resources.getLogAnalyticsName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

resource kv 'Microsoft.KeyVault/vaults@2024-04-01-preview' existing = {
  name: vaultName
}

resource kvCertSecret 'Microsoft.KeyVault/vaults/secrets@2024-04-01-preview' existing = {
  parent: kv
  name: wildCardCertName
}

resource kvPublicCertSecret 'Microsoft.KeyVault/vaults/secrets@2024-04-01-preview' existing = {
  parent: kv
  name: publicCertName
}

resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: LogAnalyticsName
}

resource vnet 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  name: ExistingVnetName
}

resource agwIPAddress 'Microsoft.Network/publicIPAddresses@2022-11-01' existing = {
  scope: resourceGroup(AGWNetworkRGName)
  name: agwPublicIpName
}

resource apim 'Microsoft.ApiManagement/service@2023-09-01-preview' existing = {
  name: apimName
}

resource wafPolicy 'Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies@2024-01-01' = if (skuName == 'WAF_v2') {
  name: wafPolicyName
  location: Location
  properties: {
    customRules: [
      {
        name: 'BlockMe'
        priority: 1
        ruleType: 'MatchRule'
        action: 'Block'
        matchConditions: [
          {
            matchVariables: [
              {
                variableName: 'QueryString'
              }
            ]
            operator: 'Contains'
            negationConditon: false
            matchValues: [
              'blockme'
            ]
          }
        ]
      }
      {
        name: 'BlockEvilBot'
        priority: 2
        ruleType: 'MatchRule'
        action: 'Block'
        matchConditions: [
          {
            matchVariables: [
              {
                variableName: 'RequestHeaders'
                selector: 'User-Agent'
              }
            ]
            operator: 'Contains'
            negationConditon: false
            matchValues: [
              'evilbot'
            ]
            transforms: [
              'Lowercase'
            ]
          }
        ]
      }
    ]
    policySettings: {
      requestBodyCheck: wafPolicyRequestBodyCheck
      maxRequestBodySizeInKb: wafPolicyMaxRequestBodySizeInKb
      fileUploadLimitInMb: wafPolicyFileUploadLimitInMb
      mode: wafPolicyMode
      state: wafPolicyState
    }
    managedRules: {
      managedRuleSets: [
        {
          ruleSetType: wafPolicyRuleSetType
          ruleSetVersion: wafPolicyRuleSetVersion
        }
      ]
      exclusions: [
        {
          matchVariable: 'RequestArgNames'
          selectorMatchOperator: 'Equals'
          selector: 'SerialisedPayload'
          exclusionManagedRuleSets: [
            {
              ruleSetType: 'OWASP'
              ruleSetVersion: '3.2'
              ruleGroups: [
                {
                  ruleGroupName: 'General'
                  rules: [
                    {
                      ruleId: '200002'
                    }
                    {
                      ruleId: '200003'
                    }
                    {
                      ruleId: '200004'
                    }
                  ]
                }
                {
                  ruleGroupName: 'Known-CVEs'
                  rules: [
                    {
                      ruleId: '800100'
                    }
                    {
                      ruleId: '800110'
                    }
                    {
                      ruleId: '800111'
                    }
                    {
                      ruleId: '800112'
                    }
                    {
                      ruleId: '800113'
                    }
                    {
                      ruleId: '800114'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-911-METHOD-ENFORCEMENT'
                  rules: [
                    {
                      ruleId: '911100'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-913-SCANNER-DETECTION'
                  rules: [
                    {
                      ruleId: '913100'
                    }
                    {
                      ruleId: '913101'
                    }
                    {
                      ruleId: '913102'
                    }
                    {
                      ruleId: '913110'
                    }
                    {
                      ruleId: '913120'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-920-PROTOCOL-ENFORCEMENT'
                  rules: [
                    {
                      ruleId: '920100'
                    }
                    {
                      ruleId: '920120'
                    }
                    {
                      ruleId: '920121'
                    }
                    {
                      ruleId: '920160'
                    }
                    {
                      ruleId: '920170'
                    }
                    {
                      ruleId: '920171'
                    }
                    {
                      ruleId: '920180'
                    }
                    {
                      ruleId: '920190'
                    }
                    {
                      ruleId: '920200'
                    }
                    {
                      ruleId: '920201'
                    }
                    {
                      ruleId: '920202'
                    }
                    {
                      ruleId: '920210'
                    }
                    {
                      ruleId: '920220'
                    }
                    {
                      ruleId: '920230'
                    }
                    {
                      ruleId: '920240'
                    }
                    {
                      ruleId: '920250'
                    }
                    {
                      ruleId: '920260'
                    }
                    {
                      ruleId: '920270'
                    }
                    {
                      ruleId: '920271'
                    }
                    {
                      ruleId: '920272'
                    }
                    {
                      ruleId: '920273'
                    }
                    {
                      ruleId: '920274'
                    }
                    {
                      ruleId: '920280'
                    }
                    {
                      ruleId: '920290'
                    }
                    {
                      ruleId: '920300'
                    }
                    {
                      ruleId: '920310'
                    }
                    {
                      ruleId: '920311'
                    }
                    {
                      ruleId: '920320'
                    }
                    {
                      ruleId: '920330'
                    }
                    {
                      ruleId: '920340'
                    }
                    {
                      ruleId: '920341'
                    }
                    {
                      ruleId: '920350'
                    }
                    {
                      ruleId: '920420'
                    }
                    {
                      ruleId: '920430'
                    }
                    {
                      ruleId: '920440'
                    }
                    {
                      ruleId: '920450'
                    }
                    {
                      ruleId: '920460'
                    }
                    {
                      ruleId: '920470'
                    }
                    {
                      ruleId: '920480'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-921-PROTOCOL-ATTACK'
                  rules: [
                    {
                      ruleId: '921110'
                    }
                    {
                      ruleId: '921120'
                    }
                    {
                      ruleId: '921130'
                    }
                    {
                      ruleId: '921140'
                    }
                    {
                      ruleId: '921150'
                    }
                    {
                      ruleId: '921151'
                    }
                    {
                      ruleId: '921160'
                    }
                    {
                      ruleId: '921170'
                    }
                    {
                      ruleId: '921180'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-930-APPLICATION-ATTACK-LFI'
                  rules: [
                    {
                      ruleId: '930100'
                    }
                    {
                      ruleId: '930110'
                    }
                    {
                      ruleId: '930120'
                    }
                    {
                      ruleId: '930130'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-931-APPLICATION-ATTACK-RFI'
                  rules: [
                    {
                      ruleId: '931100'
                    }
                    {
                      ruleId: '931110'
                    }
                    {
                      ruleId: '931120'
                    }
                    {
                      ruleId: '931130'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-932-APPLICATION-ATTACK-RCE'
                  rules: [
                    {
                      ruleId: '932100'
                    }
                    {
                      ruleId: '932105'
                    }
                    {
                      ruleId: '932106'
                    }
                    {
                      ruleId: '932110'
                    }
                    {
                      ruleId: '932115'
                    }
                    {
                      ruleId: '932120'
                    }
                    {
                      ruleId: '932130'
                    }
                    {
                      ruleId: '932140'
                    }
                    {
                      ruleId: '932150'
                    }
                    {
                      ruleId: '932160'
                    }
                    {
                      ruleId: '932170'
                    }
                    {
                      ruleId: '932171'
                    }
                    {
                      ruleId: '932180'
                    }
                    {
                      ruleId: '932190'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-933-APPLICATION-ATTACK-PHP'
                  rules: [
                    {
                      ruleId: '933100'
                    }
                    {
                      ruleId: '933110'
                    }
                    {
                      ruleId: '933111'
                    }
                    {
                      ruleId: '933120'
                    }
                    {
                      ruleId: '933130'
                    }
                    {
                      ruleId: '933131'
                    }
                    {
                      ruleId: '933140'
                    }
                    {
                      ruleId: '933150'
                    }
                    {
                      ruleId: '933151'
                    }
                    {
                      ruleId: '933160'
                    }
                    {
                      ruleId: '933161'
                    }
                    {
                      ruleId: '933170'
                    }
                    {
                      ruleId: '933180'
                    }
                    {
                      ruleId: '933190'
                    }
                    {
                      ruleId: '933200'
                    }
                    {
                      ruleId: '933210'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-941-APPLICATION-ATTACK-XSS'
                  rules: [
                    {
                      ruleId: '941100'
                    }
                    {
                      ruleId: '941101'
                    }
                    {
                      ruleId: '941110'
                    }
                    {
                      ruleId: '941120'
                    }
                    {
                      ruleId: '941130'
                    }
                    {
                      ruleId: '941140'
                    }
                    {
                      ruleId: '941150'
                    }
                    {
                      ruleId: '941160'
                    }
                    {
                      ruleId: '941170'
                    }
                    {
                      ruleId: '941180'
                    }
                    {
                      ruleId: '941190'
                    }
                    {
                      ruleId: '941200'
                    }
                    {
                      ruleId: '941210'
                    }
                    {
                      ruleId: '941220'
                    }
                    {
                      ruleId: '941230'
                    }
                    {
                      ruleId: '941240'
                    }
                    {
                      ruleId: '941250'
                    }
                    {
                      ruleId: '941260'
                    }
                    {
                      ruleId: '941270'
                    }
                    {
                      ruleId: '941280'
                    }
                    {
                      ruleId: '941290'
                    }
                    {
                      ruleId: '941300'
                    }
                    {
                      ruleId: '941310'
                    }
                    {
                      ruleId: '941320'
                    }
                    {
                      ruleId: '941330'
                    }
                    {
                      ruleId: '941340'
                    }
                    {
                      ruleId: '941350'
                    }
                    {
                      ruleId: '941360'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-942-APPLICATION-ATTACK-SQLI'
                  rules: [
                    {
                      ruleId: '942100'
                    }
                    {
                      ruleId: '942110'
                    }
                    {
                      ruleId: '942120'
                    }
                    {
                      ruleId: '942130'
                    }
                    {
                      ruleId: '942140'
                    }
                    {
                      ruleId: '942150'
                    }
                    {
                      ruleId: '942160'
                    }
                    {
                      ruleId: '942170'
                    }
                    {
                      ruleId: '942180'
                    }
                    {
                      ruleId: '942190'
                    }
                    {
                      ruleId: '942200'
                    }
                    {
                      ruleId: '942210'
                    }
                    {
                      ruleId: '942220'
                    }
                    {
                      ruleId: '942230'
                    }
                    {
                      ruleId: '942240'
                    }
                    {
                      ruleId: '942250'
                    }
                    {
                      ruleId: '942251'
                    }
                    {
                      ruleId: '942260'
                    }
                    {
                      ruleId: '942270'
                    }
                    {
                      ruleId: '942280'
                    }
                    {
                      ruleId: '942290'
                    }
                    {
                      ruleId: '942300'
                    }
                    {
                      ruleId: '942310'
                    }
                    {
                      ruleId: '942320'
                    }
                    {
                      ruleId: '942330'
                    }
                    {
                      ruleId: '942340'
                    }
                    {
                      ruleId: '942350'
                    }
                    {
                      ruleId: '942360'
                    }
                    {
                      ruleId: '942361'
                    }
                    {
                      ruleId: '942370'
                    }
                    {
                      ruleId: '942380'
                    }
                    {
                      ruleId: '942390'
                    }
                    {
                      ruleId: '942400'
                    }
                    {
                      ruleId: '942410'
                    }
                    {
                      ruleId: '942420'
                    }
                    {
                      ruleId: '942421'
                    }
                    {
                      ruleId: '942430'
                    }
                    {
                      ruleId: '942431'
                    }
                    {
                      ruleId: '942432'
                    }
                    {
                      ruleId: '942440'
                    }
                    {
                      ruleId: '942450'
                    }
                    {
                      ruleId: '942460'
                    }
                    {
                      ruleId: '942470'
                    }
                    {
                      ruleId: '942480'
                    }
                    {
                      ruleId: '942490'
                    }
                    {
                      ruleId: '942500'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-943-APPLICATION-ATTACK-SESSION-FIXATION'
                  rules: [
                    {
                      ruleId: '943100'
                    }
                    {
                      ruleId: '943110'
                    }
                    {
                      ruleId: '943120'
                    }
                  ]
                }
                {
                  ruleGroupName: 'REQUEST-944-APPLICATION-ATTACK-JAVA'
                  rules: [
                    {
                      ruleId: '944100'
                    }
                    {
                      ruleId: '944110'
                    }
                    {
                      ruleId: '944120'
                    }
                    {
                      ruleId: '944130'
                    }
                    {
                      ruleId: '944200'
                    }
                    {
                      ruleId: '944210'
                    }
                    {
                      ruleId: '944240'
                    }
                    {
                      ruleId: '944250'
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  }
}

module appGateway './modules/network/application-gateway/main.bicep' = {
  name: '${Timestamp}-${gatewayName}'
  params: {
    name: gatewayName
    backendAddressPools: [
      {
        name: 'defaultBackEnd'
        properties: {
          backendAddresses: []
        }
      }
      {
        name: 'gatewayBackEnd'
        properties: {
          backendAddresses: [
            {
              fqdn: apim.properties.privateIPAddresses[0]
            }
          ]
        }
      }
    ]
    capacity: 1
    autoscaleMinCapacity: 0
    autoscaleMaxCapacity: 5
    diagnosticSettings: [
      {
        name: 'logToAnalytics'
        logAnalyticsDestinationType: 'AzureDiagnostics'
        logCategoriesAndGroups: [
          {
            category: 'ApplicationGatewayAccessLog'
            enabled: true
          }
          {
            category: 'ApplicationGatewayPerformanceLog'
            enabled: true
          }
          {
            category: 'ApplicationGatewayFirewallLog'
            enabled: true
          }
        ]
        metricCategories: [
          {
            category: 'AllMetrics'
            enabled: true
          }
        ]
        workspaceResourceId: laWorkspace.id
      }
    ]
    backendHttpSettingsCollection: [
      {
        name: 'apim-gateway-https-setting'
        properties: {
          port: 443
          protocol: 'Https'
          cookieBasedAffinity: 'Disabled'
          hostName: '${toLower(Environment)}-apim.internal.connellsgroup.co.uk'
          pickHostNameFromBackendAddress: false
          requestTimeout: 300
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes', gatewayName, 'apim-gateway-probe')
          }
        }
      }
    ]
    firewallPolicyResourceId: skuName == 'WAF_v2' ? wafPolicy.id : null
    frontendIPConfigurations: [
      {
        name: 'appGwPublicFrontendIp'
        properties: {
          publicIPAddress: {
            id: agwIPAddress.id
          }
        }
      }
      {
        name: 'appGwPrivateFrontendIp'
        properties: {
          privateIPAllocationMethod: 'Static'
          privateIPAddress: AppGatewayPrivateIP
          subnet: {
            id: '${vnet.id}/subnets/${appGatewaySubnetName}'
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: 'port_443'
        properties: {
          port: 443
        }
      }
    ]
    gatewayIPConfigurations: [
      {
        name: 'appGatewayIpConfig'
        properties: {
          subnet: {
            id: '${vnet.id}/subnets/${appGatewaySubnetName}'
          }
        }
      }
    ]
    httpListeners: [
      {
        name: 'apim-listener-public'
        properties: {
          frontendIPConfiguration: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/frontEndIPConfigurations',
              gatewayName,
              'appGwPublicFrontendIp'
            )
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndPorts', gatewayName, 'port_443')
          }
          protocol: 'Https'
          requireServerNameIndication: false
          sslCertificate: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/sslCertificates',
              gatewayName,
              Environment == 'poc' ? 'starInternalConnellsGroupCoUk' : 'apiGatewayConnellsGroupCoUk'
            )
          }
        }
      }
      {
        name: 'apim-listener-private'
        properties: {
          frontendIPConfiguration: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/frontEndIPConfigurations',
              gatewayName,
              'appGwPrivateFrontendIp'
            )
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontEndPorts', gatewayName, 'port_443')
          }
          protocol: 'Https'
          requireServerNameIndication: false
          sslCertificate: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/sslCertificates',
              gatewayName,
              'starInternalConnellsGroupCoUk'
            )
          }
        }
      }
    ]
    location: Location
    probes: [
      {
        name: 'apim-gateway-probe'
        properties: {
          protocol: 'Https'
          port: 443
          path: '/status-0123456789abcdef'
          interval: 30
          timeout: 120
          unhealthyThreshold: 8
          pickHostNameFromBackendHttpSettings: true
          minServers: 0
        }
      }
    ]
    urlPathMaps: [
      {
        name: 'urlPathMapPrivate'
        properties: {
          defaultBackendAddressPool: {
            id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools', gatewayName, 'defaultBackEnd')
          }
          defaultBackendHttpSettings: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
              gatewayName,
              'apim-gateway-https-setting'
            )
          }
          pathRules: [
            {
              name: 'echoApiPathRuleV1'
              properties: {
                paths: [
                  echoV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV2'
              properties: {
                paths: [
                  echoV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV3'
              properties: {
                paths: [
                  echoV3PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV1'
              properties: {
                paths: [
                  branchApiSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV2'
              properties: {
                paths: [
                  branchApiSeqV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'msgFrameworkPathRuleV1'
              properties: {
                paths: [
                  msgFrameworkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'propertyUploadPathRuleV1'
              properties: {
                paths: [
                  propertyUploadV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'webFeedPathRuleV1'
              properties: {
                paths: [
                  webFeedV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'lmsSecureLinkPathRuleV1'
              properties: {
                paths: [
                  lmsSecureLinkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'coreWebServicesPathRuleV1'
              properties: {
                paths: [
                  coreWebServicesV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchProfilePathRuleV1'
              properties: {
                paths: [
                  branchProfileV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarRmsPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarRmsV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarConPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarConV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarSeqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarPaPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarPaV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarSqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarSqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchRmsPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchRmsV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchConPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchConV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchSeqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchPaPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchPaV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchSqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchSqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcRmsPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcRmsV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcConPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcConV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcSeqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcPaPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcPaV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
          ]
        }
      }
      {
        name: 'urlPathMapPublic'
        properties: {
          defaultBackendAddressPool: {
            id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools', gatewayName, 'defaultBackEnd')
          }
          defaultBackendHttpSettings: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
              gatewayName,
              'apim-gateway-https-setting'
            )
          }
          pathRules: [
            {
              name: 'echoApiPathRuleV1'
              properties: {
                paths: [
                  echoV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV2'
              properties: {
                paths: [
                  echoV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'echoApiPathRuleV3'
              properties: {
                paths: [
                  echoV3PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV1'
              properties: {
                paths: [
                  branchApiSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchSeqApiPathRuleV2'
              properties: {
                paths: [
                  branchApiSeqV2PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'msgFrameworkPathRuleV1'
              properties: {
                paths: [
                  msgFrameworkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'propertyUploadPathRuleV1'
              properties: {
                paths: [
                  propertyUploadV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'webFeedPathRuleV1'
              properties: {
                paths: [
                  webFeedV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'lmsSecureLinkPathRuleV1'
              properties: {
                paths: [
                  lmsSecureLinkV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'coreWebServicesPathRuleV1'
              properties: {
                paths: [
                  coreWebServicesV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'branchProfilePathRuleV1'
              properties: {
                paths: [
                  branchProfileV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarRmsPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarRmsV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarConPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarConV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarSeqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarPaPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarPaV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopDsarSqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopDsarSqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchRmsPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchRmsV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchConPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchConV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchSeqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchPaPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchPaV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopBranchSqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopBranchSqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcRmsPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcRmsV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcConPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcConV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcSeqPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcSeqV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
            {
              name: 'vecoDesktopMpcPaPathRuleV1'
              properties: {
                paths: [
                  vecoDesktopMpcPaV1PathMatch
                ]
                backendAddressPool: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendAddressPools',
                    gatewayName,
                    'gatewayBackEnd'
                  )
                }
                backendHttpSettings: {
                  id: resourceId(
                    'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
                    gatewayName,
                    'apim-gateway-https-setting'
                  )
                }
              }
            }
          ]
        }
      }
    ]
    requestRoutingRules: [
      {
        name: 'apim-routing-rule-public'
        properties: {
          ruleType: 'PathBasedRouting'
          priority: 1
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners', gatewayName, 'apim-listener-public')
          }
          urlPathMap: {
            id: resourceId('Microsoft.Network/applicationGateways/urlPathMaps', gatewayName, 'urlPathMapPublic')
          }
        }
      }
      {
        name: 'apim-routing-rule-private'
        properties: {
          ruleType: 'PathBasedRouting'
          priority: 10
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httpListeners', gatewayName, 'apim-listener-private')
          }
          urlPathMap: {
            id: resourceId('Microsoft.Network/applicationGateways/urlPathMaps', gatewayName, 'urlPathMapPrivate')
          }
        }
      }
    ]
    zones: []
    sku: skuTier
    tags: tags
    managedIdentities: {
      userAssignedResourceIds: [
        '/subscriptions/${subscription().subscriptionId}/resourceGroups/${resourceGroup().name}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${managedIdentityKeyVaultSecretUser}'
      ]
    }
    sslCertificates: [
      {
        name: 'starInternalConnellsGroupCoUk'
        properties: {
          keyVaultSecretId: kvCertSecret.properties.secretUri
        }
      }
      {
        name: 'apiGatewayConnellsGroupCoUk'
        properties: {
          keyVaultSecretId: kvPublicCertSecret.properties.secretUri
        }
      }
    ]
    sslPolicyCipherSuites: [
      'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384'
      'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256'
      'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384'
      'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256'
    ]
    sslPolicyMinProtocolVersion: 'TLSv1_2'
    sslPolicyType: 'Custom'
  }
}

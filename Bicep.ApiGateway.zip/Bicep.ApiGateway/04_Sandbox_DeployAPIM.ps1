function ParamBuilder
{
   param([Object]$ParamArg)
   $Arg = [PSCustomObject]::new()
   foreach ($Param in $ParamArg)
   {
      if ($Param.Value.Length -gt 0)
      {
         Write-Host Adding $Param.Name to parameter list with value $Param.Value
         $Arg | Add-Member NoteProperty -Name $Param.Name -Value ([PSCustomObject] @{ value = $Param.Value })
      } 
   }
   return ($Arg | ConvertTo-Json -Compress).Replace('"', '\"')
}

$azureApplicationId = "b648d3ac-2c67-40c4-848a-2787fa604395"                                             #$OctopusParameters["AzureAccount.Client"]
$azureTenantId = "07808216-ca18-4f9b-b249-7d53dadb5344"                                                  #$OctopusParameters["AzureAccount.TenantId"]
$azurePassword = ConvertTo-SecureString "PGi8Q~~7ikIZA-LD2WTiBd5J.e~hz4XYJasfFaYk" -AsPlainText -Force   #$OctopusParameters["AzureAccount.Password"]
$subscriptionId = "3f88752d-7039-4e85-b9b9-22dd7b8adfb6"                                                 #$OctopusParameters["DunnoWhereWe'reGettin.ThisFromYet"]

############################
#### Authentication
############################
Write-Host AppId: $azureApplicationId
Write-Host Tenant: $azureTenantId
Write-Host Subscr: $subscriptionId
Write-Host Password: $azurePassword
   
$AzCred = New-Object System.Management.Automation.PSCredential($azureApplicationId , $azurePassword)
$AzLogin = az login --service-principal -u $AzCred.UserName -p $AzCred.GetNetworkCredential().Password --tenant $azureTenantId | ConvertFrom-Json
az account set --subscription $subscriptionId 
$acc = az account show | ConvertFrom-Json
Write-Host "Subscription scoped to"  $acc.name "-" $acc.id

####################
# Parent
####################
$DeploymentParentName = "ApiGatewayAPIMPoC" 
$BicepParentFilePath = ".\ApiGatewayAPIM.bicep"
$ResourceGroupName = "UKS-POC-RSG0020-ApiGateway"


$LogAnalyticsName = "UKS-POC-LAI0001-ApiGateway"
$AppInsightsName = "UKS-POC-AIN0001-ApiGateway"
$vaultName ="UKSPOCKVT0001ApiGateway"
$wildCardCertName = "star-internal-connellsgroup-co-uk"

$ExistingVnetName = 'AZSPOC-VNET'
$ExistingVnetRG = 'UKS-TST-RSG0001-Network'
$ExistingVnetSubscription = '3f88752d-7039-4e85-b9b9-22dd7b8adfb6'
$subnet01Name  = 'UKS-POC-SUB0001-ApiGateway'

$apimName = 'UKSPOCAPIM0001'
$apimPublicIpName = 'apimPublicIP'
$APIMNetworkRGName = "UKS-POC-RSG0021-ApiGateway-Network"

$publisherName = 'Connells Group' 
$publisherEmail = 'olusola.adio@connellsgroup.co.uk'
$notificationSenderEmail = 'olusola.adio@connellsgroup.co.uk'
$apimPricingTier = 'Developer'
$apimCapacity = 1
$virtualNetworkType = 'Internal'
$managedIdentityKeyVaultSecretUser = "UKS-POC-MI-KV-SecretUser"
$deployBasicConfiguration = "Full"
$apimCustomUrlPrefix = 'poc-apim'


$Params = @(
   [PSCustomObject]@{ Name = "LogAnalyticsName"; Value = $LogAnalyticsName }
   [PSCustomObject]@{ Name = "AppInsightsName"; Value = $AppInsightsName }
   [PSCustomObject]@{ Name = "StorageAccountName"; Value = $StorageAccountName }
   [PSCustomObject]@{ Name = "ManagedIdentityStorageContributorName"; Value = $ManagedIdentityStorageContributorName }
   [PSCustomObject]@{ Name = "vaultName"; Value = $vaultName }
   [PSCustomObject]@{ Name = "wildCardCertName"; Value = $wildCardCertName }
   [PSCustomObject]@{ Name = "ExistingVnetName"; Value = $ExistingVnetName }   
   [PSCustomObject]@{ Name = "ExistingVnetRG"; Value = $ExistingVnetRG }   
   [PSCustomObject]@{ Name = "ExistingVnetSubscription"; Value = $ExistingVnetSubscription }   
   [PSCustomObject]@{ Name = "subnet01Name"; Value = $subnet01Name }
   [PSCustomObject]@{ Name = "subnet02Name"; Value = $subnet02Name }
   [PSCustomObject]@{ Name = "apimPublicIpName"; Value = $apimPublicIpName }
   [PSCustomObject]@{ Name = "apimName"; Value = $apimName }
   [PSCustomObject]@{ Name = "publisherName"; Value = $publisherName }
   [PSCustomObject]@{ Name = "publisherEmail"; Value = $publisherEmail }
   [PSCustomObject]@{ Name = "notificationSenderEmail"; Value = $notificationSenderEmail }
   [PSCustomObject]@{ Name = "apimPricingTier"; Value = $apimPricingTier }
   [PSCustomObject]@{ Name = "apimIdentity"; Value = $apimIdentity }
   [PSCustomObject]@{ Name = "apimCapacity"; Value = $apimCapacity } 
   [PSCustomObject]@{ Name = "virtualNetworkType"; Value = $virtualNetworkType }
   [PSCustomObject]@{ Name = "APIMNetworkRGName"; Value = $APIMNetworkRGName } 
   [PSCustomObject]@{ Name = "managedIdentityKeyVaultSecretUser"; Value = $managedIdentityKeyVaultSecretUser }
   [PSCustomObject]@{ Name = "deployBasicConfiguration"; Value = $deployBasicConfiguration }
   [PSCustomObject]@{ Name = "apimCustomUrlPrefix"; Value = $apimCustomUrlPrefix }
   )
$ParamString = ParamBuilder -ParamArg $Params

Write-Host Deploying $DeploymentParentName

az deployment group create `
   --resource-group $ResourceGroupName `
   --template-file $BicepParentFilePath `
   --name $DeploymentParentName `
   --parameters $ParamString `
   --debug

Write-Host Deployment complete

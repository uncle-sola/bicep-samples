# This line should point to the folder containing the checked out "PowerShellUtilities" repo from IT Devops
# This is required for the Octopus integration to retrieve project metadata
$PSUtilBaseDir = "..\Powershell%20Utilities\"
. ([System.IO.Path]::Join($PSUtilBaseDir, "Octo_Toolkit_BaseClasses.ps1"))
. ([System.IO.Path]::Join($PSUtilBaseDir, "Octo_Toolkit_Helpers.ps1"))
. ([System.IO.Path]::Join($PSUtilBaseDir, "Octo_Toolkit_OctoServer.ps1"))
. ([System.IO.Path]::Join($PSUtilBaseDir, "Octo_Toolkit_Repository.ps1"))
. ([System.IO.Path]::Join($PSUtilBaseDir, "Octo_Toolkit.ps1"))

$SpaceName = "IaC"
$ProjectNames = @(
   "apigateway-baseinfra"
   "apigateway-network"
   "apigateway-infra"
   "apigateway-apim"
   "apigateway-agw"
   "apigateway-jumpbox"
   "apigateway-api"
   "apigateway-policytov2"
)

$Repository = [OctoRepository]::new()

$ProjectList = @()

foreach ($ProjectName in $ProjectNames)
{
   $Project = $Repository.GetProjectByName($ProjectName, $SpaceName)
   $ProjectList += [PSCustomObject]@{ Name = $Project.Name; Id = $Project.Id; GroupId = $Project.ProjectGroupId; SpaceId = $Project.SpaceId }
}

Write-Output $ProjectList

foreach ($Project in $ProjectList)
{
   $BicepParentFile = ($Project.Name.Replace(".", "") + ".bicep")
   $PipelineFilePath = ([System.IO.Path]::Join(".\pipelines", ($Project.Name + "-Octopus.yml")))

   #TODO: Generator for outline variables file - needs to be optional / parameter driven
   #$PipelineVariablesFilePath = ([System.IO.Path]::Join(".\pipelines", ($Project.Name + "-Octopus-variables.yml")))
   #$sb = [System.Text.StringBuilder]::new()
   #[void]$sb.AppendLine("variables:")
   #[void]$sb.AppendLine("   CopySource: '`$(Build.SourcesDirectory)/'")
   #[void]$sb.AppendLine("   CopyContents: '$BicepParentFile'")
   #[void]$sb.AppendLine("   CopyOutput: '`$(Build.ArtifactStagingDirectory)/$($Project.Name.Replace("-", ".")).`$(Build.Buildnumber)'")
   #[void]$sb.AppendLine("   ArchiveSource: '`$(Build.ArtifactStagingDirectory)/$($Project.Name.Replace("-", ".")).`$(Build.Buildnumber)/*'")
   #[void]$sb.AppendLine("   ArchiveOutput: '`$(Build.ArtifactStagingDirectory)/$($Project.Name.Replace("-", ".")).`$(Build.Buildnumber).zip'")
   #[void]$sb.AppendLine("   OctopusGroup: '$($Project.GroupId)'")
   #[void]$sb.AppendLine("   OctopusProject: '$($Project.Id)'")
   #[void]$sb.AppendLine("   OctopusSpace: 'Spaces-62'")
   #[void]$sb.Append("   ReleaseNumber: '`$(Build.BuildNumber)'")
   #$sb.ToString().Trim() | Out-File -Append $PipelineVariablesFilePath

   $PipelineFileTemplate = `
@"
# Versions will differ depending on the pipeline they are used in
# Please ensure that you have the correct versioning before running your pipeline
name: `$(major).`$(minor)`$(Rev:.r)
variables:
   major: 0
   minor: 1

trigger: none

pool:
  name: default

resources:
  repositories:
    - repository: templates
      type: git
      name: IT DevOps/YamlTemplates

stages:
- stage: $($Project.Name.Replace(".", "_").Replace("-", "_"))
  
  jobs:
  - job: Package_Files

    steps:
    # Template file located in YamlTemplates repo in the Group folder
    - template: Groups/azure-pipelines-Bicep.yml@templates
      parameters:
        CopySource: '`$(Build.SourcesDirectory)/'
        CopyContents: '$BicepParentFile'
        CopyOutput: '`$(Build.ArtifactStagingDirectory)/$($Project.Name.Replace("-", ".")).`$(Build.Buildnumber)'
        ArchiveSource: '`$(Build.ArtifactStagingDirectory)/$($Project.Name.Replace("-", ".")).`$(Build.Buildnumber)/*'
        ArchiveOutput: '`$(Build.ArtifactStagingDirectory)/$($Project.Name.Replace("-", ".")).`$(Build.Buildnumber).zip'
        OctopusSpace: '$($Project.SpaceId)'
        OctopusGroup: '$($Project.GroupId)'
        OctopusProject: '$($Project.Id)'
        ReleaseNumber: '`$(Build.BuildNumber)'
        Channel: `${{ variables.Channel }}
"@

   Write-Host Creating $PipelineFilePath for $Project.Name
   $PipelineFileTemplate.TrimEnd() | Out-File -Append $PipelineFilePath

}


function ParamBuilder
{
   param([Object]$ParamArg)
   $Arg = [PSCustomObject]::new()
   foreach ($Param in $ParamArg)
   {
      if ($Param.Value.Length -gt 0)
      {
         Write-Host Adding $Param.Name to parameter list with value $Param.Value
         $Arg | Add-Member NoteProperty -Name $Param.Name -Value ([PSCustomObject] @{ value = $Param.Value })
      } 
   }
   return ($Arg | ConvertTo-Json -Compress).Replace('"', '\"')
}

$azureApplicationId = "b648d3ac-2c67-40c4-848a-2787fa604395"                                             #$OctopusParameters["AzureAccount.Client"]
$azureTenantId = "07808216-ca18-4f9b-b249-7d53dadb5344"                                                  #$OctopusParameters["AzureAccount.TenantId"]
$azurePassword = ConvertTo-SecureString "PGi8Q~~7ikIZA-LD2WTiBd5J.e~hz4XYJasfFaYk" -AsPlainText -Force   #$OctopusParameters["AzureAccount.Password"]
$subscriptionId = "3f88752d-7039-4e85-b9b9-22dd7b8adfb6"                                                 #$OctopusParameters["DunnoWhereWe'reGettin.ThisFromYet"]

############################
#### Authentication
############################
Write-Host AppId: $azureApplicationId
Write-Host Tenant: $azureTenantId
Write-Host Subscr: $subscriptionId
Write-Host Password: $azurePassword
   
$AzCred = New-Object System.Management.Automation.PSCredential($azureApplicationId , $azurePassword)
$AzLogin = az login --service-principal -u $AzCred.UserName -p $AzCred.GetNetworkCredential().Password --tenant $azureTenantId | ConvertFrom-Json
az account set --subscription $subscriptionId 
$acc = az account show | ConvertFrom-Json
Write-Host "Subscription scoped to"  $acc.name "-" $acc.id

####################
# Parent
####################
$DeploymentParentName = "112_DeployVecoDesktopDsarSqAPI" 
$BicepParentFilePath = ".\apis\112_DeployVecoDesktopDsarSqAPI\112_DeployVecoDesktopDsarSqAPI.bicep"
$Region = "uks"
$Environment = "poc"
$Project = "apigateway"
$RgType = "infra"
$instance = "0031"
$ResourceGroupName = "${Region}-${Environment}-rsg${instance}-${Project}-${RgType}"


$Params = @(
   [PSCustomObject]@{ Name = "Region"; Value = $Region }
   [PSCustomObject]@{ Name = "Environment"; Value = $Environment }
   [PSCustomObject]@{ Name = "Project"; Value = $Project }     
   )
$ParamString = ParamBuilder -ParamArg $Params

Write-Host Deploying $DeploymentParentName

az deployment group create `
   --resource-group $ResourceGroupName `
   --template-file $BicepParentFilePath `
   --name $DeploymentParentName `
   --parameters $ParamString 

Write-Host Deployment complete

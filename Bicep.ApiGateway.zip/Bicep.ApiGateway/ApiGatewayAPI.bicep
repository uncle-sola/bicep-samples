param apimName string
param apiName string
param apiFormat string = 'openapi-link'
param apiVersion string
param versionSetName string

var openApiSpec = loadTextContent('./api-specs/EchoAPI.openapi.yaml')

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}

module imporEchoAPI './modules/import-api.bicep' = {
  name: 'importEchoAPIModule'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(apiName)}-api-${apiVersion}'
    apiUrl: openApiSpec
    apiPath: apiName
    apiDisplayName: '${toUpper(first(apiName))}${toLower(substring(apiName, 1, length(apiName) -1 ))} API ${apiVersion}'
    apiVersion: apiVersion
    productDescription: '${toUpper(apiName)} API Product'
    productDisplayName: '${toUpper(apiName)} API'
    productName: '${toUpper(apiName)}API'
    format: apiFormat
    versionSetName: versionSetName
    versionSetDisplayName:'${toUpper(first(apiName))}${toLower(substring(apiName, 1, length(apiName) -1 ))} API'
  }
  dependsOn: [
    apim
  ]
}


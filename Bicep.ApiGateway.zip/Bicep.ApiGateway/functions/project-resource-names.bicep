import * as functions from 'functions.bicep'

@export()
func getLogAnalyticsName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.logAnalyticsResource, '0019')

@export()
func getAppInsightsName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.AppInsightResource, '0028')

@export()
func getStorageAccountNameApiLoad(region string, env string, proj string) string =>
  functions.getStorageAccountName(region, env, proj, functions.StorageAccount, '0021')
  
@export()
func getInfraResourceGroupName(region string, env string, proj string) string =>
  functions.getResourceGroupName(region, env, '0031', proj, functions.InfrastructureResourceGroupType)

@export()
@description('Apim Network ResourceGroup name')
func getAPIMNetworkRGName(region string, env string, proj string) string =>
  functions.getResourceGroupName(region, env, '0032', proj, functions.NetworkResourceGroupType)

@export()
@description('Optional. Public Standard SKU IP V4 based IP address to be associated with Virtual Network deployed service in the region. Supported only for Developer and Premium SKU being deployed in Virtual Network.')
func getApimPublicIpName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.PublicIpAddressResource, '0001')

@export()
@description('App Gateway Public IP')
func getAppGatewayPublicIpName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.PublicIpAddressResource, '0002')

@export()
@description('Jump Box IP')
func getJumpBoxPublicIpName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.PublicIpAddressResource, '0003')

@export()
@description('RouteTable name')
func getRouteTableName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.RouteTableResource, '0001')

@export()
@description('Apim subnet name')
func getApimSubnetName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.SubnetResource, '0001')

@export()
@description('App Gateway Subnet Name')
func getAppGatewaySubnetName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.SubnetResource, '0002')

@export()
@description('Infra subnet name')
func getInfraSubnetName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.SubnetResource, '0003')

@export()
@description('Apim subnet NSG name')
func getApimSubnetNsgName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.NsgResource, '0001')

@export()
@description('App Gateway Subnet NSG Name')
func getAppGatewaySubnetNsgName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.NsgResource, '0002')

@export()
@description('Infra subnet NSG name')
func getInfraSubnetNsgName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.NsgResource, '0003')

@export()
@description('Key vault name')
func getKeyVaultName(region string, env string, proj string) string =>
  functions.getKeyVaultName(region, env, functions.KeyvaultResource, '0007')

@export()
@description('VM name')
func getVmName(region string, env string, proj string) string =>
  functions.getVirtualMachineName(region, env, functions.VirtualMachineResource, '0001')

@export()
@description('Managed Identity Name for key vault user')
func getManagedIdentityKeyVaultSecretUser(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.ManagedIdentityResource, '0001-secret-user')

@export()
@description('Managed Identity Name for key vault user')
func getManagedIdentityApiCaller(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.ManagedIdentityResource, '0002-api-caller')  

@export()
@description('The name of the API Management service.')
func getApimName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.ApimResource, '0001')

@export()
@description('Specifies the name of the app gateway')
func getAppGatewayName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.AppGatewayResource, '0001')

@export()
@description('NIC Name.')
func getInterfaceCardName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.NetworkInterfaceCardResource, '0001')

@export()
@description('OS disk Name')
func getOsDiskName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.OsDiskResource, '0001')

@export()
@description('VNet Name')
func getVnetName(region string, env string, proj string) string =>
  functions.getResourceName(region, env, proj, functions.VNetResource, '0001')



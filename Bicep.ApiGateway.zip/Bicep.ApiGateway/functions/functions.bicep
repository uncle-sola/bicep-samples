@export()
type resourceType =
  | 'pip'
  | 'nsg'
  | 'lai'
  | 'ain'
  | 'vnt'
  | 'sub'
  | 'rtb'
  | 'kyv'
  | 'agw'
  | 'waf'
  | 'apm'
  | 'mid'
  | 'nic'
  | 'vm'
  | 'osd'
  | 'sta'

@export()
var logAnalyticsResource = 'lai'

@export()
var AppInsightResource = 'ain'

@export()
var StorageAccount = 'sta'

@export()
var VNetResource = 'vnt'

@export()
var SubnetResource = 'sub'

@export()
var RouteTableResource = 'rtb'

@export()
var NsgResource = 'nsg'

@export()
var PublicIpAddressResource = 'pip'

@export()
var KeyvaultResource = 'kyv'

@export()
var AppGatewayResource = 'agw'

@export()
var WafResource = 'waf'

@export()
var ApimResource = 'apm'

@export()
var ManagedIdentityResource = 'mid'

@export()
var NetworkInterfaceCardResource = 'nic'

@export()
var VirtualMachineResource = 'vm'

@export()
var OsDiskResource = 'osd'

@export()
func getResourceName(region string, env string, proj string, resourceType resourceType, instance string) string =>
  toLower('${region}-${env}-${resourceType}${instance}-${proj}')

@export()
  func getStorageAccountName(region string, env string, proj string, resourceType resourceType, instance string) string =>
    toLower('${region}${env}${resourceType}${instance}${proj}')

@export()
func getKeyVaultName(region string, env string, resourceType resourceType, instance string) string =>
  toLower('${region}-${env}-${resourceType}${instance}')

@export()
func getVirtualMachineName(region string, env string, resourceType resourceType, instance string) string =>
  toLower('${region}-${env}-${resourceType}${instance}')

// region-env-resType!!instance-project

// kv stop at the numbers uks-poc-mid01-secret-user-apigateway
// var managedIdentityKeyVaultSecretUser = functions.getResourceName(Region, Environment, Project, functions.ManagedIdentityResource, '01-secret-user') 

@export()
func getFirstLetterUppercase(inputString string) string =>
  '${toUpper(first(inputString))}${toLower(substring(inputString, 1, length(inputString) -1 ))}'

@export()
type resourceGroupType = 'network' | 'infra' | 'vm'

@export()
var NetworkResourceGroupType = 'network'

@export()
var VirtualMachineResourceGroupType = 'vm'

@export()
var InfrastructureResourceGroupType = 'infra'

@export()
func getResourceGroupName(region string, env string, instance string, proj string, resourceGroupType resourceGroupType) string =>
  toLower('${region}-${env}-rsg${instance}-${proj}-${resourceGroupType}')

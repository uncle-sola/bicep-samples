import * as resources from 'functions/project-resource-names.bicep'

param Location string = resourceGroup().location

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

param addressPrefix string


param BusinessUnitTag string = 'New Business Unit'
param CompanyTag string = 'Connells Group'
param ContactTag string = 'Dev - Online'
param SolutionName string = 'ApiGateway'
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

var tags= {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}

var vNetName = resources.getVnetName(Region, Environment, Project)

module VNet './modules/VNet.bicep' = {
  name: '${Timestamp}-vnet'
  params:{
    vNetName: vNetName
    tags: tags
    addressPrefix: addressPrefix
    location: Location
  }
  dependsOn:[
  ]
}

@description('Location')
param Location string = resourceGroup().location

@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string

@description('Apim Subnet IP range')
param subnet01Range string

@description('Infra Subnet IP range')
param subnet02Range string

@description('App Gateway Subnet IP Range')
param appGatewaySubnetIp string

@description('Apim subnet name')
param subnet01Name string

@description('Infra subnet name')
param subnet02Name string

@description('App Gateway Subnet Name')
param appGatewaySubnetName string

@description('RouteTable name')
param routeTableName string

@description('NSG name for subnet 1')
param nsg1Name string

@description('NSG name for subnet 2')
param nsg2Name string

@description('Optional. Public Standard SKU IP V4 based IP address to be associated with Virtual Network deployed service in the region. Supported only for Developer and Premium SKU being deployed in Virtual Network.')
param apimPublicIp string

@description('App Gateway Public IP')
param agwPublicIp string


@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('log analytics workspace name')
param LogAnalyticsName string

@description('log analytics workspace RG name')
param LogAnalyticsResourceGroupName string


var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}


module agwIPAddress './modules/network/public-ip-address/main.bicep' = {
  name: '${Timestamp}-agwIPAddress'
  params: {
    name: agwPublicIp
    dnsSettings: {
      domainNameLabel: toLower(agwPublicIp)
      fqdn: '${toLower(agwPublicIp)}.azure-api.net'
      domainNameLabelScope: ''
    }
    ddosSettings: {
      protectionMode: 'Enabled'
    }
    ipTags: []
    location: Location
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    skuName: 'Standard'
    skuTier: 'Regional'
    tags: tags
    zones: [
      2
      1
      3
    ]
  }
}

module apimIPAddress './modules/network/public-ip-address/main.bicep' = {
  name: '${Timestamp}-apimIPAddress'
  params: {
    name: apimPublicIp
    dnsSettings: {
      domainNameLabel: toLower(apimPublicIp)
      fqdn: '${toLower(apimPublicIp)}.azure-api.net'
      domainNameLabelScope: ''
    }
    ddosSettings: {
      protectionMode: 'Enabled'
    }
    ipTags: []
    location: Location
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    skuName: 'Standard'
    skuTier: 'Regional'
    tags: tags
    zones: [
      2
      1
      3
    ]
  }
}
module RouteTable './modules/RouteTable.bicep' = {
  name: '${Timestamp}-RouteTable'
  params: {
    rtName: routeTableName
    location: Location
    apimPublicIp: apimIPAddress.outputs.ipAddress
    tags: tags
  }
  dependsOn: [
    apimIPAddress
  ]
}


module APIMNSG1Rules './modules/APIMSubnetNSGRules.bicep' = {
  name: '${Timestamp}-APIMNSG1Rules'
  params: {
    apimSubnetNsg: true
    nsgName: nsg1Name
    tags: tags
    location: Location
    LogAnalyticsName: LogAnalyticsName
    LogAnalyticsResourceGroupName: LogAnalyticsResourceGroupName
  }
}

module APIMNSG2Rules './modules/APIMSubnetNSGRules.bicep' = {
  name: '${Timestamp}-APIMNSG2Rules'
  params: {
    apimSubnetNsg: false
    nsgName: nsg2Name
    tags: tags
    location: Location
    LogAnalyticsName: LogAnalyticsName
    LogAnalyticsResourceGroupName: LogAnalyticsResourceGroupName
  }
}

module AppGatewayNSGRules './modules/applicationgwnsg.bicep' = {
  name: '${Timestamp}-AppGatewayNSGRules'
  params: {
    appGwNetworkSecurityGroupName: 'AppGatewayNSGRules'
    tags: tags
    location: Location
    LogAnalyticsName: LogAnalyticsName
    LogAnalyticsResourceGroupName: LogAnalyticsResourceGroupName
  }
}

module Subnet1 './modules/network/virtual-network/subnet/main.bicep' = {
  name: '${Timestamp}-subnet1'
  scope: resourceGroup(subscription().subscriptionId, ExistingVnetRG)
  params: {
    virtualNetworkName: ExistingVnetName
    networkSecurityGroupResourceId: APIMNSG1Rules.outputs.id
    name: subnet01Name
    addressPrefix: subnet01Range
    routeTableResourceId: RouteTable.outputs.id
    privateEndpointNetworkPolicies: 'Enabled'
    privateLinkServiceNetworkPolicies: 'Enabled'
    serviceEndpoints: [
      'Microsoft.KeyVault'
      'Microsoft.ServiceBus'
      'Microsoft.Sql'
      'Microsoft.Storage'
      'Microsoft.Web'
      'Microsoft.EventHub'
    ]
  }
  dependsOn: [
    APIMNSG1Rules
    APIMNSG2Rules
    AppGatewayNSGRules
    RouteTable
  ]
}

module Subnet2 './modules/network/virtual-network/subnet/main.bicep' = {
  name: '${Timestamp}-subnet2'
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  params: {
    virtualNetworkName: ExistingVnetName
    name: subnet02Name
    addressPrefix: subnet02Range
    networkSecurityGroupResourceId: APIMNSG2Rules.outputs.id
    routeTableResourceId: RouteTable.outputs.id
    privateEndpointNetworkPolicies: 'Enabled'
    privateLinkServiceNetworkPolicies: 'Enabled'
    serviceEndpoints: [
      'Microsoft.KeyVault'
      'Microsoft.ServiceBus'
      'Microsoft.Sql'
      'Microsoft.Storage'
      'Microsoft.Web'
      'Microsoft.EventHub'
    ]
  }
  dependsOn: [
    Subnet1
  ]
}

module Subnet3 './modules/network/virtual-network/subnet/main.bicep' = {
  name: '${Timestamp}-subnet3'
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  params: {
    virtualNetworkName: ExistingVnetName
    name: appGatewaySubnetName
    addressPrefix: appGatewaySubnetIp
    networkSecurityGroupResourceId: AppGatewayNSGRules.outputs.id
    privateEndpointNetworkPolicies: 'Disabled'
    privateLinkServiceNetworkPolicies: 'Enabled'
    serviceEndpoints: ['Microsoft.KeyVault', 'Microsoft.Web']
  }
  dependsOn: [
    Subnet2
  ]
}

import * as resources from 'functions/project-resource-names.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Location')
param Location string = resourceGroup().location

@description('Existing VNet Name')
param ExistingVnetName string

@description('Existing VNet Resourcegroup Name')
param ExistingVnetRG string

@description('Existing VNet Subscription')
param ExistingVnetSubscription string = subscription().subscriptionId

@description('Apim Subnet IP range')
param subnet01Range string

@description('Infra Subnet IP range')
param subnet02Range string

@description('App Gateway Subnet IP Range')
param subnet03Range string

@description('Apim subnet name')
var apimSubnetName = resources.getApimSubnetName(Region, Environment, Project)

@description('App Gateway Subnet Name')
var appGatewaySubnetName = resources.getAppGatewaySubnetName(Region, Environment, Project)

@description('Infra subnet name')
var infraSubnetName = resources.getInfraSubnetName(Region, Environment, Project)

@description('RouteTable name')
var routeTableName = resources.getRouteTableName(Region, Environment, Project)

@description('NSG name for subnet 1')
var nsg1Name = resources.getApimSubnetNsgName(Region, Environment, Project)

@description('NSG name for subnet 2')
var nsg2Name = resources.getAppGatewaySubnetNsgName(Region, Environment, Project)

@description('NSG name for subnet 3')
var nsg3Name = resources.getInfraSubnetNsgName(Region, Environment, Project)

@description('Optional. Public Standard SKU IP V4 based IP address to be associated with Virtual Network deployed service in the region. Supported only for Developer and Premium SKU being deployed in Virtual Network.')
var apimPublicIp = resources.getApimPublicIpName(Region, Environment, Project)

@description('App Gateway Public IP')
var agwPublicIp = resources.getAppGatewayPublicIpName(Region, Environment, Project)

@description('Jump Box IP')
var jumpBoxIp = resources.getJumpBoxPublicIpName(Region, Environment, Project) 

@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('log analytics workspace name')
var LogAnalyticsName = resources.getLogAnalyticsName(Region, Environment, Project)

@description('log analytics workspace RG name')
var LogAnalyticsResourceGroupName = resources.getInfraResourceGroupName(Region, Environment, Project)


var tags = {
  Solution: SolutionName
  Company: CompanyTag
  'Business Unit': BusinessUnitTag
  Contact: ContactTag
}


module agwIPAddress './modules/network/public-ip-address/main.bicep' = {
  name: '${Timestamp}-agwIPAddress'
  params: {
    name: agwPublicIp
    dnsSettings: {
      domainNameLabel: toLower(agwPublicIp)
      fqdn: '${toLower(agwPublicIp)}.azure-api.net'
      domainNameLabelScope: 'TenantReuse'
    }
    ddosSettings: {
      protectionMode: 'Enabled'
    }
    ipTags: []
    location: Location
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    skuName: 'Standard'
    skuTier: 'Regional'
    tags: tags
    zones: [
      2
      1
      3
    ]
  }
}

module apimIPAddress './modules/network/public-ip-address/main.bicep' = {
  name: '${Timestamp}-apimIPAddress'
  params: {
    name: apimPublicIp
    dnsSettings: {
      domainNameLabel: toLower(apimPublicIp)
      fqdn: '${toLower(apimPublicIp)}.azure-api.net'
      domainNameLabelScope: 'TenantReuse'
    }
    ddosSettings: {
      protectionMode: 'Enabled'
    }
    ipTags: []
    location: Location
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    skuName: 'Standard'
    skuTier: 'Regional'
    tags: tags
    zones: [
      2
      1
      3
    ]
  }
}

module jumpBoxIPAddress './modules/network/public-ip-address/main.bicep' = {
  name: '${Timestamp}-jumpBoxIPAddress'
  params: {
    name: jumpBoxIp
    dnsSettings: {
      domainNameLabel: toLower(jumpBoxIp)
      fqdn: '${toLower(jumpBoxIp)}.azure-api.net'
      domainNameLabelScope: 'TenantReuse'
    }
    ddosSettings: {
      protectionMode: 'Enabled'
    }
    ipTags: []
    location: Location
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    skuName: 'Standard'
    skuTier: 'Regional'
    tags: tags
    zones: [
      2
      1
      3
    ]
  }
}

module RouteTable './modules/RouteTable.bicep' = {
  name: '${Timestamp}-RouteTable'
  params: {
    rtName: routeTableName
    location: Location
    apimPublicIp: apimIPAddress.outputs.ipAddress
    tags: tags
  }
}


module APIMNSG1Rules './modules/APIMSubnetNSGRules.bicep' = {
  name: '${Timestamp}-APIMNSG1Rules'
  params: {
    apimSubnetNsg: true
    nsgName: nsg1Name
    tags: tags
    location: Location
    LogAnalyticsName: LogAnalyticsName
    LogAnalyticsResourceGroupName: LogAnalyticsResourceGroupName
  }
}


module AppGatewayNSG2Rules './modules/applicationgwnsg.bicep' = {
  name: '${Timestamp}-AppGatewayNSG2Rules'
  params: {
    appGwNetworkSecurityGroupName: nsg2Name
    tags: tags
    location: Location
    LogAnalyticsName: LogAnalyticsName
    LogAnalyticsResourceGroupName: LogAnalyticsResourceGroupName
  }
}

module OtherResourcesNSG3Rules './modules/APIMSubnetNSGRules.bicep' = {
  name: '${Timestamp}-OtherResourcesNSG3Rules'
  params: {
    apimSubnetNsg: false
    nsgName: nsg3Name
    tags: tags
    location: Location
    LogAnalyticsName: LogAnalyticsName
    LogAnalyticsResourceGroupName: LogAnalyticsResourceGroupName
  }
}

module APIMSubnet './modules/network/virtual-network/subnet/main.bicep' = {
  name: '${Timestamp}-APIMSubnet'
  scope: resourceGroup(subscription().subscriptionId, ExistingVnetRG)
  params: {
    virtualNetworkName: ExistingVnetName
    networkSecurityGroupResourceId: APIMNSG1Rules.outputs.id
    name: apimSubnetName
    addressPrefix: subnet01Range
    routeTableResourceId: RouteTable.outputs.id
    privateEndpointNetworkPolicies: 'Enabled'
    privateLinkServiceNetworkPolicies: 'Enabled'
    serviceEndpoints: [
      'Microsoft.KeyVault'
      'Microsoft.ServiceBus'
      'Microsoft.Sql'
      'Microsoft.Storage'
      'Microsoft.Web'
      'Microsoft.EventHub'
    ]
  }
  dependsOn: [
    AppGatewayNSG2Rules
  ]
}


module AppGatewaySubnet './modules/network/virtual-network/subnet/main.bicep' = {
  name: '${Timestamp}-AppGatewaySubnet'
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  params: {
    virtualNetworkName: ExistingVnetName
    name: appGatewaySubnetName
    addressPrefix: subnet02Range
    networkSecurityGroupResourceId: AppGatewayNSG2Rules.outputs.id
    privateEndpointNetworkPolicies: 'Disabled'
    privateLinkServiceNetworkPolicies: 'Enabled'
    serviceEndpoints: ['Microsoft.KeyVault', 'Microsoft.Web']
  }
  dependsOn: [
    APIMSubnet
  ]
}
module OtherResourcesSubnet './modules/network/virtual-network/subnet/main.bicep' = {
  name: '${Timestamp}-OtherResourcesSubnet'
  scope: resourceGroup(ExistingVnetSubscription, ExistingVnetRG)
  params: {
    virtualNetworkName: ExistingVnetName
    name: infraSubnetName
    addressPrefix: subnet03Range
    networkSecurityGroupResourceId: OtherResourcesNSG3Rules.outputs.id
    privateEndpointNetworkPolicies: 'Enabled'
    privateLinkServiceNetworkPolicies: 'Enabled'
    serviceEndpoints: [
      'Microsoft.KeyVault'
      'Microsoft.ServiceBus'
      'Microsoft.Sql'
      'Microsoft.Storage'
      'Microsoft.Web'
      'Microsoft.EventHub'
    ]
  }
  dependsOn: [
    AppGatewaySubnet
  ]
}



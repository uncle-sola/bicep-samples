import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

#disable-next-line no-unused-existing-resources
resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vaultName
}

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

var pocSwaggerLink = 'https://veco-desktop-dsar-api-rms-test.internal.connellsgroup.co.uk'
var tstSwaggerLink = 'https://veco-desktop-dsar-api-rms-test.internal.connellsgroup.co.uk'
var uatSwaggerLink = 'https://veco-desktop-dsar-api-rms-uat.internal.connellsgroup.co.uk'
var qatSwaggerLink = 'https://veco-desktop-dsar-api-rms-qa.internal.connellsgroup.co.uk'
var prdSwaggerLink = 'https://veco-desktop-dsar-api-rms.internal.connellsgroup.co.uk'

var finalSwaggerLink = Environment == 'poc'
  ? pocSwaggerLink
  : Environment == 'tst'
      ? tstSwaggerLink
      : Environment == 'uat'
          ? uatSwaggerLink
          : Environment == 'qat' ? qatSwaggerLink : Environment == 'prd' ? prdSwaggerLink : 'unknown'

var linkFormat = 'openapi+json-link'

var tempPolicySnippet = loadTextContent('policy-snippets/policy.xml')
var policySnippet = replace(tempPolicySnippet,'{{backEndUrl}}', finalSwaggerLink)


#disable-next-line no-unused-vars
var spec = loadTextContent('api-specs/api-spec.json')

var vecoDesktopDsarRmsApiV1 = 'v1'
var vecoDesktopDsarRmsSubscriptionRequiredV2 = 'false'
var vecoDesktopDsarRmsApiName = 'veco-desktop-dsar-rms'

module ImportVecoDesktopDsarRmsApiV1 '../../modules/api-import/import-api-apim-oauth-backend-oauth.bicep' = {
  name: '${Timestamp}-ImportVecoDesktopDsarRmsModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(vecoDesktopDsarRmsApiName)}-api-${vecoDesktopDsarRmsApiV1}'
    apiUrl: '${finalSwaggerLink}/swagger/v1/swagger.json'
    apiPath: vecoDesktopDsarRmsApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(vecoDesktopDsarRmsApiName)}API ${vecoDesktopDsarRmsApiV1}'
    apiVersion: vecoDesktopDsarRmsApiV1
    productDescription: '${toUpper(vecoDesktopDsarRmsApiName)} Product'
    productDisplayName: '${toUpper(vecoDesktopDsarRmsApiName)} Product'
    productName: '${toUpper(vecoDesktopDsarRmsApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(vecoDesktopDsarRmsApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(vecoDesktopDsarRmsApiName)} API'
    subscriptionRequired: vecoDesktopDsarRmsSubscriptionRequiredV2
    snippet: policySnippet

    clientAppId: keyVault.getSecret('vecoDesktopAllClientAppId')
    clientAppSecret: keyVault.getSecret('vecoDesktopAllClientSecret')
    backendAppId: keyVault.getSecret('vecoDesktopAllServerAppId')
    backendAppIdName: 'vecoDesktopScope'
    clientAppIdName: 'vecoDesktopClientAppId'
    clientAppSecretName: 'vecoDesktopClientAppSecret'
    tokenEndpointUrlName: 'vecoDesktopTokenEndpointUrl'
    hostName: environment().authentication.loginEndpoint
    tenantId: tenant().tenantId
  }
  dependsOn: [
    apim
  ]
}

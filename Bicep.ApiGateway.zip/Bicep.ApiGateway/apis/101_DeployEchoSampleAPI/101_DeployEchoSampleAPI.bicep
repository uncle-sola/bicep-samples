import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vaultName
}

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

var operationSnippet = loadTextContent('policy-snippets/echotest-get-operation.xml')

/////  ECHOTEST V1

var pocSnippet = loadTextContent('api-specs/echotest-v1-poc.yaml')
var tstSnippet = loadTextContent('api-specs/echotest-v1-tst.yaml')
var uatSnippet = loadTextContent('api-specs/echotest-v1-uat.yaml')

var finalSnippet = Environment == 'poc'
  ? pocSnippet
  : Environment == 'tst' ? tstSnippet : Environment == 'uat' ? uatSnippet : 'unknown'

var echoOpenApiSpecV1 = finalSnippet
var echoApiName = 'echotest'
var echoApiFormat = 'openapi'
var echoApiVersionV1 = 'v1'
var echoSubscriptionRequiredV1 = 'true'
module importEchoAPIV1 '../../modules/api-import/import-api-no-oauth.bicep' = if (contains(
  ['poc', 'tst', 'uat'],
  Environment
)) {
  name: '${Timestamp}-ImportEchoAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(echoApiName)}-api-${echoApiVersionV1}'
    apiUrl: echoOpenApiSpecV1
    apiPath: echoApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(echoApiName)}API ${echoApiVersionV1}'
    apiVersion: echoApiVersionV1
    productDescription: '${toUpper(echoApiName)} Product'
    productDisplayName: '${toUpper(echoApiName)} Product'
    productName: '${toUpper(echoApiName)}PRODUCT'
    format: echoApiFormat
    versionSetName: '${functions.getFirstLetterUppercase(echoApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(echoApiName)} API'
    subscriptionRequired: echoSubscriptionRequiredV1
  }
  dependsOn: [
    apim
  ]
}

module InstallApiOperation '../../modules/api-import/install-operation-oauth.bicep' = if (contains(
  ['poc', 'tst', 'uat'],
  Environment
)) {
  name: '${Timestamp}-InstallApiOperationV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(echoApiName)}-api-${echoApiVersionV1}'
    snippet: operationSnippet
    apiOperationName: 'retrieve-resource'
  }
  dependsOn: [
    importEchoAPIV1
  ]
}

/////  ECHOTEST V1  END

/////  ECHOTEST V2

var echoSnippet2 = loadTextContent('policy-snippets/echotest-v2.xml')

var echoOpenApiSpecV2 = finalSnippet
var echoApiVersionV2 = 'v2'
var echoSubscriptionRequiredV2 = 'false'
module importEchoAPIV2 '../../modules/api-import/import-api-apim-oauth-no-backend-oauth.bicep' = if (contains(
  ['poc', 'tst', 'uat'],
  Environment
)) {
  name: '${Timestamp}-ImportEchoAPIModuleV2'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(echoApiName)}-api-${echoApiVersionV2}'
    apiUrl: echoOpenApiSpecV2
    apiPath: echoApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(echoApiName)}API ${echoApiVersionV2}'
    apiVersion: echoApiVersionV2
    productDescription: '${toUpper(echoApiName)} Product'
    productDisplayName: '${toUpper(echoApiName)} Product'
    productName: '${toUpper(echoApiName)}PRODUCT'
    format: echoApiFormat
    versionSetName: '${functions.getFirstLetterUppercase(echoApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(echoApiName)} API'
    subscriptionRequired: echoSubscriptionRequiredV2
    snippet: echoSnippet2
  }
  dependsOn: [
    importEchoAPIV1
  ]
}

module InstallApiOperationV2 '../../modules/api-import/install-operation-oauth.bicep' = if (contains(
  ['poc', 'tst', 'uat'],
  Environment
)) {
  name: '${Timestamp}-InstallApiOperationV2'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(echoApiName)}-api-${echoApiVersionV2}'
    snippet: operationSnippet
    apiOperationName: 'retrieve-resource'
  }
  dependsOn: [
    importEchoAPIV2
  ]
}
/////  ECHOTEST V2 END

/////  ECHOTEST V3

var echoSnippet3 = loadTextContent('policy-snippets/echotest-v3.xml')

var echoOpenApiSpecV3 = finalSnippet
var echoApiVersionV3 = 'v3'
var echoSubscriptionRequiredV3 = 'false'
module importEchoAPIV3 '../../modules/api-import/import-api-apim-oauth-backend-oauth.bicep' = if (contains(
  ['poc', 'tst', 'uat'],
  Environment
)) {
  name: '${Timestamp}-ImportEchoAPIModuleV3'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(echoApiName)}-api-${echoApiVersionV3}'
    apiUrl: echoOpenApiSpecV3
    apiPath: echoApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(echoApiName)}API ${echoApiVersionV3}'
    apiVersion: echoApiVersionV3
    productDescription: '${toUpper(echoApiName)} Product'
    productDisplayName: '${toUpper(echoApiName)} Product'
    productName: '${toUpper(echoApiName)}PRODUCT'
    format: echoApiFormat
    versionSetName: '${functions.getFirstLetterUppercase(echoApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(echoApiName)} API'
    subscriptionRequired: echoSubscriptionRequiredV3
    snippet: echoSnippet3
    clientAppId: keyVault.getSecret('apiClientAppId')
    clientAppSecret: keyVault.getSecret('apiClientAppSecret')
    backendAppId: keyVault.getSecret('apiBackendAppId')
    backendAppIdName: 'apiScope'
    clientAppIdName: 'apiClientAppId'
    clientAppSecretName: 'apiClientAppSecret'
    tokenEndpointUrlName: 'apiTokenEndpointUrl'
    hostName: environment().authentication.loginEndpoint
    tenantId: tenant().tenantId
  }
  dependsOn: [
    importEchoAPIV2
  ]
}

module InstallApiOperationV3 '../../modules/api-import/install-operation-oauth.bicep' = if (contains(
  ['poc', 'tst', 'uat'],
  Environment
)) {
  name: '${Timestamp}-InstallApiOperationV3'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(echoApiName)}-api-${echoApiVersionV3}'
    snippet: operationSnippet
    apiOperationName: 'retrieve-resource'
  }
  dependsOn: [
    importEchoAPIV3
  ]
}
/////  ECHOTEST V3 END

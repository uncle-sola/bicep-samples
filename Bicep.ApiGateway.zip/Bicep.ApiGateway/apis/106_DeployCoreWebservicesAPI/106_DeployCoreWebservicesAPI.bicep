import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

#disable-next-line no-unused-existing-resources
resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vaultName
}

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

var pocSwaggerLink = 'https://corewebservice-test.internal.connellsgroup.co.uk/swagger/v3.0/swagger.json'
var tstSwaggerLink = 'https://corewebservice-test.internal.connellsgroup.co.uk/swagger/v3.0/swagger.json'
var uatSwaggerLink = 'https://corewebservice-uat.internal.connellsgroup.co.uk/swagger/v3.0/swagger.json'
var qatSwaggerLink = 'https://corewebservice-qa.internal.connellsgroup.co.uk/swagger/v3.0/swagger.json'
var prdSwaggerLink = 'https://corewebservice.internal.connellsgroup.co.uk/swagger/v3.0/swagger.json'

var finalSwaggerLink = Environment == 'poc'
  ? pocSwaggerLink
  : Environment == 'tst'
      ? tstSwaggerLink
      : Environment == 'uat'
          ? uatSwaggerLink
          : Environment == 'qat' ? qatSwaggerLink : Environment == 'prd' ? prdSwaggerLink : 'unknown'

var linkFormat = 'openapi+json-link'

var policySnippet = loadTextContent('policy-snippets/core-web-services.xml')
#disable-next-line no-unused-vars
var spec = loadTextContent('api-specs/core-web-services-v1-poc.json')

var coreWebServicesApiV1 = 'v1'
var coreWebServicesSubscriptionRequiredV2 = 'false'
var coreWebServicesApiName = 'core-web-services'

module ImportCoreWebServicesAPIV1 '../../modules/api-import/import-api-no-apim-oauth-backend-oauth.bicep' = {
  name: '${Timestamp}-ImportCoreWebServicesAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(coreWebServicesApiName)}-api-${coreWebServicesApiV1}'
    apiUrl: finalSwaggerLink
    apiPath: coreWebServicesApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(coreWebServicesApiName)}API ${coreWebServicesApiV1}'
    apiVersion: coreWebServicesApiV1
    productDescription: '${toUpper(coreWebServicesApiName)} Product'
    productDisplayName: '${toUpper(coreWebServicesApiName)} Product'
    productName: '${toUpper(coreWebServicesApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(coreWebServicesApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(coreWebServicesApiName)} API'
    subscriptionRequired: coreWebServicesSubscriptionRequiredV2
    snippet: policySnippet

    // clientAppId: keyVault.getSecret('coreWebClientAppId')
    // clientAppSecret: keyVault.getSecret('coreWebClientAppSecret')
    // backendAppId: keyVault.getSecret('coreWebBackendAppId')
    // backendAppIdName: 'coreWebScope'
    // clientAppIdName: 'coreWebClientAppId' 
    // clientAppSecretName: 'coreWebClientAppSecret'
    // tokenEndpointUrlName: 'coreWebTokenEndpointUrl'
    // authorizationResourceName: 'Core-Web-AuthorizationServer'
    // hostName: environment().authentication.loginEndpoint
    // tenantId: tenant().tenantId
  }
  dependsOn: [
    apim
  ]
}

import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

/////  msgFrameworkAPI V1

var policySnippet = loadTextContent('policy-snippets/msg-framework.xml')
var linkFormat = 'swagger-link-json'

var pocSwaggerLink = 'http://messagingframework-web.test.branch.local/swagger/docs/v1'
var tstSwaggerLink = 'http://messagingframework-web.test.branch.local/swagger/docs/v1'
var uatSwaggerLink = 'http://messagingframework-web.uat.branch.local/swagger/docs/v1'
var qatSwaggerLink = 'http://messagingframework-web.qa.branch.local/swagger/docs/v1'
var prdSwaggerLink = 'http://messagingframework-web.app.branch.local/swagger/docs/v1'

var finalSwaggerLink = Environment == 'poc'
  ? pocSwaggerLink
  : Environment == 'tst'
      ? tstSwaggerLink
      : Environment == 'uat'
          ? uatSwaggerLink
          : Environment == 'qat' ? qatSwaggerLink : Environment == 'prd' ? prdSwaggerLink : 'unknown'

var msgFrameworkApiV1 = 'v1'
var msgFrameworkSubscriptionRequiredV2 = 'false'
var msgFrameworkApiName = 'msg-framework'

module importMsgFrameworkAPIV1 '../../modules/api-import/import-api-apim-oauth-no-backend-oauth.bicep' = {
  name: '${Timestamp}-ImportMsgFrameworkAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(msgFrameworkApiName)}-api-${msgFrameworkApiV1}'
    apiUrl: finalSwaggerLink
    apiPath: msgFrameworkApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(msgFrameworkApiName)}API ${msgFrameworkApiV1}'
    apiVersion: msgFrameworkApiV1
    productDescription: '${toUpper(msgFrameworkApiName)} Product'
    productDisplayName: '${toUpper(msgFrameworkApiName)} Product'
    productName: '${toUpper(msgFrameworkApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(msgFrameworkApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(msgFrameworkApiName)} API'
    subscriptionRequired: msgFrameworkSubscriptionRequiredV2
    snippet: policySnippet
  }
  dependsOn: [
    apim
  ]
}

/////  msgFrameworkAPI V1 END

import * as resources from '../functions/project-resource-names.bicep'
import * as functions from '../functions/functions.bicep'


@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')


module DeployEchoAPI '101_DeployEchoSampleAPI/101_DeployEchoSampleAPI.bicep' =  {
  name: '${Timestamp}-DeployEchoAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployMsgFrameworkAPI '102_DeployMsgFrameworkAPI/102_DeployMsgFrameworkAPI.bicep' =  {
  name: '${Timestamp}-DeployMsgFrameworkAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployPropertyUploadAPI '103_DeployPropertyUploadAPI/103_DeployPropertyUploadAPI.bicep' =  {
  name: '${Timestamp}-DeployPropertyUploadAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployWebFeedAPI '104_DeployWebFeedAPI/104_DeployWebFeedAPI.bicep' =  {
  name: '${Timestamp}-DeployWebFeedAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployLMSSecureLinkAPI '105_DeployLMSSecureLinkAPI/105_DeployLMSSecureLinkAPI.bicep' =  {
  name: '${Timestamp}-DeployLMSSecureLinkAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployCoreWebservicesAPI '106_DeployCoreWebservicesAPI/106_DeployCoreWebservicesAPI.bicep' =  {
  name: '${Timestamp}-DeployCoreWebservicesAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployBranchProfileAPI '107_DeployBranchProfileAPI/107_DeployBranchProfileAPI.bicep' =  {
  name: '${Timestamp}-DeployBranchProfileAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

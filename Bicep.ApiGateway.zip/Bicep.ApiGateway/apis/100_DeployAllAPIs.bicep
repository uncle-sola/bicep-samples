import * as resources from '../functions/project-resource-names.bicep'
import * as functions from '../functions/functions.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

module DeployEchoAPI '101_DeployEchoSampleAPI/101_DeployEchoSampleAPI.bicep' = {
  name: '${Timestamp}-DeployEchoAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployMsgFrameworkAPI '102_DeployMsgFrameworkAPI/102_DeployMsgFrameworkAPI.bicep' = {
  name: '${Timestamp}-DeployMsgFrameworkAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployPropertyUploadAPI '103_DeployPropertyUploadAPI/103_DeployPropertyUploadAPI.bicep' = {
  name: '${Timestamp}-DeployPropertyUploadAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployWebFeedAPI '104_DeployWebFeedAPI/104_DeployWebFeedAPI.bicep' = {
  name: '${Timestamp}-DeployWebFeedAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployLMSSecureLinkAPI '105_DeployLMSSecureLinkAPI/105_DeployLMSSecureLinkAPI.bicep' = {
  name: '${Timestamp}-DeployLMSSecureLinkAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployCoreWebservicesAPI '106_DeployCoreWebservicesAPI/106_DeployCoreWebservicesAPI.bicep' = {
  name: '${Timestamp}-DeployCoreWebservicesAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployBranchProfileAPI '107_DeployBranchProfileAPI/107_DeployBranchProfileAPI.bicep' = {
  name: '${Timestamp}-DeployBranchProfileAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}



module DeployVecoDesktopDsarRmsAPI '108_DeployVecoDesktopDsarRmsAPI/108_DeployVecoDesktopDsarRmsAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopDsarRmsAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployVecoDesktopDsarConAPI '109_DeployVecoDesktopDsarConAPI/109_DeployVecoDesktopDsarConAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopDsarConAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployVecoDesktopDsarSeqAPI '110_DeployVecoDesktopDsarSeqAPI/110_DeployVecoDesktopDsarSeqAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopDsarSeqAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployVecoDesktopDsarPaAPI '111_DeployVecoDesktopDsarPaAPI/111_DeployVecoDesktopDsarPaAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopDsarPaAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployVecoDesktopDsarSqAPI '112_DeployVecoDesktopDsarSqAPI/112_DeployVecoDesktopDsarSqAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopDsarSqAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployVecoDesktopBranchRmsAPI '113_DeployVecoDesktopBranchRmsAPI/113_DeployVecoDesktopBranchRmsAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopBranchRmsAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployVecoDesktopBranchConAPI '114_DeployVecoDesktopBranchConAPI/114_DeployVecoDesktopBranchConAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopBranchConAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployVecoDesktopBranchSeqAPI '115_DeployVecoDesktopBranchSeqAPI/115_DeployVecoDesktopBranchSeqAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopBranchSeqAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployVecoDesktopBranchPaAPI '116_DeployVecoDesktopBranchPaAPI/116_DeployVecoDesktopBranchPaAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopBranchPaAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}


module DeployVecoDesktopBranchSqAPI '117_DeployVecoDesktopBranchSqAPI/117_DeployVecoDesktopBranchSqAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopBranchSqAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}



module DeployVecoDesktopMpcRmsAPI '118_DeployVecoDesktopMpcRmsAPI/118_DeployVecoDesktopMpcRmsAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopMpcRmsAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

module DeployVecoDesktopMpcConAPI '119_DeployVecoDesktopMpcConAPI/119_DeployVecoDesktopMpcConAPI.bicep' = {
   name: '${Timestamp}-DeployVecoDesktopMpcConAPI'
   params: {
      Environment: Environment
      Project: Project
      Region: Region
   }
}

module DeployVecoDesktopMpcSeqAPI '120_DeployVecoDesktopMpcSeqAPI/120_DeployVecoDesktopMpcSeqAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopMpcSeqAPI'
  params: {
     Environment: Environment
     Project: Project
     Region: Region
  }
}

module DeployVecoDesktopMpcPaAPI '121_DeployVecoDesktopMpcPaAPI/121_DeployVecoDesktopMpcPaAPI.bicep' = {
  name: '${Timestamp}-121_DeployVecoDesktopMpcPaAPI'
  params: {
     Environment: Environment
     Project: Project
     Region: Region
  }
}


module DeployVecoDesktopMpcSqAPI '122_DeployVecoDesktopMpcSqAPI/122_DeployVecoDesktopMpcSqAPI.bicep' = {
  name: '${Timestamp}-DeployVecoDesktopMpcSqAPI'
  params: {
    Environment: Environment
    Project: Project
    Region: Region
  }
}

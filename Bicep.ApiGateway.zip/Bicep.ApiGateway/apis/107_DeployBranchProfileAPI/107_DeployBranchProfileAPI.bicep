import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

var pocSwaggerLink = 'https://branch-profile-api-test.internal.connellsgroup.co.uk/swagger/v1/swagger.json'
var tstSwaggerLink = 'https://branch-profile-api-test.internal.connellsgroup.co.uk/swagger/v1/swagger.json'
var uatSwaggerLink = 'https://branch-profile-api-uat.internal.connellsgroup.co.uk/swagger/v1/swagger.json'
var qatSwaggerLink = 'https://branch-profile-api-qa.internal.connellsgroup.co.uk/swagger/v1/swagger.json'
var prdSwaggerLink = 'https://branch-profile-api.internal.connellsgroup.co.uk/swagger/v1/swagger.json'
var finalSwaggerLink = Environment == 'poc'
  ? pocSwaggerLink
  : Environment == 'tst'
      ? tstSwaggerLink
      : Environment == 'uat'
          ? uatSwaggerLink
          : Environment == 'qat' ? qatSwaggerLink : Environment == 'prd' ? prdSwaggerLink : 'unknown'

#disable-next-line no-unused-vars
var spec = loadTextContent('api-specs/temp.json')

var policySnippet = loadTextContent('policy-snippets/branch-profile.xml')

var linkFormat = 'openapi-link'

var branchProfileApiV1 = 'v1'
var branchProfileSubscriptionRequiredV2 = 'false'
var branchProfileApiName = 'branch-profile'

module ImportBranchProfileAPIV1 '../../modules/api-import/import-api-no-apim-oauth-backend-oauth.bicep' = {
  name: '${Timestamp}-ImportBranchProfileAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(branchProfileApiName)}-api-${branchProfileApiV1}'
    apiUrl: finalSwaggerLink
    apiPath: branchProfileApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(branchProfileApiName)}API ${branchProfileApiV1}'
    apiVersion: branchProfileApiV1
    productDescription: '${toUpper(branchProfileApiName)} Product'
    productDisplayName: '${toUpper(branchProfileApiName)} Product'
    productName: '${toUpper(branchProfileApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(branchProfileApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(branchProfileApiName)} API'
    subscriptionRequired: branchProfileSubscriptionRequiredV2
    snippet: policySnippet
  }
  dependsOn: [
    apim
  ]
}

import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')

@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)

@description('Key vault name')
var vaultName = resources.getKeyVaultName(Region, Environment, Project)

#disable-next-line no-unused-existing-resources
resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vaultName
}

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

var pocSwaggerLink = 'https://veco-desktop-mpc-api-pa-test.internal.connellsgroup.co.uk'
var tstSwaggerLink = 'https://veco-desktop-mpc-api-pa-test.internal.connellsgroup.co.uk'
var uatSwaggerLink = 'https://veco-desktop-mpc-api-pa-uat.internal.connellsgroup.co.uk'
var qatSwaggerLink = 'https://veco-desktop-mpc-api-pa-qa.internal.connellsgroup.co.uk'
var prdSwaggerLink = 'https://veco-desktop-mpc-api-pa.internal.connellsgroup.co.uk'

var finalSwaggerLink = Environment == 'poc'
  ? pocSwaggerLink
  : Environment == 'tst'
      ? tstSwaggerLink
      : Environment == 'uat'
          ? uatSwaggerLink
          : Environment == 'qat' ? qatSwaggerLink : Environment == 'prd' ? prdSwaggerLink : 'unknown'

var linkFormat = 'openapi+json-link'

var tempPolicySnippet = loadTextContent('policy-snippets/policy.xml')
var policySnippet = replace(tempPolicySnippet,'{{backEndUrl}}', finalSwaggerLink)


#disable-next-line no-unused-vars
var spec = loadTextContent('api-specs/api-spec.json')

var vecoDesktopMpcPaApiV1 = 'v1'
var vecoDesktopMpcPaSubscriptionRequiredV2 = 'false'
var vecoDesktopMpcPaApiName = 'veco-desktop-mpc-pa'

module ImportVecoDesktopMpcPaApiV1 '../../modules/api-import/import-api-apim-oauth-backend-oauth.bicep' = {
  name: '${Timestamp}-ImportVecoDesktopMpcPaModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(vecoDesktopMpcPaApiName)}-api-${vecoDesktopMpcPaApiV1}'
    apiUrl: '${finalSwaggerLink}/swagger/v1/swagger.json'
    apiPath: vecoDesktopMpcPaApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(vecoDesktopMpcPaApiName)}API ${vecoDesktopMpcPaApiV1}'
    apiVersion: vecoDesktopMpcPaApiV1
    productDescription: '${toUpper(vecoDesktopMpcPaApiName)} Product'
    productDisplayName: '${toUpper(vecoDesktopMpcPaApiName)} Product'
    productName: '${toUpper(vecoDesktopMpcPaApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(vecoDesktopMpcPaApiName)}APIVersionSet'
    versionSetDisplayName: '${functions.getFirstLetterUppercase(vecoDesktopMpcPaApiName)} API'
    subscriptionRequired: vecoDesktopMpcPaSubscriptionRequiredV2
    snippet: policySnippet

    clientAppId: keyVault.getSecret('vecoDesktopAllClientAppId')
    clientAppSecret: keyVault.getSecret('vecoDesktopAllClientSecret')
    backendAppId: keyVault.getSecret('vecoDesktopAllServerAppId')
    backendAppIdName: 'vecoDesktopScope'
    clientAppIdName: 'vecoDesktopClientAppId'
    clientAppSecretName: 'vecoDesktopClientAppSecret'
    tokenEndpointUrlName: 'vecoDesktopTokenEndpointUrl'
    hostName: environment().authentication.loginEndpoint
    tenantId: tenant().tenantId
  }
  dependsOn: [
    apim
  ]
}

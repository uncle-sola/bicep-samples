import * as resources from '../../functions/project-resource-names.bicep'
import * as functions from '../../functions/functions.bicep'


@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string

@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')


@description('The name of the API Management service.')
var apimName = resources.getApimName(Region, Environment, Project)



// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimName
}

var linkFormat = 'swagger-link-json'


var pocSwaggerLink = 'http://webfeed-api.test.branch.local/swagger/v1.0/swagger.json'
var tstSwaggerLink = 'http://webfeed-api.test.branch.local/swagger/v1.0/swagger.json'
var uatSwaggerLink = 'http://webfeed-api.uat.branch.local/swagger/v1.0/swagger.json'
var qatSwaggerLink = 'http://webfeed-api.qa.branch.local/swagger/v1.0/swagger.json'
var prdSwaggerLink = 'http://webfeed-api.app.branch.local/swagger/v1.0/swagger.json'

var finalSwaggerLink = Environment == 'poc' ? pocSwaggerLink
  : Environment == 'tst' ? tstSwaggerLink
  : Environment == 'uat' ? uatSwaggerLink
  : Environment == 'qat' ? qatSwaggerLink
  : Environment == 'prd' ? prdSwaggerLink
  : 'unknown'


var webFeedSnippet = loadTextContent('policy-snippets/web-feed.xml')


var webFeedApiV1 = 'v1'
var webFeedSubscriptionRequiredV2 = 'false'
var webFeedApiName = 'web-feed'

module importWebFeedAPIV1 '../../modules/api-import/import-api-apim-oauth-no-backend-oauth.bicep' = {
  name: '${Timestamp}-ImportWebFeedAPIModuleV1'
  params: {
    apimServiceName: apimName
    apiName: '${toLower(webFeedApiName)}-api-${webFeedApiV1}'
    apiUrl: finalSwaggerLink
    apiPath: webFeedApiName
    apiDisplayName: '${functions.getFirstLetterUppercase(webFeedApiName)}API ${webFeedApiV1}'
    apiVersion: webFeedApiV1
    productDescription: '${toUpper(webFeedApiName)} Product'
    productDisplayName: '${toUpper(webFeedApiName)} Product'
    productName: '${toUpper(webFeedApiName)}PRODUCT'
    format: linkFormat
    versionSetName: '${functions.getFirstLetterUppercase(webFeedApiName)}APIVersionSet'
    versionSetDisplayName:'${functions.getFirstLetterUppercase(webFeedApiName)} API'
    subscriptionRequired: webFeedSubscriptionRequiredV2
    snippet: webFeedSnippet
  }
  dependsOn: [
    apim
  ]
}

function ParamBuilder
{
   param([Object]$ParamArg)
   $Arg = [PSCustomObject]::new()
   foreach ($Param in $ParamArg)
   {
      if ($Param.Value.Length -gt 0)
      {
         Write-Host Adding $Param.Name to parameter list with value $Param.Value
         $Arg | Add-Member NoteProperty -Name $Param.Name -Value ([PSCustomObject] @{ value = $Param.Value })
      } 
   }
   return ($Arg | ConvertTo-Json -Compress).Replace('"', '\"')
}

$azureApplicationId = "33e490ef-26cc-41c2-bdaa-09c5014a1f5f"    #$OctopusParameters["AzureAccount.Client"]
$azureTenantId = "07808216-ca18-4f9b-b249-7d53dadb5344"         #$OctopusParameters["AzureAccount.TenantId"]
$azurePassword = ConvertTo-SecureString "i1L8Q~FHhu2ApiGK3GyYPuccOQ8llhpYzUCOucYQ" -AsPlainText -Force   #$OctopusParameters["AzureAccount.Password"]
$subscriptionId = "5a0d2531-1597-473f-bb7a-ae3d7e8a3773"        #$OctopusParameters["DunnoWhereWe'reGettin.ThisFromYet"]

############################
#### Authentication
############################
Write-Host AppId: $azureApplicationId
Write-Host Tenant: $azureTenantId
Write-Host Subscr: $subscriptionId
Write-Host Password: $azurePassword
   
$AzCred = New-Object System.Management.Automation.PSCredential($azureApplicationId , $azurePassword)
$AzLogin = az login --service-principal -u $AzCred.UserName -p $AzCred.GetNetworkCredential().Password --tenant $azureTenantId | ConvertFrom-Json
az account set --subscription $subscriptionId 
$acc = az account show | ConvertFrom-Json
Write-Host "Subscription scoped to"  $acc.name "-" $acc.id

####################
# Parent
####################
$DeploymentParentName = "ApiGatewayBaseInfraPoC" 
$BicepParentFilePath = ".\ApiGatewayBaseInfra.bicep"
$Region = "uks"
$Environment = "tst"
$Project = "apigateway"
$RgType = "infra"
$instance = "0031"
$ResourceGroupName = "${Region}-${Environment}-rsg${instance}-${Project}-${RgType}"

$Params = @(
   [PSCustomObject]@{ Name = "Region"; Value = $Region }
   [PSCustomObject]@{ Name = "Environment"; Value = $Environment }
   [PSCustomObject]@{ Name = "Project"; Value = $Project }
   )
$ParamString = ParamBuilder -ParamArg $Params

Write-Host Deploying $DeploymentParentName

# az bicep lint --file "ApiGatewayBaseInfra.bicep"

# az bicep build --file "ApiGatewayBaseInfra.bicep"

# ./powershell/Arm-ttk.ps1 "ApiGatewayBaseInfra"

# Remove-Item "ApiGatewayBaseInfra.json"

# Remove-Item "./arm-template-toolkit" -Recurse -Force -Confirm:$false

# Remove-Item "./arm-template-toolkit.zip"

az deployment group create `
   --resource-group $ResourceGroupName `
   --template-file $BicepParentFilePath `
   --name $DeploymentParentName `
   --parameters $ParamString `
   --debug 




Write-Host "Deployment complete"

import * as resources from 'functions/project-resource-names.bicep'
//import * as resources from '#{Module.Parent.Directory}/functions/project-resource-names.bicep'

@description('Location')
param Location string = resourceGroup().location

@description('Region')
param Region string

@allowed([
  'poc'
  'tst'
  'uat'
  'qat'
  'prd'
])
@description('Environment')
param Environment string

@description('Project Code')
param Project string


@description('log analytics workspace name')
var LogAnalyticsName = resources.getLogAnalyticsName(Region, Environment, Project) 

@description('App Insights Name')
var AppInsightsName = resources.getAppInsightsName(Region, Environment, Project)

@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')


module LogAnalytics 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/loganalytics:1.0.1' = {
  name: '${Timestamp}-LogAnalytics'
  params: {
    BusinessUnitTag: BusinessUnitTag
    CompanyTag: CompanyTag
    ContactTag: ContactTag
    Location: Location
    LogAnalyticsName: LogAnalyticsName
    SolutionName: SolutionName
  }
}

module AppInsights 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/appinsights:1.0.1' = {
  name: '${Timestamp}-AppInsights'
  params: {
    AppInsightsName: AppInsightsName
    BusinessUnitTag: BusinessUnitTag
    CompanyTag: CompanyTag
    ContactTag: ContactTag
    Location: Location
    LogAnalyticsId: LogAnalytics.outputs.Id
    SolutionName: SolutionName
  }
}

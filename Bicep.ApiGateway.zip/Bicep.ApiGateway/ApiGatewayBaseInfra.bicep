@description('Location')
param Location string = resourceGroup().location

@description('log analytics workspace name')
param LogAnalyticsName string

@description('App Insights Name')
param AppInsightsName string


@description('Business Tag')
param BusinessUnitTag string = 'New Business Unit'

@description('Company Tag')
param CompanyTag string = 'Connells Group'

@description('Contact Tag')
param ContactTag string = 'Dev - Online'

@description('Solution Name')
param SolutionName string = 'ApiGateway'


@description('Time stamp')
param Timestamp string = utcNow('yyyyMMdd-HHmmss')


module LogAnalytics 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/loganalytics:1.0.1' = {
  name: '${Timestamp}-LogAnalytics'
  params: {
    BusinessUnitTag: BusinessUnitTag
    CompanyTag: CompanyTag
    ContactTag: ContactTag
    Location: Location
    LogAnalyticsName: LogAnalyticsName
    SolutionName: SolutionName
  }
}

module AppInsights 'br:connellsgroupbicepregistry.azurecr.io/bicep/modules/generic/appinsights:1.0.1' = {
  name: '${Timestamp}-AppInsights'
  params: {
    AppInsightsName: AppInsightsName
    BusinessUnitTag: BusinessUnitTag
    CompanyTag: CompanyTag
    ContactTag: ContactTag
    Location: Location
    LogAnalyticsId: LogAnalytics.outputs.Id
    SolutionName: SolutionName
  }
}

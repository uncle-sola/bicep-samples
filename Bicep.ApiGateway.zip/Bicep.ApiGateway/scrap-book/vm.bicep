param virtualMachines_jumpbox_name string = 'jumpbox'
param publicIPAddresses_jumpbox_ip_name string = 'jumpbox-ip'
param networkInterfaces_jumpbox8_z1_name string = 'jumpbox8_z1'
param schedules_shutdown_computevm_jumpbox_name string = 'shutdown-computevm-jumpbox'
param virtualNetworks_AZSPOC_VNET_externalid string = '/subscriptions/3f88752d-7039-4e85-b9b9-22dd7b8adfb6/resourceGroups/UKS-TST-RSG0001-Network/providers/Microsoft.Network/virtualNetworks/AZSPOC-VNET'

resource publicIPAddresses_jumpbox_ip_name_resource 'Microsoft.Network/publicIPAddresses@2024-01-01' = {
  name: publicIPAddresses_jumpbox_ip_name
  location: 'uksouth'
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  zones: [
    '1'
  ]
  properties: {
    ipAddress: '20.117.233.148'
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    idleTimeoutInMinutes: 4
    ipTags: []
  }
}

resource virtualMachines_jumpbox_name_resource 'Microsoft.Compute/virtualMachines@2024-07-01' = {
  name: virtualMachines_jumpbox_name
  location: 'uksouth'
  zones: [
    '1'
  ]
  properties: {
    hardwareProfile: {
      vmSize: 'Standard_B2s'
    }
    additionalCapabilities: {
      hibernationEnabled: false
    }
    storageProfile: {
      imageReference: {
        publisher: 'MicrosoftWindowsDesktop'
        offer: 'Windows-10'
        sku: 'win10-22h2-pro-g2'
        version: 'latest'
      }
      osDisk: {
        osType: 'Windows'
        name: '${virtualMachines_jumpbox_name}_OsDisk_1_97a1420518c041f68511a4a0538f5a44'
        createOption: 'FromImage'
        caching: 'ReadWrite'
        managedDisk: {
          storageAccountType: 'Premium_LRS'
          id: resourceId(
            'Microsoft.Compute/disks',
            '${virtualMachines_jumpbox_name}_OsDisk_1_97a1420518c041f68511a4a0538f5a44'
          )
        }
        deleteOption: 'Delete'
        diskSizeGB: 127
      }
      dataDisks: []
      diskControllerType: 'SCSI'
    }
    osProfile: {
      computerName: virtualMachines_jumpbox_name
      adminUsername: 'sola'
      windowsConfiguration: {
        provisionVMAgent: true
        enableAutomaticUpdates: true
        patchSettings: {
          patchMode: 'AutomaticByOS'
          assessmentMode: 'ImageDefault'
          enableHotpatching: false
        }
      }
      secrets: []
      allowExtensionOperations: true
      requireGuestProvisionSignal: true
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: networkInterfaces_resource.id
          properties: {
            deleteOption: 'Delete'
          }
        }
      ]
    }
    diagnosticsProfile: {
      bootDiagnostics: {
        enabled: true
      }
    }
    licenseType: 'Windows_Client'
  }
}

resource schedules_shutdown_computevm_jumpbox_name_resource 'microsoft.devtestlab/schedules@2018-09-15' = {
  name: schedules_shutdown_computevm_jumpbox_name
  location: 'uksouth'
  properties: {
    status: 'Enabled'
    taskType: 'ComputeVmShutdownTask'
    dailyRecurrence: {
      time: '2100'
    }
    timeZoneId: 'UTC'
    notificationSettings: {
      status: 'Enabled'
      timeInMinutes: 30
      emailRecipient: 'Olusola.Adio@connellsgroup.co.uk'
      notificationLocale: 'en'
    }
    targetResourceId: virtualMachines_jumpbox_name_resource.id
  }
}

resource networkInterfaces_resource 'Microsoft.Network/networkInterfaces@2024-01-01' = {
  name: networkInterfaces_jumpbox8_z1_name
  location: 'uksouth'
  kind: 'Regular'
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
        id: '${resourceId('Microsoft.Network/networkInterfaces',networkInterfaces_jumpbox8_z1_name)}/ipConfigurations/ipconfig1'
        type: 'Microsoft.Network/networkInterfaces/ipConfigurations'
        properties: {
          privateIPAddress: '10.60.120.52'
          privateIPAllocationMethod: 'Static'
          publicIPAddress: {
            id: publicIPAddresses_jumpbox_ip_name_resource.id
            properties: {
              deleteOption: 'Delete'
            }
          }
          subnet: {
            id: '${virtualNetworks_AZSPOC_VNET_externalid}/subnets/UKS-POC-SUB0002-ApiGateway'
          }
          primary: true
          privateIPAddressVersion: 'IPv4'
        }
      }
    ]
    dnsSettings: {
      dnsServers: []
    }
    enableAcceleratedNetworking: false
    enableIPForwarding: false
    disableTcpStateTracking: false
    nicType: 'Standard'
    auxiliaryMode: 'None'
    auxiliarySku: 'None'
  }
}

@description('location')
param location string = resourceGroup().location

@description('Name of the route table')
param rtName string

@description('asset tags')
param tags object

@description('APIM Public IP')
param apimPublicIp string

@description('default route')
var defaultRoute = {
  routes: [
    {
      name: 'APIMControlPlane'
      properties: {
        addressPrefix: 'ApiManagement'
        nextHopType: 'Internet'
      }
    }
    {
      name: 'APIMControlPlaneIp'
      properties: {
        addressPrefix: '${apimPublicIp}/32'
        nextHopType: 'Internet'
      }
    }
  ]
}



module rt './network/route-table/main.bicep' = {
  name: rtName
  params:{
    name: rtName
    disableBgpRoutePropagation:true
    location: location
    tags: tags
    routes: defaultRoute.routes
  }
  
}

output id string = rt.outputs.resourceId

param apimName string
param apiName string
param policystring string 


resource apim 'Microsoft.ApiManagement/service@2022-08-01' existing = {
  name: apimName
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' existing = {
  name: apiName
  parent: apim
}


resource apiPolicy 'Microsoft.ApiManagement/service/apis/policies@2023-09-01-preview' = {
  parent: api
  name: 'policy'
  properties: {
    value: policystring
    format:'xml'
  }
}

output apiPolicyValue string = apiPolicy.properties.value
output apiName string = api.name
output apiDisplayName string = api.properties.displayName
//output apiDescription string = api.properties.description

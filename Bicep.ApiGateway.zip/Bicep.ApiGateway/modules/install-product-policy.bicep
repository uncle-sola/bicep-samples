param apimName string
param productName string
param policystring string 


resource apim 'Microsoft.ApiManagement/service@2022-08-01' existing = {
  name: apimName
}

resource product 'Microsoft.ApiManagement/service/products@2022-08-01' existing = {
  name: productName
  parent: apim
}

resource apiPolicy 'Microsoft.ApiManagement/service/products/policies@2023-09-01-preview' = {
  parent: product
  name: 'policy'
  properties: {
    value: policystring
    format:'xml'
  }
}

output productPolicyId string = apiPolicy.id
output prouctPolicyValue string = apiPolicy.properties.value
output productName string = product.properties.displayName

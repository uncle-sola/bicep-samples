param apimName string
param policystring string 


resource apim 'Microsoft.ApiManagement/service@2022-08-01' existing = {
  name: apimName
}

resource apiPolicy 'Microsoft.ApiManagement/service/policies@2023-09-01-preview' = {
  parent: apim
  name: 'policy'
  properties: {
    value: policystring
    format:'xml'
  }
}

output apimPolicyId string = apiPolicy.id
output apimPolicyValue string = apiPolicy.properties.value
output apimName string = apim.name

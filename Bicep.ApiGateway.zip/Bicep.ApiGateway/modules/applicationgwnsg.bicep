@description('location')
param location string

@description('app gateway nsg name')
param appGwNetworkSecurityGroupName string

@description('tags')
param tags object

@description('workspace name')
param LogAnalyticsName string

@description('LogAnalyticsResourceGroupName')
param LogAnalyticsResourceGroupName string

var securityRules = {
  rules: [
    {
      name: 'ALLOW_Internal_Inbound'
      properties: {
        description: ''
        protocol: 'Tcp'
        destinationPortRanges: ['443', '80']
        sourcePortRange: '*'
        access: 'Allow'
        priority: 140
        direction: 'Inbound'
        sourceAddressPrefix: 'VirtualNetwork'
        DestinationAddressPrefix: 'VirtualNetwork'
      }
    }
    {
      name: 'ALLOW_HTTPS_from_internet'
      properties: {
        description: ''
        protocol: 'Tcp'
        destinationPortRange: '443'
        sourcePortRange: '*'
        access: 'Allow'
        priority: 150
        direction: 'Inbound'
        sourceAddressPrefix: 'Internet'
        DestinationAddressPrefix: '*'
      }
    }
    {
      name: 'ALLOW_HTTP_from_internet'
      properties: {
        description: ''
        protocol: 'Tcp'
        destinationPortRange: '80'
        sourcePortRange: '*'
        access: 'Allow'
        priority: 151
        direction: 'Inbound'
        sourceAddressPrefix: 'Internet'
        DestinationAddressPrefix: '*'
      }
    }
    {
      name: 'ALLOW_Backend_Healthcheck'
      properties: {
        description: ''
        protocol: 'Tcp'
        destinationPortRange: '65200-65535'
        sourcePortRange: '*'
        access: 'Allow'
        priority: 152
        direction: 'Inbound'
        sourceAddressPrefix: 'GatewayManager'
        DestinationAddressPrefix: '*'
      }
    }
    {
      name: 'ALLOW_Azure_loadbalancer_probes'
      properties: {
        description: ''
        protocol: '*'
        destinationPortRange: '*'
        sourcePortRange: '*'
        access: 'Allow'
        priority: 153
        direction: 'Inbound'
        sourceAddressPrefix: 'AzureLoadBalancer'
        DestinationAddressPrefix: '*'
      }
    }
    {
      name: 'Deny_All'
      properties: {
        description: ''
        protocol: '*'
        access: 'Deny'
        sourcePortRange: '*'
        destinationPortRange: '*'
        priority: 4095
        direction: 'Inbound'
        sourceAddressPrefix: '*'
        DestinationAddressPrefix: '*'
      }
    }
  ]
}

resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  scope: resourceGroup(LogAnalyticsResourceGroupName)
  name: LogAnalyticsName
}


module CreateNSGRules './network/network-security-group/main.bicep' = {
  name: '${appGwNetworkSecurityGroupName}-nsg'
  params: {
    name: appGwNetworkSecurityGroupName
    diagnosticSettings: [
      {
        name: 'logToAnalytics'
        logAnalyticsDestinationType: 'AzureDiagnostics'
        logCategoriesAndGroups: [
          {
            category: 'NetworkSecurityGroupEvent'
            enabled: true
          }
          {
            category: 'NetworkSecurityGroupRuleCounter'
            enabled: true
          }
        ]
        workspaceResourceId: laWorkspace.id
      }
    ]
    location: location
    tags: tags
    securityRules: securityRules.rules
  }
}

output id string = CreateNSGRules.outputs.resourceId

@description('Is it APIM Subnet NSG?')
param apimSubnetNsg bool

@description('location')
param location string = resourceGroup().location

@description('Name of the nsg')
param nsgName string

@description('asset tags')
param tags object

@description('workspace name')
param LogAnalyticsName string

@description('LogAnalyticsResourceGroupName')
param LogAnalyticsResourceGroupName string

@description('priority number')
var priorityOffset = 306

var defaultRulez = [
  {
    name: 'ApiInbound'
    properties: {
      description: 'Management endpoint for Azure portal and PowerShell'
      protocol: 'Tcp'
      sourcePortRange: '*'
      destinationPortRange: '443'
      sourceAddressPrefix: 'ApiManagement'
      destinationAddressPrefix: 'VirtualNetwork'
      access: 'Allow'
      priority: 130
      direction: 'Inbound'
    }
  }
]

var rdpRulez = [
  {
    name: 'RDPInbound'
    properties: {
      description: 'Management endpoint for Azure portal and PowerShell'
      protocol: 'Tcp'
      sourcePortRange: '*'
      destinationPortRange: '3389'
      sourceAddressPrefix: '*'
      destinationAddressPrefix: '*'
      access: 'Allow'
      priority: 140
      direction: 'Inbound'
    }
  }
]
var otherRulez = [
  {
    name: 'allow-internet-apim'
    properties: {
      access: 'Allow'
      description: 'Allow traffic from Internet to apim'
      destinationAddressPrefix: 'VirtualNetwork'
      destinationPortRange: '443'
      direction: 'Inbound'
      priority: priorityOffset + 1
      protocol: 'Tcp'
      sourceAddressPrefix: 'Internet'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-apim-apim'
    properties: {
      access: 'Allow'
      description: 'Allow traffic from apiManagement endpoint to vnet'
      destinationAddressPrefix: 'VirtualNetwork'

      destinationPortRange: '3443'

      direction: 'Inbound'
      priority: priorityOffset + 2
      protocol: '*'
      sourceAddressPrefix: 'ApiManagement'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-apim-loadbalancer'
    properties: {
      access: 'Allow'
      description: 'Allow traffic from load balancer endpoint to vnet for apim'
      destinationAddressPrefix: 'VirtualNetwork'

      destinationPortRange: '6390'

      direction: 'Inbound'
      priority: priorityOffset + 3
      protocol: '*'
      sourceAddressPrefix: 'AzureLoadBalancer'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-traffic-manager-apim'
    properties: {
      access: 'Allow'
      description: 'Allow traffic from TrafficManager to Vnet'
      destinationAddressPrefix: 'VirtualNetwork'
      destinationPortRange: '443'

      direction: 'Inbound'
      priority: priorityOffset + 4
      protocol: 'Tcp'
      sourceAddressPrefix: 'AzureTrafficManager'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-apim-storage'
    properties: {
      access: 'Allow'
      description: 'Allow traffic from apim to storage'
      destinationAddressPrefix: 'Storage'
      destinationPortRange: '443'

      direction: 'Outbound'
      priority: priorityOffset + 1
      protocol: 'Tcp'
      sourceAddressPrefix: 'VirtualNetwork'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-apim-sql'
    properties: {
      access: 'Allow'
      description: 'Allow traffic from apim to sql'
      destinationAddressPrefix: 'SQL'
      destinationPortRange: '1433'

      direction: 'Outbound'
      priority: priorityOffset + 2
      protocol: 'Tcp'
      sourceAddressPrefix: 'VirtualNetwork'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-apim-keyvault'
    properties: {
      access: 'Allow'
      description: 'Allow traffic from apim to AzureKeyVault'
      destinationAddressPrefix: 'AzureKeyVault'
      destinationPortRange: '443'

      direction: 'Outbound'
      priority: priorityOffset + 3
      protocol: 'Tcp'
      sourceAddressPrefix: 'VirtualNetwork'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-vn-apim-outbound'
    properties: {
      access: 'Allow'
      description: 'Allow traffic to apiManagement endpoint from vnet'
      destinationAddressPrefix: 'ApiManagement'

      destinationPortRange: '3443'

      direction: 'Outbound'
      priority: priorityOffset + 4
      protocol: '*'
      sourceAddressPrefix: 'VirtualNetwork'
      sourcePortRange: '*'
    }
  }
  {
    name: 'allow-vn-azure-monitor-outbound'
    properties: {
      access: 'Allow'
      description: 'Allow traffic to apiManagement endpoint from vnet'
      destinationAddressPrefix: 'AzureMonitor'

      destinationPortRanges: ['443','1886']

      direction: 'Outbound'
      priority: priorityOffset + 5
      protocol: '*'
      sourceAddressPrefix: 'VirtualNetwork'
      sourcePortRange: '*'
    }
  }
]

resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  scope: resourceGroup(LogAnalyticsResourceGroupName)
  name: LogAnalyticsName
}

module CreateNSGRules './network/network-security-group/main.bicep' = {
  name: '${nsgName}-nsg'
  params: {
    name: nsgName
    diagnosticSettings: [
      {
        name: 'logToAnalytics'
        logAnalyticsDestinationType: 'AzureDiagnostics'
        logCategoriesAndGroups: [
          {
            category: 'NetworkSecurityGroupEvent'
            enabled: true
          }
          {
            category: 'NetworkSecurityGroupRuleCounter'
            enabled: true
          }
        ]
        workspaceResourceId: laWorkspace.id
      }
    ]
    location: location
    tags: tags
    securityRules: apimSubnetNsg ? union(defaultRulez, otherRulez) : union(defaultRulez, rdpRulez)
  }
}

output id string = CreateNSGRules.outputs.resourceId

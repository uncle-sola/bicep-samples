

param Location string = resourceGroup().location
param tags object

@secure()
param adminUsername string
@secure()
param adminPassword string

param jumBoxIpName string

param vmName string
param vmInterfaceCardName string
param vmShutDownScheduleName string
param vmDiskName string
param subNetId string
param jumpBoxIpResourceGroup string


resource vmIPAddress 'Microsoft.Network/publicIPAddresses@2024-01-01' existing =  {
  scope: resourceGroup(jumpBoxIpResourceGroup)
  name: jumBoxIpName
}

resource vm 'Microsoft.Compute/virtualMachines@2024-07-01' = {
  name: vmName
  location: Location
  tags: tags
  zones: [
    '1'
  ]
  properties: {
    hardwareProfile: {
      vmSize: 'Standard_B2s'
    }
    additionalCapabilities: {
      hibernationEnabled: false
    }
    storageProfile: {
      imageReference: {
        publisher: 'MicrosoftWindowsDesktop'
        offer: 'Windows-10'
        sku: 'win10-22h2-pro-g2'
        version: 'latest'
      }
      osDisk: {
        osType: 'Windows'
        name: vmDiskName
        createOption: 'FromImage'
        caching: 'ReadWrite'
        managedDisk: {
          storageAccountType: 'Premium_LRS'
        }
        deleteOption: 'Delete'
        diskSizeGB: 127
      }
      dataDisks: []
      diskControllerType: 'SCSI'
    }
    osProfile: {
      computerName: vmName
      adminUsername: adminUsername
      adminPassword: adminPassword
      windowsConfiguration: {
        provisionVMAgent: true
        enableAutomaticUpdates: true
        patchSettings: {
          patchMode: 'AutomaticByOS'
          assessmentMode: 'ImageDefault'
          enableHotpatching: false
        }
      }
      secrets: []
      allowExtensionOperations: true
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: vmInterfaceCard.id
          properties: {
            deleteOption: 'Delete'
          }
        }
      ]
    }
    diagnosticsProfile: {
      bootDiagnostics: {
        enabled: true
      }
    }
    licenseType: 'Windows_Client'
  }
}

resource vmShutDownSchedule 'microsoft.devtestlab/schedules@2018-09-15' = {
  name: vmShutDownScheduleName
  location: Location
  tags: tags
  properties: {
    status: 'Enabled'
    taskType: 'ComputeVmShutdownTask'
    dailyRecurrence: {
      time: '2200'
    }
    timeZoneId: 'UTC'
    notificationSettings: {
      status: 'Enabled'
      timeInMinutes: 30
      emailRecipient: 'Olusola.Adio@connellsgroup.co.uk'
      notificationLocale: 'en'
    }
    targetResourceId: vm.id
  }
}

resource vmInterfaceCard 'Microsoft.Network/networkInterfaces@2024-01-01' = {
  name: vmInterfaceCardName
  location: Location
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
#disable-next-line use-resource-id-functions
        id: '${resourceId('Microsoft.Network/networkInterfaces',vmInterfaceCardName)}/ipConfigurations/ipconfig1'
        type: 'Microsoft.Network/networkInterfaces/ipConfigurations'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          publicIPAddress: {
            id: vmIPAddress.id
            properties: {
              deleteOption: 'Delete'
            }
          }
          subnet: {
            id: subNetId
          }
          primary: true
          privateIPAddressVersion: 'IPv4'
        }
      }
    ]
    dnsSettings: {
      dnsServers: []
    }
    enableAcceleratedNetworking: false
    enableIPForwarding: false
    disableTcpStateTracking: false
    nicType: 'Standard'
    auxiliaryMode: 'None'
    auxiliarySku: 'None'
  }
}

output publicIp string = vmIPAddress.properties.ipAddress
output privateIp string = vmInterfaceCard.properties.ipConfigurations[0].properties.privateIPAddress

param Location string = resourceGroup().location
param vmPrefix string
param vnetId string
param tags object

@secure()
param adminUsername string
@secure()
param adminPassword string

var vmName = '${vmPrefix}-vm'
var vmIPAddressName  = '${vmPrefix}-pip'
var vmInterfaceCardName = '${vmPrefix}-nic'
var vmShutDownScheduleName = 'shutdown-computevm-${vmPrefix}-vm'
var vmDiskName = '${vmPrefix}_OsDisk_1'

resource vmIPAddress 'Microsoft.Network/publicIPAddresses@2024-01-01' = {
  name: vmIPAddressName
  location: Location
  tags: tags
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  zones: [
    '1'
  ]
  properties: {
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    idleTimeoutInMinutes: 4
    ipTags: []
  }
}

resource vm 'Microsoft.Compute/virtualMachines@2024-07-01' = {
  name: vmName
  location: Location
  tags: tags
  zones: [
    '1'
  ]
  properties: {
    hardwareProfile: {
      vmSize: 'Standard_B2s'
    }
    additionalCapabilities: {
      hibernationEnabled: false
    }
    storageProfile: {
      imageReference: {
        publisher: 'MicrosoftWindowsDesktop'
        offer: 'Windows-10'
        sku: 'win10-22h2-pro-g2'
        version: 'latest'
      }
      osDisk: {
        osType: 'Windows'
        name: vmDiskName
        createOption: 'FromImage'
        caching: 'ReadWrite'
        managedDisk: {
          storageAccountType: 'Premium_LRS'
        }
        deleteOption: 'Delete'
        diskSizeGB: 127
      }
      dataDisks: []
      diskControllerType: 'SCSI'
    }
    osProfile: {
      computerName: vmName
      adminUsername: adminUsername
      adminPassword: adminPassword
      windowsConfiguration: {
        provisionVMAgent: true
        enableAutomaticUpdates: true
        patchSettings: {
          patchMode: 'AutomaticByOS'
          assessmentMode: 'ImageDefault'
          enableHotpatching: false
        }
      }
      secrets: []
      allowExtensionOperations: true
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: vmInterfaceCard.id
          properties: {
            deleteOption: 'Delete'
          }
        }
      ]
    }
    diagnosticsProfile: {
      bootDiagnostics: {
        enabled: true
      }
    }
    licenseType: 'Windows_Client'
  }
}

resource vmShutDownSchedule 'microsoft.devtestlab/schedules@2018-09-15' = {
  name: vmShutDownScheduleName
  location: Location
  tags: tags
  properties: {
    status: 'Enabled'
    taskType: 'ComputeVmShutdownTask'
    dailyRecurrence: {
      time: '2200'
    }
    timeZoneId: 'UTC'
    notificationSettings: {
      status: 'Enabled'
      timeInMinutes: 30
      emailRecipient: 'Olusola.Adio@connellsgroup.co.uk'
      notificationLocale: 'en'
    }
    targetResourceId: vm.id
  }
}

resource vmInterfaceCard 'Microsoft.Network/networkInterfaces@2024-01-01' = {
  name: vmInterfaceCardName
  location: Location
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
#disable-next-line use-resource-id-functions
        id: '${resourceId('Microsoft.Network/networkInterfaces',vmInterfaceCardName)}/ipConfigurations/ipconfig1'
        type: 'Microsoft.Network/networkInterfaces/ipConfigurations'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          publicIPAddress: {
            id: vmIPAddress.id
            properties: {
              deleteOption: 'Delete'
            }
          }
          subnet: {
#disable-next-line use-resource-id-functions
            id: '${vnetId}/subnets/UKS-POC-SUB0002-ApiGateway'
          }
          primary: true
          privateIPAddressVersion: 'IPv4'
        }
      }
    ]
    dnsSettings: {
      dnsServers: []
    }
    enableAcceleratedNetworking: false
    enableIPForwarding: false
    disableTcpStateTracking: false
    nicType: 'Standard'
    auxiliaryMode: 'None'
    auxiliarySku: 'None'
  }
}

output publicIp string = vmIPAddress.properties.ipAddress
output privateIp string = vmInterfaceCard.properties.ipConfigurations[0].properties.privateIPAddress

param apimName string
param apiName string
param apiOperationName string
param policystring string 


resource apim 'Microsoft.ApiManagement/service@2022-08-01' existing = {
  name: apimName
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' existing = {
  name: apiName
  parent: apim
}

resource apiOperation 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' existing = {
  name: apiOperationName
  parent: api
}


resource apiOperationPolicy 'Microsoft.ApiManagement/service/apis/operations/policies@2023-09-01-preview' = {
  parent: apiOperation
  name: 'policy'
  properties: {
    value: policystring
    format:'xml'
  }
}

output apiOperationPolicyValue string = apiOperationPolicy.properties.value
output apiOpsName string = apiOperation.name
output apiOpsDisplayName string = apiOperation.properties.displayName
output apiOpsDescription string = apiOperation.properties.description

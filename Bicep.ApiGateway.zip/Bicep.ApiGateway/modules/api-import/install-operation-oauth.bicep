param apimServiceName string

// API name needs to unique in APIM
param apiName string 

param apiOperationName string

param snippet string

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimServiceName
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01'  existing = {
  parent: apim
  name: apiName
}

resource apiOperation 'Microsoft.ApiManagement/service/apis/operations@2024-06-01-preview' existing = {
  parent: api
  name: apiOperationName
}

resource apiOperationPolicy 'Microsoft.ApiManagement/service/apis/operations/policies@2024-06-01-preview' = {
  name: 'policy'
  parent: apiOperation
  properties: {
    value: snippet
    format: 'rawxml'
  }
  dependsOn: [
    apiOperation
  ]
}

//output nameWithVersion string = nameWithVersion
output name string = api.name
output id string = api.id

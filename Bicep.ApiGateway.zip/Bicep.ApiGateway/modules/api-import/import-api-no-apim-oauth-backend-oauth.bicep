param apimServiceName string

// API name needs to unique in APIM
param apiName string 

// This url needs to be reachable for APIM
param apiUrl string

// There can be only one api without path
param apiPath string = ''
param apiVersion string
// API Display Name
param apiDisplayName string

param productDescription string
param productDisplayName string
param productName string 
param format string = 'openapi-link'
param versionSetName string
param versionSetDisplayName string
param subscriptionRequired string
param snippet string


// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimServiceName
}

resource versionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = {
  name: versionSetName
  parent: apim
  properties: {
    displayName: versionSetDisplayName
    versioningScheme: 'Segment'
  }
}

resource apimProduct 'Microsoft.ApiManagement/service/products@2023-03-01-preview' = {
  parent: apim
  name: productName
  properties: {
    description: productDescription
    displayName: productDisplayName
    subscriptionRequired: true
    approvalRequired: false
    state: 'published'
  }
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' = {
  parent: apim
  name: apiName
  properties: {
    format: format
    apiType: 'http'
    value: apiUrl
    path: apiPath
    displayName: apiDisplayName
    apiRevision: '1'
    apiVersionSetId: versionSet.id
    apiVersion: apiVersion
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    subscriptionRequired: subscriptionRequired == 'true' ? true : false
    protocols: [
      'https'
    ]
    authenticationSettings:{
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
  }
}

resource productApiLink 'Microsoft.ApiManagement/service/products/apiLinks@2023-05-01-preview' = {
  name: '${productDisplayName}-${apiDisplayName}-Link'
  parent: apimProduct
  properties: {
    apiId: api.id
  }
}

resource aLApiPoliciesOAuth 'Microsoft.ApiManagement/service/apis/policies@2022-08-01'  = {
  name: 'policy'
  parent: api
  properties: {
    value: snippet
    format: 'rawxml'
  }
  dependsOn: [
    productApiLink
  ]
}
//output nameWithVersion string = nameWithVersion
output name string = api.name
output id string = api.id

param apimServiceName string

// API name needs to unique in APIM
param apiName string 

// This url needs to be reachable for APIM
param apiUrl string

// There can be only one api without path
param apiPath string = ''
param apiVersion string
// API Display Name
param apiDisplayName string

param productDescription string
param productDisplayName string
param productName string 
param format string = 'openapi-link'
param versionSetName string
param versionSetDisplayName string
param subscriptionRequired string
param snippet string

@secure()
param clientAppId string
@secure()
param clientAppSecret string
@secure()
param backendAppId string
param clientAppIdName string
param clientAppSecretName string
param backendAppIdName string
param tokenEndpointUrlName string

param hostName string 
param tenantId string

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2024-06-01-preview' existing = {
  name: apimServiceName
}

resource versionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = {
  name: versionSetName
  parent: apim
  properties: {
    displayName: versionSetDisplayName
    versioningScheme: 'Segment'
  }
}

resource apimProduct 'Microsoft.ApiManagement/service/products@2023-03-01-preview' = {
  parent: apim
  name: productName
  properties: {
    description: productDescription
    displayName: productDisplayName
    subscriptionRequired: false
    state: 'published'
  }
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' = {
  parent: apim
  name: apiName
  properties: {
    format: format
    apiType: 'http'
    value: apiUrl
    path: apiPath
    displayName: apiDisplayName
    apiRevision: '1'
    apiVersionSetId: versionSet.id
    apiVersion: apiVersion
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    subscriptionRequired: subscriptionRequired == 'true' ? true : false
    protocols: [
      'https'
    ]
    authenticationSettings:{
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
  }
}

resource productApiLink 'Microsoft.ApiManagement/service/products/apiLinks@2023-05-01-preview' = {
  name: '${productDisplayName}-${apiDisplayName}-Link'
  parent: apimProduct
  properties: {
    apiId: api.id
  }
}


// named values

resource tokenEndpointUrlNamedValue 'Microsoft.ApiManagement/service/namedValues@2024-06-01-preview' = {
  parent: apim
  name: tokenEndpointUrlName
  properties: {
    displayName: tokenEndpointUrlName
    secret: false
    value: '${hostName}${tenantId}/oauth2/v2.0/token'
  }
}
resource clientAppIdNamedValue 'Microsoft.ApiManagement/service/namedValues@2024-06-01-preview' = {
  parent: apim
  name: clientAppIdName
  properties: {
    displayName: clientAppIdName
    secret: false
    value: clientAppId
  }
}
  

resource backEndAppIdNamedValue 'Microsoft.ApiManagement/service/namedValues@2024-06-01-preview' = {
  parent: apim
  name: backendAppIdName
  properties: {
    displayName: backendAppIdName
    secret: false
    value: 'api://${backendAppId}/.default'
  }
}

resource clientAppSecretNamedValue 'Microsoft.ApiManagement/service/namedValues@2024-06-01-preview' = {
  parent: apim
  name: clientAppSecretName
  properties: {
    displayName: clientAppSecretName
    secret: true
    value: clientAppSecret
  }
}

resource aLApiPoliciesOAuth 'Microsoft.ApiManagement/service/products/policies@2022-08-01'  = {
  name: 'policy'
  parent: apimProduct
  properties: {
    value: snippet
    format: 'rawxml'
  }
  dependsOn: [
    productApiLink
    backEndAppIdNamedValue
    clientAppSecretNamedValue
    clientAppIdNamedValue
    tokenEndpointUrlNamedValue
  ]
}

//output nameWithVersion string = nameWithVersion
output name string = api.name
output id string = api.id

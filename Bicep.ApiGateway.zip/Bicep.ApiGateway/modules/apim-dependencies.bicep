param LogAnalyticsName string
param AppInsightsName string
param apimName string
@secure()
param apimClientAppId string
@secure()
param apimClientAppSecret string
@secure()
param apimBackendAppId string

param clientAppIdName string
param backendAppIdName string

var envUrl = environment().authentication.loginEndpoint

resource apim 'Microsoft.ApiManagement/service@2023-09-01-preview' existing = {
  name: apimName
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' existing = {
  name: AppInsightsName
}

resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: LogAnalyticsName
}

resource Apim_Audit_Setting 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${apimName}-audit-settings'
  scope: apim
  properties: {
    workspaceId: laWorkspace.id
    logs: [
      {
        category: 'GatewayLogs'
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

resource appInsights_logger 'Microsoft.ApiManagement/service/loggers@2023-09-01-preview' = {
  parent: apim
  name: 'AppInsightsName'
  properties: {
    loggerType: 'applicationInsights'
    resourceId: appInsights.id
    credentials: {
      instrumentationKey: appInsights.properties.InstrumentationKey
    }
  }
}

resource apimName_applicationinsights 'Microsoft.ApiManagement/service/diagnostics@2023-09-01-preview' = {
  parent: apim
  name: 'applicationinsights'
  properties: {
    alwaysLog: 'allErrors'
    httpCorrelationProtocol: 'Legacy'
    verbosity: 'information'
    logClientIp: true
    loggerId: appInsights_logger.id
    sampling: {
      samplingType: 'fixed'
      percentage: 100
    }
    frontend: {
      request: {
        body: {
          bytes: 0
        }
      }
      response: {
        body: {
          bytes: 0
        }
      }
    }
    backend: {
      request: {
        body: {
          bytes: 0
        }
      }
      response: {
        body: {
          bytes: 0
        }
      }
    }
  }
}

resource clientAppIdNamedValue 'Microsoft.ApiManagement/service/namedValues@2024-06-01-preview' = {
  parent: apim
  name: clientAppIdName
  properties: {
    displayName: clientAppIdName
    secret: false
    value: apimClientAppId
  }
}
  

resource backEndAppIdNamedValue 'Microsoft.ApiManagement/service/namedValues@2024-06-01-preview' = {
  parent: apim
  name: backendAppIdName
  properties: {
    displayName: backendAppIdName
    secret: false
    value: 'api://${apimBackendAppId}'
  }
}


resource authorizationServer 'Microsoft.ApiManagement/service/authorizationServers@2024-06-01-preview' = {
  parent: apim
  name: 'OAuthServer'
  properties: {
    displayName: 'OAuth Server'
    description: 'OAuth Server'
    clientRegistrationEndpoint: 'http://localhost'
    authorizationEndpoint: '${envUrl}${tenant().tenantId}/oauth2/v2.0/authorize'
    authorizationMethods: [
      'GET'
    ]
    clientAuthenticationMethod: [
      'Body'
    ]
    tokenBodyParameters: []
    tokenEndpoint: '${envUrl}/${tenant().tenantId}/oauth2/v2.0/token'
    useInTestConsole: true
    useInApiDocumentation: false
    supportState: false
    defaultScope: 'api://${apimBackendAppId}/.default'
    grantTypes: [
      'authorizationCode'
      'clientCredentials'
    ]
    bearerTokenSendingMethods: [
      'authorizationHeader'
    ]
    clientId: apimClientAppId
    clientSecret: apimClientAppSecret
  }
}



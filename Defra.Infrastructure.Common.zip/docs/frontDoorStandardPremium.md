# Bicep template - frontDoorStandardPremium.bicep

This bicep file is designed to be consumed by other repositories across projects, to deploy an Azure Front Door. 

This file deploys following resources.
* [Microsoft.Cdn profiles](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/profiles?tabs=bicep)
* [Microsoft.Cdn profiles/afdEndpoints](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/profiles/afdendpoints?tabs=bicep)
* [Microsoft.Cdn profiles/afdEndpoints/routes](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/profiles/afdendpoints/routes?tabs=bicep)
* [Microsoft.Cdn profiles/originGroups](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/profiles/origingroups?tabs=bicep)
* [Microsoft.Cdn profiles/originGroups/origins](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/profiles/origingroups/origins?tabs=bicep)
* [Microsoft.Cdn profiles/ruleSets](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/profiles/rulesets?tabs=bicep)
* [Microsoft.Cdn profiles/secrets](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/profiles/secrets?tabs=bicep)
* [Microsoft.Cdn profiles/customDomains](https://docs.microsoft.com/en-us/azure/templates/microsoft.cdn/2020-09-01/profiles/customdomains?tabs=bicep)

This bicep file consumes other bicep files as modules
* templates\Microsoft.KeyVault\vaults\accessPolicies.bicep
    * Adds access policies for the front door instance to the provided keyVault.
    * Adds get secrets and certificates permissions.

## Parameters
* **`profile`** sets the name of the Front Door Name and Service principle Object Id.
    
    Example 
    ```json
        "profile": {
            "value": {
                "Name": "FrontDoorName",
                "ObjectId": "abca66d1-3412-384a-62a0-50b612a437d2"
            }
        }
    ```
* **`skuName`** sets the Front Door tier.
* **`certificates`** sets the TSL certificates to be assigned to the custom domains. 

    Example 
    ```json
        "certificates": {
            "value": [
                { 
                    "certificateKeyVaultName": "KeyVaultName",
                    "certificateKeyVaultSecretName": "defra-cert" , 
                    "subscriptionId": "abbca56d1-5412-584a-52a0-50b612a437d2",
                    "resourceGroupName": "rg1001"
                }
            ]
        }
    ```
* **`endpoints`** sets the collection of Front Door endpoints with routes, origin groups and rule sets.'.
     Example 
    ```json
        "endpoints": {
            "value": [
                {
                    "name": "endpoint1",
                    "route": { "name": "route1", "patternsToMatch":["/*"] },
                    "originGroup": {
                        "name": "originGroup1",
                        "origins": [
                            { "name": "origin1","hostName": "origin1.azurewebsites.net","priority": 1,"weight": 100 }
                        ]
                    },
                    "customDomain":{
                        "hostName": "hostname.com",
                        "dnsZoneName": "dnsZoneName",
                        "secretName": "defra-cert",
                        "silverLineIp": "100.100.100.00"
                    },
                    "ruleSet": [
                        {
                            "name": "testRuleSet",
                            "rules": [
                                {
                                    "name": "rule1",
                                    "order": 0,
                                    "conditions": [
                                        {
                                            "name": "UrlPath",
                                            "parameters": {
                                                "typeName": "DeliveryRuleUrlPathMatchConditionParameters",
                                                "operator": "RegEx",
                                                "negateCondition": false,
                                                "matchValues": [
                                                    "test/*"
                                                ],
                                                "transforms": []
                                            }
                                        },
                                        {
                                            "name": "RequestMethod",
                                            "parameters": {
                                                "typeName": "DeliveryRuleRequestMethodConditionParameters",
                                                "matchValues": [
                                                    "POST",
                                                    "GET",
                                                    "DELETE"
                                                ],
                                                "operator": "Equal",
                                                "negateCondition": false,
                                                "transforms": []
                                            }
                                        }
                                    ],
                                    "actions": [
                                        {
                                            "name": "UrlRedirect",
                                            "parameters": {
                                                "typeName": "DeliveryRuleUrlRedirectActionParameters",
                                                "redirectType": "PermanentRedirect",
                                                "destinationProtocol": "Https",
                                                "customPath": "/test123",
                                                "customHostname": "hostname.com"
                                            }
                                        }
                                    ],
                                    "matchProcessingBehavior": "Continue"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ```
* **`environment`** Current deployment environment. DEV, TST, etc.
* **`defaultTags`** Default tags for Front Door. Recommend to not use default, but to set as per the below example.

    Default
    ```bicep 
        defaultTags = {
            Environment: environment
            Tier: 'CDN'
            Location: 'global'
        }
    ```
    Example
    ```bicep 
        defaultTags = {
            ServiceCode: 'TRS'
            ServiceName: 'TRS'
            ServiceType: 'LOB'
            CreatedDate: createdDate
            Environment: environment
            Tier: 'CDN'
            Location: 'global'
        }
    ```
* **`customTags`** Specific tags for the Front Door, in addition to defaultTags.

    Example
    ```json
        "customTags": {
            "value": {
                "Name": "FrontDoorName",
                "Purpose": "CDN"
            }
        }
    ```
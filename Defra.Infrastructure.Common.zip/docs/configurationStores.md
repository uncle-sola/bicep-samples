# Bicep template - configurationStores.bicep

This bicep file is designed to be consumed by other repositories across projects, to deploy an Azure Configuration Store. 

This file deploys following resources.
* [Microsoft.AppConfiguration configurationStores](https://learn.microsoft.com/en-us/azure/templates/Microsoft.AppConfiguration/configurationStores?tabs=bicep)

## Parameters
* **`configStoreName`** The name of the App Configuration service.
* **`location`** The resource location.
* **`properties`**  Sets the Properties of the App Configuration service.

    Example 
    ```json
        "properties": {
            "value": {
                "disableLocalAuth": true,
                "enablePublicAccess":true,
                "enablePurgeProtection": true,
                "softDeleteRetentionInDays": 7
            }
        }
    ```
* **`privateEndpoint`** Private endpoint configuration details

    Example 
    ```json
       "privateEndpoint":{
            "value": {
                "name":"PrivateEndpointName",
                "vnetResourceGroup":"PrivateEndpointVNetResourceGroup",
                "vnetName":"PrivateEndpointVNetName",
                "vnetSubnetName":"PrivateEndpointSubnetName"
            }
        }
    ```
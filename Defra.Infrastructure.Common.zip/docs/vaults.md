# Bicep template - vaults.bicep

This bicep file is designed to be consumed by other repositories across projects, to deploy an Azure Key Vault. 

This file deploys following resources with standard set of common settings for a web app deployment.
* [Microsoft.KeyVault/vaults](https://learn.microsoft.com/en-us/azure/templates/microsoft.keyvault/vaults?pivots=deployment-language-bicep)

This bicep file consumes other bicep files as modules
* templates\Microsoft.Network\privateEndpoints.bicep
    * Creates a Private Endpoint to the ACR to disable public access to registry.

## Parameters
* **`vaultName`** sets the name of the key vault.
* **`sku`** SKU for the vault.
    Default:
    ```json
        {
            "name": "standard",
            "family": "A"
        }
    ```
* **`privateEndpointName`** sets the name of the private endpoint to the container registry.
* **`tenantId`** Azure tenant GUID.
* **`vnetResourceGroup`** Resource Group name of the VNET to which the Private Endpoint will be attached.
* **`vnetName`** Name of the VNET to which the Private Endpoint will be attached.
* **`vnetSubnetName`** Name of the subnet within VNET to which the Private Endpoint will be attached.
* **`location`** sets the location into which the resources should be deployed.
    Default:
     `resourceGroup().location`
* **`enablePublicAccess`** Controls the public access to key vault. Template creates a Private endpoint to key vault when public access is disabled and does not run the private endpoint post deployment scripts.
    Default:
     `true`
* **`customTags`** Specific tags for the functionapp, in addition to defaultTags.

    Example
    ```json
        "customTags": {
            "value": {
                "Name": "DEVCDPINFCR1001",
                "Purpose": "CDP-CONTAINER-REGISTRY"
            }
        }
    ```
* **`defaultTags`** Default tags for functionapp. Recommend to not use default, but to set as per the below example.

    Default
    ```bicep 
        defaultTags = {
            Environment: environment
            Tier: 'SHARED'
            Location: location
        }
    ```
    Example
    ```bicep 
        defaultTags = {
            ServiceCode: 'CDP'
            ServiceName: 'CDP'
            ServiceType: 'LOB'
            CreatedDate: createdDate
            Environment: environment
            Tier: 'WEB'
            Location: location
        }
    ```
* **`enableRbacAuthorization`** sets the permission model for key vault to Azure role based access control.
Default: `true`
* **`accessPolicies`** sets the vault access policy when `enableRbackAuthorisation` parameter is set to `false`.
Default: `[]`
* **`enableSoftDelete`** Enables soft delete for the objects in the vault.
Default: `true`
* **`enablePurgeProtection`** Enforces mandatory retention period for deleted vaults and vault objects.
Default: `true`

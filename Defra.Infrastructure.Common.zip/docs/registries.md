# Bicep template - registries.bicep

This bicep file is designed to be consumed by other repositories across projects, to deploy an Azure Container Registry. 

This file deploys following resources with standard set of common settings for a web app deployment.
* [Microsoft.ContainerRegistry/registries](https://learn.microsoft.com/en-us/azure/templates/microsoft.containerregistry/registries?pivots=deployment-language-bicep)

This bicep file consumes other bicep files as modules
* templates\Microsoft.Network\privateEndpoints.bicep
    * Creates a Private Endpoint to the ACR to disable public access to registry.

## Parameters
* **`acrName`** sets the name of the container registry.
* **`privateEndpointName`** sets the name of the private endpoint to the container registry.
* **`vnetResourceGroup`** Resource Group name of the VNET to which the Private Endpoint will be attached.
* **`vnetName`** Name of the VNET to which the Private Endpoint will be attached.
* **`vnetSubnetName`** Name of the subnet within VNET to which the Private Endpoint will be attached.
* **`location`** sets the location into which the resources should be deployed.
    Default:
     `resourceGroup().location`
* **`acrSku`** sets the SKU of the container registry.
    Default:
     `Basic`
* **`disablePublicAccess`** Controls the public access to registry.
    Default:
     `true`
* **`environment`** Current deployment environment. DEV, TST, etc.
* **`customTags`** Specific tags for the functionapp, in addition to defaultTags.

    Example
    ```json
        "customTags": {
            "value": {
                "Name": "DEVCDPINFCR1001",
                "Purpose": "CDP-CONTAINER-REGISTRY"
            }
        }
    ```
* **`defaultTags`** Default tags for functionapp. Recommend to not use default, but to set as per the below example.

    Default
    ```bicep 
        defaultTags = {
            Environment: environment
            Tier: 'SHARED'
            Location: location
        }
    ```
    Example
    ```bicep 
        defaultTags = {
            ServiceCode: 'CDP'
            ServiceName: 'CDP'
            ServiceType: 'LOB'
            CreatedDate: createdDate
            Environment: environment
            Tier: 'WEB'
            Location: location
        }
    ```

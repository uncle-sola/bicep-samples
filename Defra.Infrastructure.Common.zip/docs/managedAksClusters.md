# Bicep template - managedClusters.bicep

This bicep file is designed to be consumed by other repositories across projects, to deploy an Azure Kubernetes Cluster. 

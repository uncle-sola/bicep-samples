# Bicep template - webApps.bicep

This bicep file is designed to be consumed by other repositories across projects, to deploy an Azure web app. 

This file deploys following resources with standard set of common settings for a web app deployment.
* [Microsoft.Web sites](https://docs.microsoft.com/en-us/azure/templates/microsoft.web/sites?tabs=bicep)
* [Microsoft.Web sites/config 'appsettings'](https://docs.microsoft.com/en-us/azure/templates/microsoft.web/sites/config-appsettings?tabs=bicep)
* [Microsoft.Web sites/config 'web'](https://docs.microsoft.com/en-us/azure/templates/microsoft.web/sites/config-web?tabs=bicep)
* [Microsoft.Web sites/config 'authsettingsV2'](https://docs.microsoft.com/en-us/azure/templates/microsoft.web/sites/config-authsettingsv2?tabs=bicep)

This bicep file consumes two other bicep files as modules
* templates\Microsoft.KeyVault\vaults\accessPolicies.bicep
    * Adds access policies for the created web app to the provided keyVault.
    * Adds get and list secrets permissions by default, this can be optionally overwritten.
* templates\Microsoft.Authorization\roleAssignments.bicep
    * Adds role assignment for the created web app to the provided storage account with the provided roleId.

## Parameters
* **`webAppName`** sets the name of the app.
* **`webAppURLPrefix`** sets the URL prefix, i.e., the first half that forms the URL to the app, usually webapp name.
* **`webAppDomainSuffix`** sets the domain suffix, that forms the latter half of the URL to the app. 

    Example 
    ```json
        "webAppDomainSuffix": {
            "value": "azurewebsites.net"
        }
    ```
* **`aspName`** sets the name of the associated App Service plan.
* **`vnetResourceGroup`** sets the resource group name of the VNet in which the app will be created.
* **`vnetName`** sets the VNet name in which the app will be created.
* **`vnetSubnetName`** sets the subnet name in which the app will be created.
* **`buildAgentIPAddress`** Semicolon separated list of IP Addresses to be allowed under security restrictions, typically build agent IPs.

    Example
    ```json
        "buildAgentIPAddress": {
            "value": "11.110.11.40/32;11.110.11.41/32"
        }
    ```
* **`appInsightsResourceGroup`** sets resource group name of the existing ApplicationInsights resource.
* **`appInsightsName`** sets the name of the associated ApplicationInsights resource.
* **`environment`** Current deployment environment. DEV, TST, etc.
* **`defaultTags`** Default tags for webapp. Recommend to not use default, but to set as per the below example.

    Default
    ```bicep 
        defaultTags = {
            Environment: environment
            Tier: 'WEB'
            Location: location
        }
    ```
    Example
    ```bicep 
        defaultTags = {
            ServiceCode: 'TRS'
            ServiceName: 'TRS'
            ServiceType: 'LOB'
            CreatedDate: createdDate
            Environment: environment
            Tier: 'WEB'
            Location: location
        }
    ```
* **`customTags`** Specific tags for the webapp, in addition to defaultTags.

    Example
    ```json
        "customTags": {
            "value": {
                "Name": "DEVWEBAPP01",
                "Purpose": "DATA_MAPPING-API"
            }
        }
    ```

* **`webAppUserAssignedIdentity`** UserAssignedIdentity to assign web app, optionally. Parameters are: {name, resourceGroupName}.

    Example
    ```json
    "webAppUserAssignedIdentity":{
            "value": {
              "name": "DEVTRDINFMID1001",
              "ResourceGroupName": "DEVRG001"
            }
        },
    ```

* **`allowSubnetNames`** this is a semicolon separated list of subnet names for additional subnets (under above vnetName) to be allowed under security restrictions, typical example could be to allow APIM subnet.

    Example
    ```json
        "allowSubnetNames": {
            "value": "DEVSubnet01;DEVSubnet02"
        }
    ```

* **`allowSubnetIds`** this is a semicolon separated list of subnet Ids for additional subnets (outside of the above vnetName) to be allowed under security restrictions.

    Example
    ```json
        "allowSubnetIds": {
            "value": "/subscriptions/subscriptionID/resourceGroups/DEVRG001/Microsoft.Network/virtualNetworks/VNet001/subnets/DEVSubnet001;/subscriptions/subscriptionID/resourceGroups/DEVRG001/Microsoft.Network/virtualNetworks/VNet001/subnets/DEVSubnet002"
        }
    ```
param  bool = true

* **`enableADAuthentication`** sets up AD Authentication if true.
     Default
     `true`

* **`aspClientId`** sets the API\'s backend \'Client ID\' for OAuth.

* **`keyvaultAccessPolicy`** collection of objects to be passed optionally, to assign KeyVault access policies to the app on a given Key Vault. Parameters are: {name, resourceGroupName, permissions(optional)}

    Example
    ```json
        "keyvaultAccessPolicy": {
            "value": [{
                "name": "DEVKV01",
                "resourceGroupName": "DEVRG01"
            }]
    ```

* **`storageAccountRoleAssignments`** collection of objects indicative of the storage account roles to be assigned to the app, on a given storage account. For example, Contributer to a storage account. Parameters are: {roleId, resourceType, resourceGroupName, resourceName (resourceName is the storage account name)}

    Example
    ```json
        "roleAssignmentCollection": { 
            "value": [
                {
                "roleId": "acdd72a7-3385-48ef-bd42-f606fba81ae7",
                "resourceGroupName": "DEVRG01",
                "resourceName": "DEVSA01"
                },
                {
                "roleId": "2a2b9908-6ea1-4ae2-8e65-a410df84e7d1",
                "resourceGroupName": "DEVRG01",
                "resourceName": "DEVSA01"
                }
            ]
        }
    ```

* **`appConfigurationRoleAssignments`** collection of objects indicative of the app configuration roles to be assigned to the app, on a given appConfiguration service. Parameters are: {roleId, resourceType, resourceGroupName, resourceName (resourceName is the appConfiguration name)}

    Example
    ```json
        "roleAssignmentCollection": { 
            "value": [
                {
                "roleId": "516239f1-63e1-4d78-a4de-a74fb236a071",
                "resourceGroupName": "DEVRG01",
                "resourceName": "DEVAC01"
                }
            ]
        }
    ```

* **`serviceBusRoleAssignments`**  collection of objects indicative of the service bus roles to be assigned to the app, on a given Service Bus. Parameters are: {roleId, resourceType, resourceGroupName, resourceName (resourceName is the appConfiguration name)}

    Example
    ```json
        "roleAssignmentCollection": { 
            "value": [
                {
                "roleId": "090c5cfd-751d-490a-894a-3ce6f1109419",
                "resourceGroupName": "DEVRG01",
                "resourceName": "DEVSB01"
                }
            ]
        }
    ```

* **`use32BitWorkerProcess`** Sets the property use32BitWorkerProcess under the sites/config. Optional, defaults to true.
     Default
     `true`

* **`webSocketsEnabled`** Sets the property webSocketsEnabled under the sites/config. Optional, defaults to false.
     Default
     `false`

* **`location`** sets the location into which the resources should be deployed.
     Default
     `resourceGroup().location`

* **`deploymentDate`** Optional. default: `utcNow('yyyyMMdd-HHmmss')`
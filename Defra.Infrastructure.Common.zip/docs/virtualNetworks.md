# Bicep template - virtualNetworks.bicep

This bicep file is designed to be consumed by other repositories across projects, to deploy a Virtual Network and related components. 

This file deploys following resources with standard set of common settings for a web app deployment.
* [Microsoft.Network virtualNetworks](https://learn.microsoft.com/en-us/azure/templates/microsoft.network/virtualnetworks?pivots=deployment-language-bicep)
* [Microsoft.Network networkSecurityGroups](https://learn.microsoft.com/en-us/azure/templates/microsoft.network/networksecuritygroups?pivots=deployment-language-bicep)
* [Microsoft.Network routeTables](https://learn.microsoft.com/en-us/azure/templates/microsoft.network/routetables?pivots=deployment-language-bicep)

## Parameters
* **`vnetInfra`** sets the name of the app.
    Example 
    ```json
        "name": "DEVCDPNETVN1401",
        "addressPrefix": ["VNET Address Space"],
        "subnets": [
            {
                "name": "Subnet Name",
                "properties": {
                    "addressPrefix": "Address prefix",
                    "serviceEndpoints": [
                        { "service": "Microsoft.AzureActiveDirectory" }
                    ],
                    "networkSecurityGroup": {
                        "id": "Resource Id"
                    },
                    "privateEndpointNetworkPolicies": "Enabled",
                    "privateLinkServiceNetworkPolicies": "Enabled"
                }
            }
        ],
        "dnsServers": "Server IPs",
        "customTags": {
            "Name": "DEVCDPNETVN1401",
            "Purpose": "CDP-VNET"
        }
    ```
* **`routeTable`** sets the URL prefix, i.e., the first half that forms the URL to the app, usually functionapp name.
    Example 
    ```json
        "name": "UDR-Spoke-Route-From-DEVCDPNETVN1401",
        "customTags": {
            "Name": "UDR-Spoke-Route-From-DEVCDPNETVN1401",
            "Purpose": "UDR-SPOKE-ROUTETABLE"
        },
        "virtualApplicanceIp": "Next Hop IP for the Network Traffic"
    ```
* **`nsgs`** sets the domain suffix, that forms the latter half of the URL to the app. 

    Example 
    ```json
        "name": "DEVCDPNETNSG1401",
        "rules": [
            {
                "name": "ApiInbound",
                "properties": {
                    "description": "Description",
                    "protocol": "TCP",
                    "sourcePortRange": "*",
                    "destinationPortRange": 443,
                    "sourceAddressPrefix": "ApiManagement",
                    "destinationAddressPrefix": "VirtualNetwork",
                    "access": "Allow",
                    "priority": 100,
                    "direction": "Inbound"
                }
            }
        ],
        "customTags": {
            "Name": "DEVCDPNETNSG1401",
            "Purpose": "EXTERNAL-APIS-NSG"
        }
    ```
* **`location`** sets the location into which the resources should be deployed.

* **`defaultTags`** Default tags for functionapp. Recommend to not use default, but to set as per the below example.

    Default
    ```bicep 
        defaultTags = {
            Environment: environment
            Tier: 'NETWORK'
            Location: location
        }
    ```
    Example
    ```bicep 
        defaultTags = {
            ServiceCode: 'CDP'
            ServiceName: 'CDP'
            ServiceType: 'LOB'
            CreatedDate: createdDate
            Environment: environment
            Tier: 'WEB'
            Location: location
        }
    ```

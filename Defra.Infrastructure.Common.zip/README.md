# Introduction 
Defra.Infrastructure.Common repository contains all the common Azure infrastructure templates that can be shared across Major Project's infrastructure deployments using Azure DevOps to build and deploy their code.

## Templates
The template folder contains the Azure Resource Manager templates to deploy different types of Azure resources. These templates comprise of sets of standard configurations which are commonly used and are reusable across many deployments.

### Locating templates in the repository
The templates are organized in a folder structure similar to [Microsoft template reference](https://docs.microsoft.com/en-us/azure/templates/).

For example, bicep file related to key vaults could be found at templates\Microsoft.KeyVault. Below image from Microsoft template reference docs.
![Microsoft template reference](./docs/images/templatelocationreference.jpg)

### Bicep files
The bicep files are treated as a template for deploying infrastructure resources to Azure.
These templates or bicep files may contain nested module which is literally another bicep file.
These files may require some inputs either as mandatory or optional parameters.
The bicep files are created keeping in mind the common infrastructure deployment requirements.

While you could consume any of them bicep files as per your needs, here are a list of bicep files designed for deploying a standard set of resources and its dependencies:
* templates\Microsoft.Web\webApps.bicep. [refer documentation](./docs/webApps.md)
* templates\Microsoft.Web\functionApps.bicep

And these are some bicep files designed to be consumable from other bicep files for common repeatable scenarios:
* templates\Microsoft.Authorization\roleAssignments.bicep
* templates\Microsoft.KeyVault\vaults\accessPolicies.bicep

### Consuming bicep templates

The bicep templates could be consumed from any other repository as follows:
* Checkout the Defra.Infrastructure.Common repository in your DevOps pipeline.
* Create a new bicep file in your repository, this file consumes the required bicep file from Defra.Infrastructure.Common as a module.
    * Bicep module can be referenced using relative path (pointing to the checked-out Defra.Infrastructure.Common repo)
    * This file accepts input parameters to pass on to the referenced module.
    * Create a parameter.json file having values for the declared parameters.

Here is pseudo code for an example bicep file.

```yaml
param aspName string
param webAppName string
.
.
.

module webApp '../../../Defra.Infrastructure.Common/templates/arm/Microsoft.Web/webApps.bicep' = {
  name: deploymentName
  params: {
    webAppName: webAppName
    webAppURLPrefix: webAppURLPrefix
    webAppDomainSuffix: webAppDomainSuffix
    .
    .
    .
  }
}
```

Sample yaml pipeline check-out repo

```yaml
  repositories:
  - repository: DevOpsCommonInfra
    name: DEFRA-DEVOPS-COMMON/Defra.Infrastructure.Common
    type: git
    ref: master

    .
    .
    .
    
    steps:
    - checkout: DevOpsCommonInfra
```




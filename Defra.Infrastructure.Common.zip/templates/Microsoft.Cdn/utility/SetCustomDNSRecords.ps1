[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$dnsZoneRgName,
    [Parameter(Mandatory = $false)]
    [int]$Ttl=3600,
    [Parameter(Mandatory = $false)]
    [string]$deploymentOutputsVariableName = 'azureDeploymentOutputs'
)

try {

    $output = (get-item env:$deploymentOutputsVariableName).Value | ConvertFrom-Json

    foreach ($record in $output.customDomainRecords.value) {

        Write-Host "Updating DNS 'TXT' recod for DNS($($record.customDomainHostName))"
            
        $dnsAuthRecordSetName = $record.customDomainDnsTxtRecordName -replace ".$($record.customDomainDnsZoneName)" , ""
    
        New-AzDnsRecordSet -Name "$($dnsAuthRecordSetName)" `
            -RecordType TXT `
            -ZoneName $record.customDomainDnsZoneName `
            -ResourceGroupName $dnsZoneRgName `
            -Ttl $Ttl `
            -DnsRecords (New-AzDnsRecordConfig -Value "$($record.customDomainDnsTxtRecordValue)") -Overwrite

        $dnsRecordSetName = $dnsAuthRecordSetName -replace "_dnsauth.",""
              
        if($record.silverLineIp) {

            Write-Host "Updating DNS 'A' recod for DNS($($record.customDomainHostName)) with the Ip4Address:($($record.silverLineIp))"

            New-AzDnsRecordSet -Name "$($dnsRecordSetName)" `
                -RecordType A `
                -ZoneName $record.customDomainDnsZoneName `
                -ResourceGroupName $dnsZoneRgName `
                -Ttl $Ttl `
                -DnsRecords (New-AzDnsRecordConfig -Ipv4Address "$($record.silverLineIp)") -Overwrite 
        }

    }        
}
catch {
    Write-Error "Error updating DNS records : $($_.Exception.Message)"
}

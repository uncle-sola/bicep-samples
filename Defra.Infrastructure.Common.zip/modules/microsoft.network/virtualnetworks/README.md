# Vitual Networks

The Virtual Networks bicep module.

## Description

The Virtual Networks bicep module.

## Parameters

| Name          | Type     | Required | Description               |
| :------------ | :------: | :------: | :------------------------ |
| `vnetInfra`   | `object` | Yes      | The VNET Infra object.    |
| `routeTable`  | `object` | Yes      | The Route Table object.   |
| `nsgs`        | `array`  | Yes      | The list of NSGS.         |
| `location`    | `string` | Yes      | The location name.        |
| `defaultTags` | `object` | Yes      | The defaults tags object. |

## Outputs

| Name | Type | Description |
| :--- | :--: | :---------- |

## Examples

### Example 1

```bicep
{
    location: location
    defaultTags: {
      ServiceCode: 'CDP'
      ServiceName: 'CDP'
      ServiceType: 'LOB'
    }
    nsgs: [
      {
        name: 'DEVCDPNETNSG1401'
        rules: [
          {
            name: 'ApiInbound'
            properties: {
              description: 'Description'
              protocol: 'TCP'
              sourcePortRange: '*'
              destinationPortRange: 443
              sourceAddressPrefix: 'ApiManagement'
              destinationAddressPrefix: 'VirtualNetwork'
              access: 'Allow'
              priority: 100
              direction: 'Inbound'
            }
          }
        ]
        customTags: {
          Name: 'DEVCDPNETNSG1401'
          Purpose: 'EXTERNAL-APIS-NSG'
        }
      }
    ]
    routeTable: { }
    vnetInfra: {
      name: 'DEVCDPNETVN1401'
      addressPrefix: [ '10.0.0.1/24' ]
      subnets: [
        {
          name: 'Subnet Name'
          addressPrefix: '10.0.0.1/28'
          serviceEndpoints: [
              { service: 'Microsoft.AzureActiveDirectory' }
            ]
          nsgName: 'DEVCDPNETNSG01'
          routeTableName: 'route-deplotment-01'
        }
      ]
      dnsServers: '10.1.0.100'
      customTags: {
        Name: 'DEVCDPNETVN1401'
        Purpose: 'CDP-VNET'
      }
    }
  }
```
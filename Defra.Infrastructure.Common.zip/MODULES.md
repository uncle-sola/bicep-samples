# Introduction 

The `modules` folder in the repository contains the source code of all the Azure infrastructure bicep modules in the Private CDP Common bicep registry which can be shared across Major Project's infrastructure deployments.

# Create or Update Bicep Modules

Please follow the below instrctions to Create or update a module.

## Prerequisite

- Install [.NET 6.0 Runtime](https://dotnet.microsoft.com/en-us/download/dotnet/6.0/runtime)
- Install the [Bicep registry module](https://www.nuget.org/packages/Azure.Bicep.RegistryModuleTool/) tool by running:
  - `dotnet tool install --global Azure.Bicep.RegistryModuleTool`
- Create a feature branch from main branch.

## Creating a new module

### Creating a directory for the new module

Add a new directory under the `modules` folder in your local repository with the path in lowercase following the pattern `<ModuleGroup>/<ModuleName>`. Typical `<ModuleGroup>` names are Azure resource provider names, and the `<ModuleName>` are the name of the resource. For examples:

- `microsoft.network\virtualnetworks`
- `microsoft.cdn\frontdoor`
- `microsoft.appconfiguration\configurationStores`

### Generating module files

> Before generating module files, please make sure both Bicep CLI (version: `0.12.40`) and Bicep registry module tool installed on your machine. This is to avoid any validation errors in the CI validation, since the CI uses the version (`0.12.40`) of Bicep CLI and Bicep registry module tool.

Open a terminal and navigate to the newly created folder. From there, run the following command to generate the required files for the module:

```
brm generate
```

You should be able to see these files created in the module folder:
| File Name | Description |
| :--------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `metadata.json` | An JSON file containing module metadata. You must edit the file to provide the metadata values. |
| `main.bicep` | An empty Bicep file that you need to update. This is the main module file. |
| `test/main.test.bicep` | A Bicep file to be deployed in the PR merge validation pipeline to test if `main.bicep` is deployable. You must add at least one test to the file. A module referencing `main.bicep` is considered a test. |
| `main.json` | The main ARM template file compiled from `main.bicep`. This is the artifact that will be published to the CDP Common registry. You should not modify the file. |
| `README.md` | The README file generated based on the contents of `metadata.json` and `main.bicep`. You need to update this file to add examples. |
| `version.json` | The module version file. It is used together with `main.json` to calculate the patch version number of the module. Every time `main.json` is changed, the patch version number gets bumped. The full version (`<ModuleMajorVersion>.<ModuleMinorVersion>.<ModulePatchVersion>`) will then be assigned to the module before it gets published to the CDP Common registry. The process is handled by the module publishing CI automatically. |

### Modifying module files

The files that you need to edit are are `metadata.json`, `main.bicep`, `test/main.test.bicep`, `README.md`, and `version.json`.

The `metadata.json` file contains metadata of the module including `name`, `description`, and `owner`. You must provide the values for them. Below is a sample metadata file with the constraints of each property commented:

```JSONC
{
  "$schema": "https://aka.ms/bicep-registry-module-metadata-file-schema-v2#",
  "name": "Vitual Networks",
  "summary": "The Virtual Networks bicep module.",
  "owner": "DEFRA"
}
```
In the `main.bicep` file, make sure to provide a description for each parameter and output.. You can create other Bicep files inside the module folder and reference them as local modules in `main.bicep` if needed. You may also reference other registry modules to help build your module. If you do so, make sure to add them as external references (CDP Common registry reference) with specific version numbers. We should not reference other registry modules through local file path, since they may get updated over time.

The `test/main.test.bicep` file is the test file for `main.bicep`. It will be deployed into a test resource group in the PR merge pipeline to make sure main.bicep is deployable. You must add at least one test to the file. To add a test, create a module referencing main.bicep and provide values for the required parameters. You may write multiple tests to ensure different paths of the module are covered. If any of the parameters are secrets, make sure to provide generated values instead of hard-coded ones. Below is an example showing how to use the combination of some string functions to construct a dynamic azure-compatible password for a virtual machine:


```bicep
@secure()
param vmPasswordSuffix string = uniqueString(newGuid())

var vmPassword = 'pwd#${vmPasswordSuffix}'

module testMain '../main.bicep' = {
  name: 'testMain'
  params: {
    vmUsername: 'testuser'
    vmPassword: vmPassword
  }
}
```

The `README.md` file is the documentation of the module. A large proportion of the file contents, such as the parameter and output tables, are generated based on the contents of other files. However, you must update the `Examples` section manually to provide examples of how the module can be used.

The `version.json` file defines the MAJOR and MINOR version number of the module. Update the value of the `“version"` property to specify a version, e.g., `"1.0"`.

Once you are done editing the files, run `brm generate` again to refresh `main.json` and `README.md`.

## Updating an existing module

To update an existing module, refer to the [Modifying module files](#modifying-module-files) section to update and regenerate the module files. Depending on the changes you make, you may need to bump the version in the `version.json` file.

### Bumping MAJOR version

You should bump the MAJOR version when you make breaking changes to the module.

### Bumping MINOR version

You should increase the MINOR version when you change the module in a backward-compatible manner, including the following scenarios:

- Adding a new parameter with a default value
- Adding a new output
- Adding a new value to the allowed value array of a parameter

### Bumping PATCH version

If your change is non-breaking but does not require updating the MINOR version, the PATCH version will be bumped by the CI automatically when publishing the module to the Bicep registry once your pull request is merged. The PATCH version is increased by the git commit "height" since last time the `main.json` or `metadata.json` file of a module was changed on the `main` branch. Because we only allow squash merging, the git commit height is always 1 for each module update PR merged into `main`. The following scenarios will trigger a PATCH version bump:

- Updating the metadata file
- Updating the description of a parameter
- Updating the description of an output
- Adding a variable
- Removing a variable
- Renaming a variable
- Bumping the API version of a resource
- Bumping the MINOR or PATCH version of a referenced CDP Common registry module

## Validating module files

> Before running the command, don't forget to run `generate` to ensure all files are up-to-date.

You may use the Bicep registry module tool to validate the contents of the registry module files. To do so, invoke the follow command from the module folder:

```
brm validate
```

# Publishing a module

Once your pull request is approved and merged to the `main` branch, an Azure Pipeline will be triggered to publish the module to the CDP common bicep registry automatically.
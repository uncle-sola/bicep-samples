param apimName string

param alClientAppIdV21Ext1 string
param alClientAppIdV21Ext2 string
param alClientAppIdV21Ext3 string
param alIssuerExt string
param alBackEndAppId string

param cappApiUrl string

param cappOatApiUrl string
param deployAll string
param deployOAT string

param cappFormat string
param cappOriginUrl string
param aLServiceURL string
param aLServiceURLExtV1 string
param boomicertificateName string

param chServiceurlv22Ext string

param elServiceurlv1Ext string
param environment string

var alV21ContentExt = loadTextContent('policy-snippets/addressLookupV21SnippetExt.txt')

var eLabContent = loadTextContent('json-snippets/eLabExchangeOpenApi.json')

var deploy = (deployAll == 'true')
var deployOATAPI = (deployOAT == 'true' && deployAll == 'true')

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}


module importCompaniesHouse 'import-companies-house-api-v22.bicep' = {
  name: 'importCompaniesHouse'
  params:{
    boomicertificateName: boomicertificateName
    apimName: apimName
    deploy: deploy
    environment: environment
    chServiceurlv22: chServiceurlv22Ext
  }
  dependsOn: [
    apim
  ]
}

// module importAddressLookupV1 'import-address-lookup-api-v1.bicep' = {
//   name: 'importAddressLookupV1'
//   params:{
//     aLServiceURL: aLServiceURLExtV1
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//     environment: environment
//   }
//   dependsOn: [
//     apim
//   ]
// }

// module importAddressLookup 'import-address-lookup-api.bicep' = {
//   name: 'importAddressLookup'
//   params:{
//     aLServiceURL: aLServiceURL
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//     alClientAppIdV21Ext1: alClientAppIdV21Ext1
//     alClientAppIdV21Ext2: alClientAppIdV21Ext2
//     alClientAppIdV21Ext3: alClientAppIdV21Ext3
//     alIssuerExt: alIssuerExt
//     alBackEndAppId: alBackEndAppId
//     addressLookup21snippet: alV21ContentExt
//   }
//   dependsOn: [
//     apim
//   ]
//}

module importElabExchange 'import-eLab-Exchange-api-v1.bicep' = {
  name: 'importElabExchange'
  params:{
    elServiceURL: elServiceurlv1Ext
    boomicertificateName: boomicertificateName
    apimName: apimName
    environment: environment
    apiName: 'eLabExchange'
    apiPath: 'eLabExchange'
    apiDisplayName: 'eLabExchange'
    apiVersion: 'v1.0'
    productDescription: 'eLabExchange Product'
    productDisplayName: 'eLabExchange'
    productName: 'eLabExchange'
    openApiSpec: eLabContent
  }
  dependsOn: [
    apim
  ]
}

// module importCAPPAPI 'import-capp-api.bicep' = {
//   name: 'importCAPPModule'
//   params: {
//     apimServiceName: apimName
//     apiName: 'capp'
//     apiUrl: cappApiUrl
//     apiPath: 'capp'
//     apiDisplayName: 'CAPP'
//     apiVersion: 'v1'
//     productDescription: 'CAPP Charge Calculation'
//     productDisplayName: 'CAPP'
//     productName: 'CAPP'
//     format: cappFormat
//     cappOriginUrl: cappOriginUrl
//   }
//   dependsOn: [
//     apim
//   ]
// }

// module importCAPPOATAPI 'import-capp-api.bicep' = if (deployOATAPI) {
//   name: 'importCAPPOATModule'
//   params: {
//     apimServiceName: apimName
//     apiName: 'capp-oat'
//     apiUrl: cappOatApiUrl
//     apiPath: 'capp-oat'
//     apiDisplayName: 'CAPP OAT'
//     apiVersion: 'v1'
//     productDescription: 'CAPP OAT Charge Calculation'
//     productDisplayName: 'CAPP OAT'
//     productName: 'CAPPOAT'
//     cappOriginUrl: cappOriginUrl
//   }
//   dependsOn: [
//     apim
//   ]
// }


module importCAPPOAuthProduct 'import-capp-oauth-product.bicep' = {
  name: 'importCAPPOAuthModule'
  params: {
    environment: environment
    apimServiceName: apimName
    apiName: 'capp'
    productDescription: 'OAuth Product for CAPP API'
    productDisplayName: 'CAPP OAUTH'
    productName: 'capp-oauth'
  }
  dependsOn: [
    apim
  ]
}


param elServiceURL string
param boomicertificateName string
param apimName string


param openApiSpec string

// API name needs to unique in APIM
param apiName string 


// There can be only one api without path
param apiPath string = ''
param apiVersion string

// API Display Name
param apiDisplayName string

param productDescription string
param productDisplayName string
param productName string 


param environment string


var devSnippet = loadTextContent('policy-snippets/eLab-exchange-v1-dev.txt')
var tstSnippet = loadTextContent('policy-snippets/eLab-exchange-v1-tst.txt')
var preSnippet = loadTextContent('policy-snippets/eLab-exchange-v1-pre.txt')
var prdSnippet = loadTextContent('policy-snippets/eLab-exchange-v1-prd.txt')


var finalSnippet = environment == 'DEV' ? devSnippet
  : environment == 'TST' ? tstSnippet
  : environment == 'PRE' ? preSnippet
  : environment == 'PRD' ? prdSnippet
  : 'unknown'




// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}

resource boomiCertificate 'Microsoft.ApiManagement/service/certificates@2023-05-01-preview' existing = {
  parent: apim
  name: boomicertificateName
}

//Address Lookup API - Starts 

resource eLabExchangeVersionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = {
  name: 'eLabExchangepVersionset'
  parent: apim
  properties: {
    displayName: 'eLabExchange'
    versioningScheme: 'Segment'
  }
}


resource apimProduct 'Microsoft.ApiManagement/service/products@2023-03-01-preview' = {
  parent: apim
  name: productName
  properties: {
    description: productDescription
    displayName: productDisplayName
    subscriptionRequired: true
    approvalRequired: false
    state: 'published'
  }
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' = {
  parent: apim
  name: apiName
  properties: {
    format: 'openapi+json'
    apiType: 'http'
    serviceUrl: elServiceURL
    value: openApiSpec
    path: apiPath
    displayName: apiDisplayName
    apiRevision: '1'
    apiVersionSetId: eLabExchangeVersionSet.id
    apiVersion: apiVersion
    subscriptionRequired: false
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    protocols: [
      'https'
    ]
    authenticationSettings:{
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
  }
}

resource productApiLink 'Microsoft.ApiManagement/service/products/apiLinks@2023-05-01-preview' = {
  name: '${productDisplayName}-${apiDisplayName}-Link'
  parent: apimProduct
  properties: {
    apiId: api.id
  }
}

resource eLabExchangeApiPolicies 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' =  {
  name: 'policy'
  parent: api
  properties: {
    value: finalSnippet
    format: 'xml'
  }
  dependsOn:[
    boomiCertificate
  ]
}

//output nameWithVersion string = nameWithVersion
output name string = api.name
output id string = api.id

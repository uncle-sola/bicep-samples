param apimServiceName string

// API name needs to unique in APIM
param apiName string 

// This url needs to be reachable for APIM
param apiUrl string

// There can be only one api without path
param apiPath string = ''
param apiVersion string

// API Display Name
param apiDisplayName string

param productDescription string
param productDisplayName string
param productName string 
var deployPolicy = (apiName == 'capp')
param cappOriginUrl string

// Existing APIM service
resource apimService 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimServiceName
}

resource versionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = {
  name: apiName
  parent: apimService
  properties: {
    displayName: apiDisplayName
    versioningScheme: 'Segment'
  }
}

resource apimProduct 'Microsoft.ApiManagement/service/products@2023-03-01-preview' = {
  parent: apimService
  name: productName
  properties: {
    description: productDescription
    displayName: productDisplayName
    subscriptionRequired: true
    approvalRequired: false
    state: 'published'
  }
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' = {
  parent: apimService
  name: apiName
  properties: {
    format: 'openapi'
    apiType: 'http'
    value: apiUrl
    path: apiPath
    displayName: apiDisplayName
    apiRevision: '1'
    apiVersionSetId: versionSet.id
    apiVersion: apiVersion
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    protocols: [
      'https'
    ]
    authenticationSettings:{
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
  }
}

resource productApiLink 'Microsoft.ApiManagement/service/products/apiLinks@2023-05-01-preview' = {
  name: '${productDisplayName}-${apiDisplayName}-Link'
  parent: apimProduct
  properties: {
    apiId: api.id
  }
}

resource cappApiPolicies 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' = if (deployPolicy) {
  name: 'policy'
  parent: api
  properties: {
    value: '<!--\r\n    - Policies are applied in the order they appear.\r\n    - Position <base/> inside a section to inherit policies from the outer scope.\r\n    - Comments within policies are not preserved.\r\n-->\r\n<!-- Add policies as children to the <inbound>, <outbound>, <backend>, and <on-error> elements -->\r\n<policies>\r\n    <!-- Throttle, authorize, validate, cache, or transform the requests -->\r\n    <inbound>\r\n        <base />\r\n        <cors allow-credentials="true" terminate-unmatched-request="true">\r\n            <allowed-origins>\r\n                <origin>${cappOriginUrl}</origin>\r\n            </allowed-origins>\r\n            <allowed-methods>\r\n                <method>GET</method>\r\n                <method>POST</method>\r\n            </allowed-methods>\r\n            <allowed-headers>\r\n                <header>*</header>\r\n            </allowed-headers>\r\n        </cors>\r\n        <rate-limit calls="20" renewal-period="60" />\r\n    </inbound>\r\n    <!-- Control if and how the requests are forwarded to services  -->\r\n    <backend>\r\n        <base />\r\n    </backend>\r\n    <!-- Customize the responses -->\r\n    <outbound>\r\n        <base />\r\n    </outbound>\r\n    <!-- Handle exceptions and customize error responses  -->\r\n    <on-error>\r\n        <base />\r\n	</on-error>\r\n</policies>\r\n'
    format: 'xml'
  }
}

//output nameWithVersion string = nameWithVersion
output name string = api.name
output id string = api.id

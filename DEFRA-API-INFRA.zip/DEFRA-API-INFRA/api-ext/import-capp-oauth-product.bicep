param apimServiceName string

// API name needs to unique in APIM
param apiName string 


param productDescription string
param productDisplayName string
param productName string 
param environment string

var devSnippet = loadTextContent('policy-snippets/capp-auth-product-dev.txt')
var tstSnippet = loadTextContent('policy-snippets/capp-auth-product-tst.txt')
var preSnippet = loadTextContent('policy-snippets/capp-auth-product-pre.txt')
var prdSnippet = loadTextContent('policy-snippets/capp-auth-product-prd.txt')


var finalSnippet = environment == 'DEV' ? devSnippet
  : environment == 'TST' ? tstSnippet
  : environment == 'PRE' ? preSnippet
  : environment == 'PRD' ? prdSnippet
  : 'unknown'

// Existing APIM service
resource apimService 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimServiceName
}

resource apimProduct 'Microsoft.ApiManagement/service/products@2023-03-01-preview' = {
  parent: apimService
  name: productName
  properties: {
    description: productDescription
    displayName: productDisplayName
    subscriptionRequired: false
    state: 'notPublished'
  }
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' existing = {
  parent: apimService
  name: apiName
}

resource productApi 'Microsoft.ApiManagement/service/products/apis@2023-05-01-preview' = {
  name: '${apimServiceName}/${productName}/${apiName}'
  dependsOn:[
    apimProduct
    apimService
    api
  ]
}


// AL API Policies
resource productPolicyOAuth 'Microsoft.ApiManagement/service/products/policies@2022-08-01' = {
  name: 'policy'
  parent: apimProduct
  properties: {
    value: finalSnippet
    format: 'xml'
  }
  dependsOn: [
    productApi
  ]
}

//output nameWithVersion string = nameWithVersion
output name string = api.name
output id string = api.id

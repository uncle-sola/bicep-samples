
param bngServiceURL string
param boomicertificateName string
param apimName string
param deploy bool
// param elClientAppIdV1Ext string
// param elIssuerV1Ext string
// param elBackEndAppIdV1Ext string 
// param eLabExchangeV1snippet string
param openApiSpec string

// API name needs to unique in APIM
// There can be only one api without path

// API Display Name
param apiDisplayName string

param productDescription string
param productDisplayName string
param productName string 

param bngClientAppIdV20Int string
param bngIssuerV20Int string 
param bngBackEndAppIdV20Int string
param bngv1Snippet string
param bngv2Snippet string
param bngCodeParameterInt string

var finalv1Snippet = replace(bngv1Snippet, '{{bngCodeParameterInt}}', bngCodeParameterInt)

var snippet1 = replace(bngv2Snippet, '{{boomicertificateName}}', boomicertificateName)
var snippet2 = replace(snippet1, '{{bngBackEndAppIdV20Int}}', bngBackEndAppIdV20Int)
var snippet3 = replace(snippet2, '{{bngIssuerV20Int}}', bngIssuerV20Int)
var snippet4 = replace(snippet3, '{{bngClientAppIdV20Int}}', bngClientAppIdV20Int)
var finalv2Snippet = replace(snippet4, '{{bngCodeParameterInt}}', bngCodeParameterInt)



// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}

resource boomiCertificate 'Microsoft.ApiManagement/service/certificates@2023-05-01-preview' existing = {
  parent: apim
  name: boomicertificateName
}

//Address Lookup API - Starts 

resource bngVersionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = if (deploy){
  name: 'bngVersionSet'
  parent: apim
  properties: {
    displayName: 'BNG-API'
    versioningScheme: 'Segment'
  }
}


resource apimProduct 'Microsoft.ApiManagement/service/products@2023-03-01-preview' = {
  parent: apim
  name: productName
  properties: {
    description: productDescription
    displayName: productDisplayName
    subscriptionRequired: true
    approvalRequired: false
    state: 'published'
  }
}

resource bngApiV1 'Microsoft.ApiManagement/service/apis@2022-08-01' = {
  parent: apim
  name: 'bng-api-v1'
  properties: {
    format: 'openapi'
    apiType: 'http'
    serviceUrl: bngServiceURL
    value: openApiSpec
    path: 'api/bng-api'
    displayName: 'BNG-API V1.0'
    apiRevision: '1'
    apiVersionSetId: bngVersionSet.id
    apiVersion: 'v1.0'
    subscriptionRequired: false
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    protocols: [
      'https'
    ]
    authenticationSettings:{
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
  }
}

resource productApiLink 'Microsoft.ApiManagement/service/products/apiLinks@2023-05-01-preview' = {
  name: '${productDisplayName}-${apiDisplayName}-v1-Link'
  parent: apimProduct
  properties: {
    apiId: bngApiV1.id
  }
}

resource bngApiPoliciesV1 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' =  {
  name: 'policy'
  parent: bngApiV1
  properties: {
    value: finalv1Snippet
    format: 'xml'
  }
  dependsOn:[
    boomiCertificate
  ]
}

resource bngApiV2 'Microsoft.ApiManagement/service/apis@2022-08-01' = {
  parent: apim
  name: 'bng-api-v2'
  properties: {
    format: 'openapi'
    apiType: 'http'
    serviceUrl: bngServiceURL
    value: openApiSpec
    path: 'api/bng-api'
    displayName: 'BNG-API V2.0'
    apiRevision: '1'
    apiVersionSetId: bngVersionSet.id
    apiVersion: 'v2.0'
    subscriptionRequired: false
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    protocols: [
      'https'
    ]
    authenticationSettings:{
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
  }
}

resource productApiLinkV2 'Microsoft.ApiManagement/service/products/apiLinks@2023-05-01-preview' = {
  name: '${productDisplayName}-${apiDisplayName}-v2-Link'
  parent: apimProduct
  properties: {
    apiId: bngApiV2.id
  }
}

resource bngApiPoliciesV2 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' =  {
  name: 'policy'
  parent: bngApiV2
  properties: {
    value: finalv2Snippet
    format: 'xml'
  }
  dependsOn:[
    boomiCertificate
  ]
}

//output nameWithVersion string = nameWithVersion
output namev1 string = bngApiV1.name
output idv1 string = bngApiV1.id

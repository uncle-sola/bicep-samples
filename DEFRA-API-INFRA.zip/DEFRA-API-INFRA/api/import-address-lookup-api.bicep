
param aLServiceURL string
param boomicertificateName string
param apimName string
param deploy bool





// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}

resource boomiCertificate 'Microsoft.ApiManagement/service/certificates@2023-05-01-preview' existing = {
  parent: apim
  name: boomicertificateName
}

//Address Lookup API - Starts 

resource addressLookUpVersionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = if (deploy){
  name: 'addressLookupVersionset'
  parent: apim
  properties: {
    displayName: 'Address Lookup'
    versioningScheme: 'Segment'
  }
}

//API Lookup API V2 - Starts
resource aLApi 'Microsoft.ApiManagement/service/apis@2022-08-01' = if (deploy) {
  parent: apim
  name: 'address-lookup-v12'
  properties: {
    description: 'The DEFRA Address Lookup REST API provides a method to search for a list of addresses  by Postal Code or UPRN (Unique Property Reference Number)'
    type: 'http'
    subscriptionRequired: true
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    isCurrent: true
    license: {
      name: 'DEFRA API License Agreement'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs/license/url'
    }
    contact: {
      email: 'defra.helpline@defra.gsi.gov.uk'
      name: 'Department for Environment, Food and Rural Affairs - GOV UK'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs'
    }
    displayName: 'Address Lookup'
    serviceUrl: aLServiceURL
    path: 'api/address-lookup'
    protocols: [
      'https'
    ]
    authenticationSettings: {
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
    apiRevision: '1'
    apiVersion: 'v2.0'
    apiVersionSetId: addressLookUpVersionSet.id
  }
}
//Operation
resource aLApiOperationAddress 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: aLApi
  name: 'get-postcodes-postcode'
  properties: {
    description: 'Search the Address service for Postal codes or URPN'
    displayName: 'Address search by Postcode or UPRN'
    method: 'GET'
    urlTemplate: '/addresses'
    request: {
      description: 'Search the Address service for Postal codes or URPN'
      queryParameters: [
        {
          description: 'The PostCode to be used in lookup'
          name: 'postcode'
          type: 'string'
        }
        {
          description: 'The UPRN to be used in lookup'
          name: 'uprn'
          type: 'string'
        }
        {
          description: 'The maxresults parameter defines how many results will be returned (limit is 100). When searching by UPRN this parameter will be ignored. Default setting is 100.'
          name: 'maxresults'
          type: 'integer'
        }
        {
          description: 'If results set is greater than the maxresults this parameter can be used to offset the results so that the result sets can be concatenated.'
          name: 'offset'
          type: 'integer'
        }
        {
          description: 'Language paramter is used to indecate which language is required. Valid languages are English (EN) and Welsh (CY). This filter is only applicable to DPA dataset'
          name: 'language'
          type: 'string'
        }
        {
          description: 'Specifies which dataset is required, Delivery Point Addresses (DPA) or Local Property Identifier (LPI).'
          name: 'dataset'
          type: 'string'
        }
      ]
    }
    responses: [
      {
        statusCode: 202
        description: 'Success'
        // Need to include Sample Output
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}
//Tags
resource aLAPIoperationAddressTagv2 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'AddressLookup'
  parent: aLApiOperationAddress
}

resource aLAPIAddressTagv2 'Microsoft.ApiManagement/service/tags@2023-03-01-preview' = if (deploy) {
  name: 'AddressLookup'
  parent: apim
  properties: {
    displayName: 'Address Lookup'
  }
}

// AL API Policies
resource aLApiPolicies 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' = if (deploy) {
  name: 'policy'
  parent: aLApi
  properties: {
    value: '<policies>\r\n  <inbound>\r\n    <base />\r\n  <rate-limit calls="300" renewal-period="60" />\r\n   <authentication-certificate certificate-id="${boomicertificateName}" /> </inbound>\r\n  <backend>\r\n    <base />\r\n  </backend>\r\n  <outbound>\r\n    <base />\r\n  </outbound>\r\n  <on-error>\r\n    <base />\r\n  </on-error>\r\n</policies>'
    format: 'xml'
  }
  dependsOn: [
    boomiCertificate
  ]
}
//Address Lookup API V2 - Ends




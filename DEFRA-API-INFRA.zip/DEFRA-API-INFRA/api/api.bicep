param apimName string

param aLServiceURL string
param aLServiceURLIntV1 string
param boomicertificateName string
param cHserviceurlv2 string
param cHserviceurlv21 string

param rspApiUrl string
param rspOatApiUrl string

param deployAll string
param deployOAT string
param rspFormat string


param cappApiUrl string
param cappOatApiUrl string
param cappFormat string

param chServiceurlv22 string


param bngServiceurlv10 string
param bngIssuerV20Int string
param bngBackEndAppIdV20Int string
param bngClientAppIdV20Int string
param bngCodeParameterInt string
param environment string



var deploy = (deployAll == 'true')
var deployOATAPI = (deployOAT == 'true' && deployAll == 'true')
var bngAPIContent = loadTextContent('yaml-snippets/bngOpenApi.yaml')
var bngv1Snippet = loadTextContent('policy-snippets/bngV1PolicySnippet.txt')
var bngv2Snippet = loadTextContent('policy-snippets/bngV2PolicySnippet.txt')

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}


// module importCompaniesHouse 'import-companies-house-api-v22.bicep' = {
//   name: 'importCompaniesHouse'
//   params:{
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//     environment: environment
//     chServiceurlv22: chServiceurlv22
//   }
//   dependsOn: [
//     apim
//   ]
// }

// module importCompaniesHouse 'import-companies-house-api.bicep' = {
//   name: 'importCompaniesHouse'
//   params:{
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//     cHserviceurlv2: cHserviceurlv2
//     cHserviceurlv21: cHserviceurlv21
//     chLookup22snippet: chV22ContentInt
//     chBackEndAppIdV22: chBackEndAppIdV22
//     chClientAppIdV22: chClientAppIdV22
//     chIssuerV22: chIssuerV22
//     chServiceurlv22: chServiceurlv22
//   }
//   dependsOn: [
//     apim
//   ]
// }

// module importAddressLookupV1 'import-address-lookup-api-v1.bicep' = {
//   name: 'importAddressLookupV1'
//   params:{
//     aLServiceURL: aLServiceURLIntV1
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//     environment: environment
//   }
//   dependsOn: [
//     apim
//   ]
// }

// module importAddressLookupV21 'import-address-lookup-api-v21.bicep' = {
//   name: 'importAddressLookupV21'
//   params:{
//     aLServiceURL: aLServiceURL
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//     environment: environment
//   }
//   dependsOn: [
//     apim
//   ]
// }

// module importAddressLookup 'import-address-lookup-api.bicep' = {
//   name: 'importAddressLookup'
//   params:{
//     aLServiceURL: aLServiceURL
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//   }
//   dependsOn: [
//     apim
//   ]
// }

// module importRSPAPI 'import-api.bicep' = {
//   name: 'importRSPModule'
//   params: {
//     apimServiceName: apimName
//     apiName: 'rsp-api'
//     apiUrl: rspApiUrl
//     apiPath: 'rsp'
//     apiDisplayName: 'RSP'
//     apiVersion: 'v1'
//     productDescription: 'RSP API Product'
//     productDisplayName: 'RSP API'
//     productName: 'RSPAPI'
//     format: rspFormat
//   }
//   dependsOn: [
//     apim
//   ]
// }



// module importRSPOATAPI 'import-api.bicep' = if (deployOATAPI) {
//   name: 'importRSPOATModule'
//   params: {
//     apimServiceName: apimName
//     apiName: 'rsp-oat-api'
//     apiUrl: rspOatApiUrl
//     apiPath: 'rsp-oat'
//     apiDisplayName: 'RSP OAT'
//     apiVersion: 'v1'
//     productDescription: 'RSP OAT API Product'
//     productDisplayName: 'RSP OAT API'
//     productName: 'RSPOATAPI'
//     format: rspFormat
//   }
//   dependsOn: [
//     apim
//   ]
// }


// module importCAPPAPI 'import-api.bicep' = {
//   name: 'importCAPPModule'
//   params: {
//     apimServiceName: apimName
//     apiName: 'capp'
//     apiUrl: cappApiUrl
//     apiPath: 'capp'
//     apiDisplayName: 'CAPP'
//     apiVersion: 'v1'
//     productDescription: 'CAPP Charge Calculation'
//     productDisplayName: 'CAPP'
//     productName: 'CAPP'
//     format: cappFormat
//   }
//   dependsOn: [
//     apim
//   ]
// }
// module importCAPPOATAPI 'import-api.bicep' = if (deployOATAPI) {
//   name: 'importCAPPOATModule'
//   params: {
//     apimServiceName: apimName
//     apiName: 'capp-oat'
//     apiUrl: cappOatApiUrl
//     apiPath: 'capp-oat'
//     apiDisplayName: 'CAPP OAT'
//     apiVersion: 'v1'
//     productDescription: 'CAPP OAT Charge Calculation'
//     productDisplayName: 'CAPP OAT'
//     productName: 'CAPPOAT'
//   }
//   dependsOn: [
//     apim
//   ]
// }

module importRSPOAuthProduct 'import-rsp-oauth-product.bicep' = {
  name: 'importRSPOAuthModule'
  params: {
    environment: environment
    apimServiceName: apimName
    apiName: 'rsp-api'
    productDescription: 'Product created for OAuth version of RSP API'
    productDisplayName: 'RSP OAuth Product'
    productName: 'rsp-oauth-product'
  }
  dependsOn: [
    apim
  ]
}

module importCAPPOAuthProduct 'import-capp-oauth-product.bicep' = {
  name: 'importCAPPOAuthModule'
  params: {
    environment: environment
    apimServiceName: apimName
    apiName: 'capp'
    productDescription: 'OAuth Product for CAPP API'
    productDisplayName: 'CAPP OAUTH'
    productName: 'capp-oauth'
  }
  dependsOn: [
    apim
  ]
}

// module importBNGAPI 'import-bng-api.bicep' = {
//   name: 'importBNGAPI'
//   params:{
//     bngServiceURL: bngServiceurlv10
//     boomicertificateName: boomicertificateName
//     apimName: apimName
//     deploy: deploy
//     bngClientAppIdV20Int: bngClientAppIdV20Int
//     bngIssuerV20Int: bngIssuerV20Int 
//     bngBackEndAppIdV20Int: bngBackEndAppIdV20Int
//     bngv1Snippet: bngv1Snippet
//     bngv2Snippet: bngv2Snippet
//     apiDisplayName: 'BNG-API'
//     productDescription: 'BNG Product'
//     productDisplayName: 'BNG'
//     productName: 'BNG'
//     openApiSpec: bngAPIContent
//     bngCodeParameterInt: bngCodeParameterInt
//   }
//   dependsOn: [
//     apim
//   ]
// }

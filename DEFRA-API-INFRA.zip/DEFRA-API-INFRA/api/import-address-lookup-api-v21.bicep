
param aLServiceURL string
param boomicertificateName string
param apimName string
param deploy bool
param environment string


var devSnippet = loadTextContent('policy-snippets/addresslookupv21-dev.txt')
var tstSnippet = loadTextContent('policy-snippets/addresslookupv21-tst.txt')
var preSnippet = loadTextContent('policy-snippets/addresslookupv21-pre.txt')
var prdSnippet = loadTextContent('policy-snippets/addresslookupv21-prd.txt')


var finalSnippet = environment == 'DEV' ? devSnippet
  : environment == 'TST' ? tstSnippet
  : environment == 'PRE' ? preSnippet
  : environment == 'PRD' ? prdSnippet
  : 'unknown'

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}

resource boomiCertificate 'Microsoft.ApiManagement/service/certificates@2023-05-01-preview' existing = {
  parent: apim
  name: boomicertificateName
}

//Address Lookup API - Starts 

resource addressLookUpVersionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = if (deploy){
  name: 'addressLookupVersionset'
  parent: apim
  properties: {
    displayName: 'Address Lookup'
    versioningScheme: 'Segment'
  }
}

//API Lookup API VOauth - Starts
resource aLApiAuth 'Microsoft.ApiManagement/service/apis@2022-08-01' = if (deploy) {
  parent: apim
  name: 'address-lookup-v21'
  properties: {
    description: 'The DEFRA Address Lookup REST API provides a method to search for a list of addresses  by Postal Code or UPRN (Unique Property Reference Number)'
    type: 'http'
    subscriptionRequired: false
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    isCurrent: true
    license: {
      name: 'DEFRA API License Agreement'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs/license/url'
    }
    contact: {
      email: 'defra.helpline@defra.gsi.gov.uk'
      name: 'Department for Environment, Food and Rural Affairs - GOV UK'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs'
    }
    displayName: 'Address Lookup'
    serviceUrl: aLServiceURL
    path: 'api/address-lookup'
    protocols: [
      'https'
    ]
    authenticationSettings: {
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
    apiRevision: '1'
    apiVersion: 'v2.1'
    apiVersionSetId: addressLookUpVersionSet.id
  }
}
//Operation
resource aLApiOperationAddressOAuth 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: aLApiAuth
  name: 'get-postcodes-postcode'
  properties: {
    description: 'Search the Address service for Postal codes or URPN'
    displayName: 'Address search by Postcode or UPRN'
    method: 'GET'
    urlTemplate: '/addresses'
    request: {
      description: 'Search the Address service for Postal codes or URPN'
      queryParameters: [
        {
          description: 'The PostCode to be used in lookup'
          name: 'postcode'
          type: 'string'
        }
        {
          description: 'The UPRN to be used in lookup'
          name: 'uprn'
          type: 'string'
        }
        {
          description: 'The maxresults parameter defines how many results will be returned (limit is 100). When searching by UPRN this parameter will be ignored. Default setting is 100.'
          name: 'maxresults'
          type: 'integer'
        }
        {
          description: 'If results set is greater than the maxresults this parameter can be used to offset the results so that the result sets can be concatenated.'
          name: 'offset'
          type: 'integer'
        }
        {
          description: 'Language paramter is used to indecate which language is required. Valid languages are English (EN) and Welsh (CY). This filter is only applicable to DPA dataset'
          name: 'language'
          type: 'string'
        }
        {
          description: 'Specifies which dataset is required, Delivery Point Addresses (DPA) or Local Property Identifier (LPI).'
          name: 'dataset'
          type: 'string'
        }
      ]
    }
    responses: [
      {
        statusCode: 202
        description: 'Success'
        // Need to include Sample Output
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}
//Tags
resource aLAPIoperationAddressTagOAuth 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'AddressLookupVOAuth'
  parent: aLApiOperationAddressOAuth
}

resource aLAPIAddressTagOAuth 'Microsoft.ApiManagement/service/tags@2023-03-01-preview' = if (deploy) {
  name: 'AddressLookupVOAuth'
  parent: apim
  properties: {
    displayName: 'Address Lookup OAuth'
  }
}

// AL API Policies
resource aLApiPoliciesOAuth 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' = if (deploy) {
  name: 'policy'
  parent: aLApiAuth
  properties: {
   // value: '<policies>\r\n  <inbound>\r\n    <base />\r\n        <validate-azure-ad-token tenant-id="${tenant().tenantId}">\r\n            <audiences>\r\n                <audience>api://${alBackEndAppId}</audience>\r\n            </audiences>\r\n            <client-application-ids>\r\n                <application-id>${alClientAppId}</application-id>\r\n            </client-application-ids>\r\n        </validate-azure-ad-token>\r\n        <set-header name="Authorization" exists-action="delete" /><authentication-certificate certificate-id="${boomicertificateName}" /> </inbound>\r\n  <backend>\r\n    <base />\r\n  </backend>\r\n  <outbound>\r\n    <base />\r\n  </outbound>\r\n  <on-error>\r\n    <base />\r\n  </on-error>\r\n</policies>'
    value: finalSnippet
    format: 'xml'
  }
  dependsOn: [
    boomiCertificate
  ]
}
//Address Lookup API V2.1 - Ends

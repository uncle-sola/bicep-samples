
param boomicertificateName string
param apimName string
param deploy bool
param cHserviceurlv2 string
param cHserviceurlv21 string
param chBackEndAppIdV22 string
param chClientAppIdV22 string
param chIssuerV22 string
param chLookup22snippet string
param chServiceurlv22 string


var snippet1 = replace(chLookup22snippet, '{{boomicertificateName}}', boomicertificateName)
var snippet2 = replace(snippet1, '{{chBackEndAppIdV22Int}}', chBackEndAppIdV22)
var snippet3 = replace(snippet2, '{{chClientAppIdV22Int}}', chClientAppIdV22)
var snippet4 = replace(snippet3, '{{chIssuerV22Int}}', chIssuerV22)

// Existing APIM service
resource apim 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimName
}

resource boomiCertificate 'Microsoft.ApiManagement/service/certificates@2023-05-01-preview' existing = {
  parent: apim
  name: boomicertificateName
}



//COMPANIES HOUSE V2 - STARTS

resource companiesHouseVersionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = if (deploy) {
  name: 'companiesHouseVersionSet'
  parent: apim
  properties: {
    displayName: 'Companies House'
    versioningScheme: 'Segment'
  }
}

//API
resource cHAPIv2 'Microsoft.ApiManagement/service/apis@2022-08-01' = if (deploy) {
  parent: apim
  name: 'companies-house-v2'
  properties: {
    description: 'DEFRA Companies House Lookup REST API provides a method to retrieve details about a company and its officers by using the company registration id.'
    type: 'http'
    subscriptionRequired: true
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    isCurrent: true
    license: {
      name: 'DEFRA API License Agreement'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs/license/url'
    }
    contact: {
      email: 'defra.helpline@defra.gsi.gov.uk'
      name: 'Department for Environment, Food and Rural Affairs - GOV UK'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs'
    }
    displayName: 'Companies House'
    serviceUrl: cHserviceurlv2
    path: 'api/companies-house'
    protocols: [
      'https'
    ]
    authenticationSettings: {
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
    apiVersion: 'v2'
    apiRevision: '1'
    apiVersionSetId: companiesHouseVersionSet.id
  }
}

// //OPERATION 1
resource chapioperationappointmentv2 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: cHAPIv2
  name: 'get-officers-officerid-appointments'
  properties: {
    description: 'Returns a list of companies where an officer holds or has held a position.'
    displayName: 'Get a list of all the appointments of an officer using an officer id'
    method: 'GET'
    urlTemplate: '/officers/{officerId}/appointments'
    templateParameters: [
      {
        description: 'Officer Id'
        name: 'officerId'
        type: 'string'
        required: true
        values: []
      }
    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

//Tags
resource chAPIoperationappointmentTagv2 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Officer-Appointments'
  parent: chapioperationappointmentv2
}

resource chAPIappointmentTagv2 'Microsoft.ApiManagement/service/tags@2023-03-01-preview' = if (deploy) {
  name: 'Officer-Appointments'
  parent: apim
  properties: {
    displayName: 'Officer Appointments'
  }
}

// //OPERATION 2
resource chAPIoperationcompanyv2 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: cHAPIv2
  name: 'get-companies-companyid'
  properties: {
    description: 'Provides a single page document containing company details. To return all the officer details use /officer instead.'
    displayName: 'Get company details using the company id'
    method: 'GET'
    urlTemplate: '/companies/{companyId}'
    templateParameters: [
      {
        description: 'Company Id'
        name: 'companyId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

// //OPERATION 2 - TAG 
resource chAPIoperationcompanyTagv2 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Company-Details'
  parent: chAPIoperationcompanyv2
}

resource chAPITagv2 'Microsoft.ApiManagement/service/tags@2023-03-01-preview' = if (deploy) {
  name: 'Company-Details'
  parent: apim
  properties: {
    displayName: 'Company Details'
  }
}

// //OPERATION 3
resource chAPIoperationofficerv2 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: cHAPIv2
  name: 'get-companies-and-officers-companyid'
  properties: {
    description: 'Provides a signle page document containing company and officer details. To return just the company details remove /officer.'
    displayName: 'Get company and officer details using the company id'
    method: 'GET'
    urlTemplate: '/companies/{companyId}/officers'
    templateParameters: [
      {
        description: 'Company Id'
        name: 'companyId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}
// //OPERATION 3 - TAG 

resource chAPIoperationofficerTagv2 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Company-Details'
  parent: chAPIoperationofficerv2
}

// //CH API Policies V2
resource cHApiPoliciesv2 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' = if (deploy) {
  name: 'policy'
  parent: cHAPIv2
  properties: {
    value: '<policies>\r\n  <inbound>\r\n    <base />\r\n  <authentication-certificate certificate-id="${boomicertificateName}" /> </inbound>\r\n  <backend>\r\n    <base />\r\n  </backend>\r\n  <outbound>\r\n    <base />\r\n  </outbound>\r\n  <on-error>\r\n    <base />\r\n  </on-error>\r\n</policies>'
    format: 'xml'
  }
  dependsOn: [
    boomiCertificate
  ]
}
// //COMPANIES HOUSE V2 - ENDS 

// //COMPANIES HOUSE V2.1 - STARTS
// //API
resource cHAPIv21 'Microsoft.ApiManagement/service/apis@2022-08-01' = if (deploy) {
  parent: apim
  name: 'companies-house-v21'
  properties: {
    description: 'DEFRA Companies House Lookup REST API provides a method to retrieve details about a company and its officers by using the company registration id.'
    type: 'http'
    subscriptionRequired: true
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    isCurrent: true
    license: {
      name: 'DEFRA API License Agreement'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs/license/url'
    }
    contact: {
      email: 'defra.helpline@defra.gsi.gov.uk'
      name: 'Department for Environment, Food and Rural Affairs - GOV UK'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs'
    }
    displayName: 'Companies House'
    serviceUrl: cHserviceurlv21
    path: 'api/companies-house'
    protocols: [
      'https'
    ]
    authenticationSettings: {
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
    apiVersionSetId: companiesHouseVersionSet.id
    apiVersion: 'v2.1'
    apiRevision: '1'
  }
}

// //OPERATION 1
resource chapioperationappointmentv21 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' =if (deploy) {
  parent: cHAPIv21
  name: 'get-officers-officerid-appointments'
  properties: {
    description: 'Returns a list of companies where an officer holds or has held a position.'
    displayName: 'Get a list of all the appointments of an officer using an officer id'
    method: 'GET'
    urlTemplate: '/officers/{officerId}/appointments'
    templateParameters: [
      {
        description: 'Officer Id'
        name: 'officerId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

// OPERATION 1 TAG 
resource chAPIoperationappointmentTagv21 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Officer-Appointments'
  parent: chapioperationappointmentv21
}

// //OPERATION 2
resource chAPIoperationcompanyv21 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: cHAPIv21
  name: 'get-companies-companyid'
  properties: {
    description: 'Provides a single page document containing company details. To return all the officer details use /officer instead.'
    displayName: 'Get company details using the company id'
    method: 'GET'
    urlTemplate: '/companies/{companyId}'
    templateParameters: [
      {
        description: 'Company Id'
        name: 'companyId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

// //OPERATION 2 - TAG 
resource chAPIoperationcompanyTagv21 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Company-Details'
  parent: chAPIoperationcompanyv21
}

// //OPERATION 3
resource chAPIoperationofficerv21 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: cHAPIv21
  name: 'get-companies-and-officers-companyid'
  properties: {
    description: 'Provides a signle page document containing company and officer details. To return just the company details remove /officer.'
    displayName: 'Get company and officer details using the company id'
    method: 'GET'
    urlTemplate: '/companies/{companyId}/officers'
    templateParameters: [
      {
        description: 'Company Id'
        name: 'companyId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

//OPERATION 3 - TAG 
resource chAPIoperationofficerTagv21 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Company-Details'
  parent: chAPIoperationofficerv21
}

//CH API Policies V2.1
resource cHApiPoliciesv21 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' = if (deploy) {
  name: 'policy'
  parent: cHAPIv21
  properties: {
    value: '<policies>\r\n  <inbound>\r\n    <base />\r\n  <authentication-certificate certificate-id="${boomicertificateName}" /> </inbound>\r\n  <backend>\r\n    <base />\r\n  </backend>\r\n  <outbound>\r\n    <base />\r\n  </outbound>\r\n  <on-error>\r\n    <base />\r\n  </on-error>\r\n</policies>'
    format: 'xml'
  }
  dependsOn: [
    boomiCertificate
  ]
}

// //COMPANIES HOUSE V2.1 - ENDS 



// //COMPANIES HOUSE V2.2 - STARTS
// //API
resource cHAPIv22 'Microsoft.ApiManagement/service/apis@2022-08-01' = if (deploy) {
  parent: apim
  name: 'companies-house-v22'
  properties: {
    description: 'DEFRA Companies House Lookup REST API provides a method to retrieve details about a company and its officers by using the company registration id.'
    type: 'http'
    subscriptionRequired: false
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    isCurrent: true
    license: {
      name: 'DEFRA API License Agreement'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs/license/url'
    }
    contact: {
      email: 'defra.helpline@defra.gsi.gov.uk'
      name: 'Department for Environment, Food and Rural Affairs - GOV UK'
      url: 'https://www.gov.uk/government/organisations/department-for-environment-food-rural-affairs'
    }
    displayName: 'Companies House'
    serviceUrl: chServiceurlv22
    path: 'api/companies-house'
    protocols: [
      'https'
    ]
    authenticationSettings: {
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
    apiVersionSetId: companiesHouseVersionSet.id
    apiVersion: 'v2.2'
    apiRevision: '1'
  }
}

// //OPERATION 1
resource chapioperationappointmentv22 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' =if (deploy) {
  parent: cHAPIv22
  name: 'get-officers-officerid-appointments'
  properties: {
    description: 'Returns a list of companies where an officer holds or has held a position.'
    displayName: 'Get a list of all the appointments of an officer using an officer id'
    method: 'GET'
    urlTemplate: '/officers/{officerId}/appointments'
    templateParameters: [
      {
        description: 'Officer Id'
        name: 'officerId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

// OPERATION 1 TAG 
resource chAPIoperationappointmentTagv22 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Officer-Appointments'
  parent: chapioperationappointmentv22
}

// //OPERATION 2
resource chAPIoperationcompanyv22 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: cHAPIv22
  name: 'get-companies-companyid'
  properties: {
    description: 'Provides a single page document containing company details. To return all the officer details use /officer instead.'
    displayName: 'Get company details using the company id'
    method: 'GET'
    urlTemplate: '/companies/{companyId}'
    templateParameters: [
      {
        description: 'Company Id'
        name: 'companyId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

// //OPERATION 2 - TAG 
resource chAPIoperationcompanyTagv22 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Company-Details'
  parent: chAPIoperationcompanyv22
}

// //OPERATION 3
resource chAPIoperationofficerv22 'Microsoft.ApiManagement/service/apis/operations@2022-08-01' = if (deploy) {
  parent: cHAPIv22
  name: 'get-companies-and-officers-companyid'
  properties: {
    description: 'Provides a signle page document containing company and officer details. To return just the company details remove /officer.'
    displayName: 'Get company and officer details using the company id'
    method: 'GET'
    urlTemplate: '/companies/{companyId}/officers'
    templateParameters: [
      {
        description: 'Company Id'
        name: 'companyId'
        type: 'string'
        required: true
      }

    ]
    responses: [
      {
        statusCode: 202
        description: 'Success'
        representations: []
      }
      {
        statusCode: 400
        description: 'Bad Request - There are miscellaneous errors with the request, for example, mismatches between the request and what is allowed for the operation.'
      }
      {
        statusCode: 403
        description: 'Unauthorized or 403 Forbidden - Authentication errors.'
      }
      {
        statusCode: 404
        description: 'Not Found - Invalid URL path.'
      }
      {
        statusCode: 500
        description: 'Internal Server Error - This generic error message appears when an unexpected condition was encountered and a more specific message is not suitable.'
      }
      {
        statusCode: 503
        description: 'Service Unavailable - The caller has hit a throttle or the request was rejected because the service is starting or stopping.'
      }
    ]
  }
}

//OPERATION 3 - TAG 
resource chAPIoperationofficerTagv22 'Microsoft.ApiManagement/service/apis/operations/tags@2022-08-01' = if (deploy) {
  name: 'Company-Details'
  parent: chAPIoperationofficerv22
}

//CH API Policies V2.2
resource chApiPoliciesv22OAuth 'Microsoft.ApiManagement/service/apis/policies@2022-08-01' = if (deploy) {
  name: 'policy'
  parent: cHAPIv22
  properties: {
    value: snippet4
    format: 'xml'
  }
  dependsOn: [
    boomiCertificate
  ]
}

// //COMPANIES HOUSE V2.2 - ENDS 

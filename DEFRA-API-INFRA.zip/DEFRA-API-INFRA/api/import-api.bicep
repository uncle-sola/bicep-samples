param apimServiceName string

// API name needs to unique in APIM
param apiName string 

// This url needs to be reachable for APIM
param apiUrl string

// There can be only one api without path
param apiPath string = ''
param apiVersion string
// API Display Name
param apiDisplayName string

param productDescription string
param productDisplayName string
param productName string 
param format string = 'openapi-link'


// Existing APIM service
resource apimService 'Microsoft.ApiManagement/service@2021-01-01-preview' existing = {
  name: apimServiceName
}

resource versionSet 'Microsoft.ApiManagement/service/apiVersionSets@2023-03-01-preview' = {
  name: apiName
  parent: apimService
  properties: {
    displayName: apiDisplayName
    versioningScheme: 'Segment'
  }
}

resource apimProduct 'Microsoft.ApiManagement/service/products@2023-03-01-preview' = {
  parent: apimService
  name: productName
  properties: {
    description: productDescription
    displayName: productDisplayName
    subscriptionRequired: true
    approvalRequired: false
    state: 'published'
  }
}

resource api 'Microsoft.ApiManagement/service/apis@2022-08-01' = {
  parent: apimService
  name: apiName
  properties: {
    format: format
    apiType: 'http'
    value: apiUrl
    path: apiPath
    displayName: apiDisplayName
    apiRevision: '1'
    apiVersionSetId: versionSet.id
    apiVersion: apiVersion
    subscriptionKeyParameterNames: {
      header: 'Ocp-Apim-Subscription-Key'
      query: 'subscription-key'
    }
    protocols: [
      'https'
    ]
    authenticationSettings:{
      oAuth2AuthenticationSettings: []
      openidAuthenticationSettings: []
    }
  }
}

resource productApiLink 'Microsoft.ApiManagement/service/products/apiLinks@2023-05-01-preview' = {
  name: '${productDisplayName}-${apiDisplayName}-Link'
  parent: apimProduct
  properties: {
    apiId: api.id
  }
}


//output nameWithVersion string = nameWithVersion
output name string = api.name
output id string = api.id

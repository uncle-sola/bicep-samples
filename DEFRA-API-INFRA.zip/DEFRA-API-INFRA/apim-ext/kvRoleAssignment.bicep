param roleDefinitionId string
param principalId string
param principalType string
param keyvaultName string
param varUniqueKeyvaultUserRoleId string

resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: keyvaultName
}

resource uniqueKeyvaultUserGuid 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: keyVault
  name: varUniqueKeyvaultUserRoleId
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
    principalType: principalType
  }
}

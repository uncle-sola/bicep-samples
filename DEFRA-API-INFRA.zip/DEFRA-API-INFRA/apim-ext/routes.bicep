param routeTableName string
param apimPublicIp string

resource apimServiceTagRouting 'Microsoft.Network/routeTables/routes@2023-04-01' = {
  name: '${routeTableName}/APIMControlPlane'
  properties: {
    addressPrefix: 'ApiManagement'
    nextHopType: 'Internet'
  }
}

resource apimPublicIpRouting 'Microsoft.Network/routeTables/routes@2023-04-01' = {
  name: '${routeTableName}/APIMControlPlaneIp'
  properties: {
    addressPrefix: '${apimPublicIp}/32'
    nextHopType: 'Internet'
  }
}

resource apimDefaultIpRouting 'Microsoft.Network/routeTables/routes@2023-04-01' = {
  name: '${routeTableName}/Default'
  properties: {
    addressPrefix: '0.0.0.0/0'
    nextHopType: 'VirtualAppliance'
    nextHopIpAddress: '10.176.0.100'
  }
}

param appInsightsName string
param lawName string
param environment string
param createdDate string = utcNow('yyyy-MM-dd')
param customTags object
param serviceCodeName string
param ServiceNName string
param ServiceTypeName string
param location string = resourceGroup().location

var defaultTags = {
  ServiceCode: serviceCodeName
  ServiceName: ServiceNName
  ServiceType: ServiceTypeName
  CreatedDate: createdDate
  Environment: environment
  Tier: 'OTHER'
  Location: location
}

resource appInsightsName_resource 'Microsoft.Insights/components@2020-02-02' = {
  name: appInsightsName
  location: location
  tags: union(defaultTags, customTags)
  kind: 'web'
  properties: {
    Application_Type: 'web'
    Flow_Type: 'Bluefield'
    Request_Source: 'rest'
    WorkspaceResourceId: resourceId('Microsoft.OperationalInsights/workspaces', lawName)
  }
}

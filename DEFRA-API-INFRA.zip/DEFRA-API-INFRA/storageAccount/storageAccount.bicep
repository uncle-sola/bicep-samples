// General parameters
param name string
param publicNetworkAccess string
param storageAccountKind string = 'StorageV2'
param storageAccountSku string = 'Standard_LRS'
param tags object
param laWorkspaceName string
param createdDate string = utcNow('yyyy-MM-dd')
param rgLocation string = resourceGroup().location

// The following params are for the Private Endpoint
param vnetName string
param subnetName string
param vnetRg string

// Existing networking resources
resource vNet 'Microsoft.Network/virtualNetworks@2023-04-01' existing = {
  name: vnetName
  scope: resourceGroup(vnetRg)        // Required as vNet is in another RG
}

resource subNet 'Microsoft.Network/virtualNetworks/subnets@2023-04-01' existing = {
  name: subnetName
  parent: vNet
}

resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: laWorkspaceName
}

// Module definition
module storageaccount 'br/SharedDefraRegistry:storage.storage-account:0.5.3' = {
  name: name
  params: {
    name: name
    location: rgLocation
    publicNetworkAccess: publicNetworkAccess
    tags: union({Name: name}, {CreatedDate: createdDate}, {Location: rgLocation}, tags)
    kind: storageAccountKind
    skuName: storageAccountSku
    diagnosticWorkspaceId: laWorkspace.id
    diagnosticMetricsToEnable: [
      'Transaction'
    ]
    blobServices: {
      containerDeleteRetentionPolicyEnabled: true
      deleteRetentionPolicyEnabled: true
      containerDeleteRetentionPolicyDays: 7
      deleteRetentionPolicyDays: 7
      diagnosticWorkspaceId: laWorkspace.id
      diagnosticMetricsToEnable: [
        'Transaction'
      ]
      diagnosticLogCategoriesToEnable: [
        'allLogs'
      ]
      containers: [
      ]
    }
  }
}

// Private Endpoint definition
module privateEndpoint 'br/SharedDefraRegistry:network.private-endpoint:0.5.2' = {
  name: '${name}-PE'
  params: {
    name: '${name}-PE'
    location: rgLocation
    tags: union({Name: '${name}-PE'}, {CreatedDate: createdDate}, {Location: rgLocation}, tags)
    groupIds: ['blob']
    serviceResourceId: storageaccount.outputs.resourceId
    subnetResourceId: subNet.id
  }
}

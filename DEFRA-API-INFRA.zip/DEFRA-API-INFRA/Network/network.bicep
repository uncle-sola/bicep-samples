param vnetInfra object
param routeTable object
param nsgs array
param environment string
param createdDate string = utcNow('yyyy-MM-dd')
param rgLocation string = resourceGroup().location
param serviceCodeName string
param ServiceNName string
param ServiceTypeName string
module network '../../Defra.Infrastructure.Common/templates/Microsoft.Network/virtualNetworks.bicep' = {
  name: 'network-${createdDate}'
  params: {
    vnetInfra: vnetInfra
    routeTable: routeTable
    nsgs: nsgs
    location: rgLocation
    createDefaultRoute: false
    defaultTags: { ServiceCode: serviceCodeName, ServiceName: ServiceNName, ServiceType: ServiceTypeName, CreatedDate: createdDate, Environment: environment, Tier: 'NETWORK', Location: rgLocation }
  }
}

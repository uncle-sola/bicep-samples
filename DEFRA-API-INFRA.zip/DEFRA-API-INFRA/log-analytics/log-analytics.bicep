param lawName string
param customTags object
param environment string
param createdDate string = utcNow('yyyy-MM-dd')
param location string = resourceGroup().location
var defaultTags = {
  ServiceCode: 'API'
  ServiceName: 'API'
  ServiceType: 'LOB'
  CreatedDate: createdDate
  Environment: environment
  Tier: 'OTHER'
  Location: location
}

resource lawName_resource 'Microsoft.OperationalInsights/workspaces@2020-03-01-preview' = {
  name: lawName
  tags: union(defaultTags, customTags)
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 30
  }
}

param serviceCodeName string
param profileName string
param skuName string 
param location string

@description('The host name that should be used when connecting from Front Door to the origin.')
param originHostName string

param originHostHeader string
param originGroupName string
param originName string


resource profileResource 'Microsoft.Cdn/profiles@2022-11-01-preview' = {
  name: profileName
  location: location
  tags: {
    ServiceCode: serviceCodeName
  }
  sku: {
    name: skuName
  }
  kind: 'frontdoor'
  properties: {
    originResponseTimeoutSeconds: 30
    extendedProperties: {}
  }
}


resource originGroup 'Microsoft.Cdn/profiles/origingroups@2022-11-01-preview' = {
  parent: profileResource
  name: originGroupName
  properties: {
    loadBalancingSettings: {
      sampleSize: 4
      successfulSamplesRequired: 3
      additionalLatencyInMilliseconds: 50
    }
    healthProbeSettings: {
      probePath: '/status-0123456789abcdef'
      probeRequestType: 'GET'
      probeProtocol: 'Http'
      probeIntervalInSeconds: 30
    }
    sessionAffinityState: 'Disabled'
  }
}


resource origin 'Microsoft.Cdn/profiles/origingroups/origins@2022-11-01-preview' = {
  parent: originGroup
  name: originName
  properties: {
    hostName: originHostName
    httpPort: 80
    httpsPort: 443
    originHostHeader: originHostHeader
    priority: 1
    weight: 1000
    enabledState: 'Enabled'
    enforceCertificateNameCheck: true
  }
  dependsOn: [

    profileResource
  ]
}


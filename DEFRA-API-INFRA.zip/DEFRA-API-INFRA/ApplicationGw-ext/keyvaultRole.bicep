param wildcardCertKeyVault string
param principalId string

resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: wildcardCertKeyVault
}

resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' =  {
  name: guid(resourceGroup().id, '4633458b-17de-408a-b874-0445c86b69e6', principalId, resourceId('Microsoft.KeyVault/vaults', wildcardCertKeyVault))
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '4633458b-17de-408a-b874-0445c86b69e6')
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

param applicationGatewayName string
param tags object = {}
param appGatewayVirtualNetworkResourceGroupName string
param appGatewayVirtualNetworkName string
param subnet1 string
param publicIpName string
param publicIpAddressSku string = 'Standard'
param location string = resourceGroup().location
param backendEndpoint string
param appGatewaySku string = 'WAF_v2'
param minCapacity string
param maxCapacity string
param miName string
param starAzureDefraCloudSslCertKeyVaultUri string
param wafName string
param wildcardCertKeyVault string
param wildcardCertKeyVaultRG string
param laWorkspaceName string

resource lawName_resource 'Microsoft.OperationalInsights/workspaces@2020-03-01-preview' = {
  name: laWorkspaceName
  tags: tags
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 30
  }
}

// To get the resource ID for vnet which isn't deployed in the Bicep file
resource virtualNetwork 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  name: appGatewayVirtualNetworkName
  scope: resourceGroup(appGatewayVirtualNetworkResourceGroupName)
  resource subnet 'subnets@2021-03-01' existing = {
    name: subnet1
  }
}

module userAssignedManagedIdentity 'br/SharedDefraRegistry:managed-identity.user-assigned-identity:0.4.10' = {
  name: miName
  params: {
    name: miName
    location: location
    tags: union(tags, { Name: miName, Tier: 'IDENTITY' })
  }
}

module keyVaultRoleAssignment './keyvaultrole.bicep' = {
  name: 'keyVaultRole'
  scope: resourceGroup(wildcardCertKeyVaultRG)
  params: {
    principalId: userAssignedManagedIdentity.outputs.principalId
    wildcardCertKeyVault: wildcardCertKeyVault
  }
}

module publicIpAddress 'br/SharedDefraRegistry:network.public-ip-address:0.4.10' = {
  name: publicIpName
  params: {
    name: publicIpName
    skuName: publicIpAddressSku
    location: location
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    tags: union(tags, { Name: publicIpName, Tier: 'NETWORK' })
  }
}

module applicationGateway 'br/SharedDefraRegistry:network.application-gateway:0.5.3' = {
  name: applicationGatewayName
  dependsOn: [
    keyVaultRoleAssignment
  ]
  params: {
    name: applicationGatewayName
    location: location
    tags: union(tags, { Name: applicationGatewayName, Tier: 'NETWORK' })
    sku: appGatewaySku
    autoscaleMinCapacity: int(minCapacity)
    autoscaleMaxCapacity: int(maxCapacity)

    frontendIPConfigurations: [
      {
        name: 'public'
        properties: {
          publicIPAddress: {
            id: publicIpAddress.outputs.resourceId
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: 'port443'
        properties: {
          port: 443
        }
      }
    ]
    gatewayIPConfigurations: [
      {
        name: 'agw-ip-configuration'
        properties: {
          subnet: {
            id: virtualNetwork::subnet.id
          }
        }
      }
    ]
    firewallPolicyId: AgwWafPolicy.outputs.resourceId
    backendAddressPools: [
      {
        name: 'apim'
        properties: {
          backendAddresses: [
            {
              fqdn: backendEndpoint
            }
          ]
        }
      }
    ]

    backendHttpSettingsCollection: [
      {
        name: 'appServiceBackendHttpsSetting'
        properties: {
          cookieBasedAffinity: 'Disabled'
          pickHostNameFromBackendAddress: false
          port: 443
          protocol: 'Https'
          requestTimeout: 120
          probe: {
            id: '${resourceId('Microsoft.Network/applicationGateways',applicationGatewayName)}/probes/apimprobe'
          }
          hostName: backendEndpoint
        }
      }
    ]

    enableDefaultTelemetry: true
    enableHttp2: true

    httpListeners: [
      {
        name: 'public443'
        properties: {
          frontendIPConfiguration: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/frontendIPConfigurations',
              applicationGatewayName,
              'public'
            )
          }
          frontendPort: {
            id: resourceId('Microsoft.Network/applicationGateways/frontendPorts', applicationGatewayName, 'port443')
          }
          // hostNames: [
          //   frontendPublicEndpoint
          // ]
          protocol: 'https'
          requireServerNameIndication: false
          sslCertificate: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/sslCertificates',
              applicationGatewayName,
              'starAzureDefraCloudSslCert'
            )
          }
        }
      }
    ]
    requestRoutingRules: [
      {
        name: 'public443-appServiceBackendHttpsSetting-appServiceBackendHttpsSetting'
        properties: {
          priority: 10
          ruleType: 'Basic'
          backendAddressPool: {
            id: resourceId('Microsoft.Network/applicationGateways/backendAddressPools', applicationGatewayName, 'apim')
          }
          backendHttpSettings: {
            id: resourceId(
              'Microsoft.Network/applicationGateways/backendHttpSettingsCollection',
              applicationGatewayName,
              'appServiceBackendHttpsSetting'
            )
          }
          httpListener: {
            id: resourceId('Microsoft.Network/applicationGateways/httplisteners', applicationGatewayName, 'public443')
          }
        }
      }
    ]
    probes: [
      {
        name: 'apimprobe'
        properties: {
          protocol: 'Https'
          host: backendEndpoint
          path: '/status-0123456789abcdef'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          pickHostNameFromBackendHttpSettings: false
          minServers: 0
          match: {
            statusCodes: [
              '200-399'
            ]
          }
        }
      }
    ]
    sslCertificates: [
      {
        name: 'starAzureDefraCloudSslCert'
        properties: {
          keyVaultSecretId: starAzureDefraCloudSslCertKeyVaultUri
        }
      }
    ]
    userAssignedIdentities: {
      '${userAssignedManagedIdentity.outputs.resourceId}': {}
    }
    diagnosticSettingsName: '${applicationGatewayName}-diagnostics'
    diagnosticWorkspaceId: lawName_resource.id
    diagnosticLogCategoriesToEnable: [
      'ApplicationGatewayAccessLog'
      'ApplicationGatewayFirewallLog'
      'ApplicationGatewayPerformanceLog'
    ]
    diagnosticMetricsToEnable: [
      'AllMetrics'
    ]
  }
}

module AgwWafPolicy 'br/SharedDefraRegistry:network.application-gateway-web-application-firewall-policy:0.5.6' = {
  name: wafName
  params: {
    name: wafName
    location: location
    managedRules: {
      managedRuleSets: [
        {
          ruleSetType: 'OWASP'
          ruleSetVersion: '3.2'
          ruleGroupOverrides: [
            {
              ruleGroupName: 'REQUEST-942-APPLICATION-ATTACK-SQLI'
              rules: [
                {
                  ruleId: '942440'
                  state: 'Disabled'
                  action: 'Log'
                }
                {
                  ruleId: '942430'
                  state: 'Disabled'
                  action: 'Log'
                }
                {
                  ruleId: '942450'
                  action: 'Log'
                  state: 'Enabled'
                }
              ]
            }
          ]
        }
        {
          ruleSetType: 'Microsoft_BotManagerRuleSet'
          ruleSetVersion: '1.0'
        }
      ]
    }
    policySettings: {
      requestBodyCheck: true
      requestBodyEnforcement: true
      requestBodyInspectLimitInKB: 100
      maxRequestBodySizeInKb: 100
      fileUploadLimitInMb: 750
      fileUploadEnforcement: true
      state: 'Enabled'
      mode: 'Prevention'
    }
    tags: tags
  }
}

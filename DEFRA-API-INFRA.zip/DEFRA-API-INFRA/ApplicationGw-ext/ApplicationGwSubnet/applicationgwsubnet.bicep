param nsgResourceGroup string
param vnet string
param subnet1 string
param location string
param appGwNetworkSecurityGroupName string
param appGwSubnetAddressPrefix string
param routeTableAGW string


resource vnetApGW 'Microsoft.Network/virtualNetworks@2021-03-01' existing = {
  name: vnet
}

resource routeTable 'Microsoft.Network/routeTables@2022-07-01' existing = {
  name: routeTableAGW
}

resource networkSecurityGroup 'Microsoft.Network/networkSecurityGroups@2022-07-01' existing = {
  name: appGwNetworkSecurityGroupName
  scope: resourceGroup(nsgResourceGroup)
}

resource subnet 'Microsoft.Network/virtualNetworks/subnets@2021-03-01' = {
 parent: vnetApGW
 name: subnet1
 properties: {
   addressPrefix: appGwSubnetAddressPrefix
   networkSecurityGroup: {
    id: networkSecurityGroup.id
  }
   routeTable: {
    id: routeTable.id
  }
  serviceEndpoints: [
      {
        service: 'Microsoft.Web'
        locations: [
          location
        ]
      }
      {
        service: 'Microsoft.KeyVault'
        locations: [
          location
        ]
      }
    ]
 }
}


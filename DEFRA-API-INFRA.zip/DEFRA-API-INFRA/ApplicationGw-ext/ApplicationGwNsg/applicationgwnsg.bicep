param location string
param appGwNetworkSecurityGroupName string
param tags object = {}


module appGwNetworkSecurityGroup 'br/SharedDefraRegistry:network.network-security-group:0.4.10' = {
  name: appGwNetworkSecurityGroupName
  params:{
    name: appGwNetworkSecurityGroupName
    location: location
    tags: union(tags, { Name: appGwNetworkSecurityGroupName, Tier: 'NETWORK' })
    securityRules: [
      {
        name: 'ALLOW_Internal_Inbound'
        properties: {
          protocol: 'Tcp'
          destinationPortRanges: ['443','80']
          sourcePortRange: '*'
          access: 'Allow'
          priority: 140
          direction: 'Inbound'
          sourceAddressPrefix: 'VirtualNetwork'
          DestinationAddressPrefix: 'VirtualNetwork'
        }
      }
      {
        name: 'ALLOW_HTTPS_from_internet'
        properties: {
          protocol: 'Tcp'
          destinationPortRange: '443'
          sourcePortRange: '*'
          access: 'Allow'
          priority: 150
          direction: 'Inbound'
          sourceAddressPrefix: 'Internet'
          DestinationAddressPrefix: '*'
        }
      }
      {
        name: 'ALLOW_HTTP_from_internet'
        properties: {
          protocol: 'Tcp'
          destinationPortRange: '80'
          sourcePortRange: '*'
          access: 'Allow'
          priority: 151
          direction: 'Inbound'
          sourceAddressPrefix: 'Internet'
          DestinationAddressPrefix: '*'
        }
      }
      {
        name: 'ALLOW_Backend_Healthcheck'
        properties: {
          protocol: 'Tcp'
          destinationPortRange: '65200-65535'
          sourcePortRange: '*'
          access: 'Allow'
          priority: 152
          direction: 'Inbound'
          sourceAddressPrefix: 'GatewayManager'
          DestinationAddressPrefix: '*'
        }
      }
      {
        name: 'ALLOW_Azure_loadbalancer_probes'
        properties: {
          protocol: '*'
          destinationPortRange: '*'
          sourcePortRange: '*'
          access: 'Allow'
          priority: 153
          direction: 'Inbound'
          sourceAddressPrefix: 'AzureLoadBalancer'
          DestinationAddressPrefix: '*'
        }
      }
      {
        name: 'Deny_All'
        properties: {
          protocol: '*'
          access: 'Deny'
          sourcePortRange: '*'
          destinationPortRange: '*'
          priority: 4095
          direction: 'Inbound'
          sourceAddressPrefix: '*'
          DestinationAddressPrefix: '*'
        }
      }
    ]
  }
}


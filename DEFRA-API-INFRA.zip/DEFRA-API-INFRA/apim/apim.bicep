param apimName string
param serviceCodeName string
param location string
param tier string
param capacity int
param adminEmail string
param senderemail string
param organizationName string
param customProperties object
param identity string
param appInsightsName string
param publicIPAddress_name string
param publicIPAddress_name_domain string
param routeTableName string
param networkResourceGroupName string
param apimSubnetNsg string
param publicipfqdn string
param subnetID string
param virtualNetworkType string
param boomicertificateName string
param vault object
param contributorGroup string
param deployAll string
param apimCustomUrlPrefix string
param laWorkspaceName string
@secure()
param boomicertificateSecret string
param starAzureDefraCloudSslCertKeyVaultUri string

var deploy = (deployAll == 'true')
var keyVaultSecretUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'
var apimManagementServiceContributorRoleId = '312a565d-c81f-4fd8-895a-4e21e48d571c'
var varUniqueKeyvaultUserRoleId = guid(
  '/subscriptions/${subscription().subscriptionId}/resourceGroups/${resourceGroup().id}/providers/Microsoft.keyVault/vaults/${vault.name}',
  keyVaultSecretUserRoleId,
  resourceId('Microsoft.ApiManagement/service', apimName)
)
var varUniqueApimManagementServiceContributorRoleId = guid(
  '/subscriptions/${subscription().subscriptionId}/resourceGroups/${resourceGroup().id}/providers/Microsoft.ApiManagement/service/${apimName}',
  apimManagementServiceContributorRoleId,
  contributorGroup
)

resource laWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: laWorkspaceName
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' existing = {
  name: appInsightsName
}

// resource publicTempIPAddress 'Microsoft.Network/publicIPAddresses@2022-11-01' existing = {
//   name: 'PRDAPIINFPBIP1401'
// }

resource publicIPAddress 'Microsoft.Network/publicIPAddresses@2022-11-01' = {
  name: publicIPAddress_name
  location: location
  tags: {
    ServiceCode: serviceCodeName
  }
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  zones: [
    '2'
    '1'
    '3'
  ]
  properties: {
    publicIPAddressVersion: 'IPv4'
    publicIPAllocationMethod: 'Static'
    idleTimeoutInMinutes: 4
    dnsSettings: {
      domainNameLabel: publicIPAddress_name_domain
      fqdn: publicipfqdn
    }
    ipTags: []
    ddosSettings: {
      protectionMode: 'VirtualNetworkInherited'
    }
  }
}

resource apim 'Microsoft.ApiManagement/service@2022-08-01' = {
  name: apimName
  location: location
  tags: {
    ServiceCode: serviceCodeName
  }
  sku: {
    name: tier
    capacity: capacity
  }
  identity: {
    type: identity
  }
  // properties: {
  //   publisherEmail: adminEmail
  //   publisherName: organizationName
  //   notificationSenderEmail: senderemail
  //   hostnameConfigurations: [
  //     {
  //       hostName: '${toLower(apimName)}.azure-api.net'
  //       type: 'Proxy'
  //       certificateSource: 'BuiltIn'
  //       defaultSslBinding: false
  //     }
  //   ]
  //   virtualNetworkConfiguration: {
  //     subnetResourceId: subnetID
  //   }
  //   customProperties: customProperties
  //   virtualNetworkType: virtualNetworkType
  //   apiVersionConstraint: {}
  //   publicIpAddressId: publicIPAddress.id
  // }
  properties: {
    publisherEmail: adminEmail
    publisherName: organizationName
    notificationSenderEmail: senderemail
    virtualNetworkConfiguration: {
      subnetResourceId: subnetID
    }
    customProperties: customProperties
    virtualNetworkType: virtualNetworkType
    apiVersionConstraint: {}
    publicIpAddressId: publicIPAddress.id
    hostnameConfigurations: [
      {
        hostName: '${toLower(apimName)}.azure-api.net'
        type: 'Proxy'
        certificateSource: 'BuiltIn'
        defaultSslBinding: false
      }
      {
        hostName: '${apimCustomUrlPrefix}-gateway.azure.defra.cloud'
        type: 'Proxy'
        certificateSource: 'KeyVault'
        keyVaultId: starAzureDefraCloudSslCertKeyVaultUri
      }
      {
        hostName: '${apimCustomUrlPrefix}-portal.azure.defra.cloud'
        type: 'Portal'
        certificateSource: 'KeyVault'
        keyVaultId: starAzureDefraCloudSslCertKeyVaultUri
      }
      {
        hostName: '${apimCustomUrlPrefix}-developer.azure.defra.cloud'
        type: 'DeveloperPortal'
        certificateSource: 'KeyVault'
        keyVaultId: starAzureDefraCloudSslCertKeyVaultUri
      }
      {
        hostName: '${apimCustomUrlPrefix}-gateway-management.azure.defra.cloud'
        type: 'Management'
        certificateSource: 'KeyVault'
        keyVaultId: starAzureDefraCloudSslCertKeyVaultUri
      }

      {
        hostName: '${apimCustomUrlPrefix}-scm.azure.defra.cloud'
        type: 'Scm'
        certificateSource: 'KeyVault'
        keyVaultId: starAzureDefraCloudSslCertKeyVaultUri
      }
    ]
  }
  dependsOn: [
    apimRouteTableRoutes
    apimSubnetNsgRules
  ]
}

resource Apim_Audit_Setting 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${apim.name}-audit-settings'
  scope: apim
  properties: {
    workspaceId: laWorkspace.id
    logs: [
      {
        categoryGroup: 'allLogs'
        enabled: true
      }
      {
        categoryGroup: 'audit'
        enabled: true
      }
    ]
  }
}

resource keyVault 'Microsoft.KeyVault/vaults@2022-07-01' existing = {
  name: vault.name
}

resource uniqueKeyvaultUserGuid 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: keyVault
  name: varUniqueKeyvaultUserRoleId
  properties: {
    roleDefinitionId: resourceId('Microsoft.Authorization/roleDefinitions', keyVaultSecretUserRoleId)
    principalId: apim.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

resource uniqueApimManagementServiceContributorRoleGuid 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: apim
  name: varUniqueApimManagementServiceContributorRoleId
  properties: {
    roleDefinitionId: resourceId('Microsoft.Authorization/roleDefinitions', apimManagementServiceContributorRoleId)
    principalId: contributorGroup
    principalType: 'Group'
  }
}

resource boomiCertificate 'Microsoft.ApiManagement/service/certificates@2023-05-01-preview' = {
  parent: apim
  name: boomicertificateName
  properties: {
    data: boomicertificateSecret
  }
  dependsOn: [
    uniqueKeyvaultUserGuid
    uniqueApimManagementServiceContributorRoleGuid
  ]
}

resource appInsights_logger 'Microsoft.ApiManagement/service/loggers@2023-09-01-preview' = {
  parent: apim
  name: appInsightsName
  properties: {
    loggerType: 'applicationInsights'
    resourceId: appInsights.id
    credentials: {
      instrumentationKey: appInsights.properties.InstrumentationKey
    }
  }
}

resource apimName_applicationinsights 'Microsoft.ApiManagement/service/diagnostics@2023-09-01-preview' = {
  parent: apim
  name: 'applicationinsights'
  properties: {
    loggerId: appInsights_logger.id
    alwaysLog: 'allErrors'
    httpCorrelationProtocol: 'Legacy'
    verbosity: 'information'
    logClientIp: true
    sampling: {
      percentage: 100
      samplingType: 'fixed'
    }
    frontend: {
      request: {
        body: {
          bytes: 0
        }
      }
      response: {
        body: {
          bytes: 0
        }
      }
    }
    backend: {
      request: {
        body: {
          bytes: 0
        }
      }
      response: {
        body: {
          bytes: 0
        }
      }
    }
  }
}

module apimRouteTableRoutes 'routes.bicep' = {
  name: 'apimRouteTableModule'
  scope: resourceGroup(networkResourceGroupName)
  params: {
    apimPublicIp: publicIPAddress.properties.ipAddress
    routeTableName: routeTableName
  }
}

module apimSubnetNsgRules 'nsgRules.bicep' = {
  name: 'apimNsgRulesModule'
  scope: resourceGroup(networkResourceGroupName)
  params: {
    apimSubnetNsg: apimSubnetNsg
  }
}

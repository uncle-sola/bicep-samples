param vault object
param tenantId string

param environment string
param createdDate string = utcNow()
param rgLocation string = resourceGroup().location
param privateEndpointName string
param network object
param networkAclsDefaultAction string
param enablePublicAccess string
param serviceCodeName string
param ServiceNName string
param ServiceTypeName string
param auditStorageAccountName string
param laWorkspaceName string

var publicAccessEnabled = (enablePublicAccess == 'true')
var defaultTags = {
  ServiceCode: serviceCodeName
  ServiceName: ServiceNName
  ServiceType: ServiceTypeName
  CreatedDate: createdDate
  Environment: environment
  Tier: 'SHARED'
  Location: rgLocation
}

module keyVault '../../Defra.Infrastructure.Common/templates/Microsoft.KeyVault/vaults.bicep' = {
  name: 'vault-${createdDate}'
  params: {
    vaultName: vault.name
    sku: {
      name: 'Standard'
      family: 'A'
    }
    tenantId: tenantId
    location: rgLocation
    enablePublicAccess: publicAccessEnabled
    networkAclsDefaultAction: networkAclsDefaultAction
    privateEndpointName: privateEndpointName
    vnetResourceGroup: network.resourceGroup
    vnetName: network.vnetName
    vnetSubnetName: network.subnetName
    customTags: union(defaultTags, vault.customTags)
  }
}

module diagSetting 'keyvault-diag.bicep' = {
  name: 'diag-setting-${createdDate}'
  params: {
    auditStorageAccountName: auditStorageAccountName
    laWorkspaceName: laWorkspaceName
    vault: vault
  }
  dependsOn:[
    keyVault
  ]
}
